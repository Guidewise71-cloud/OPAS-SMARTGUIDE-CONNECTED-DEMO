import React from 'react';
import { ShieldCheck, CheckCircle2, TrendingUp, AlertTriangle, FileText, UserCheck, Lock } from 'lucide-react';

export const PilotEvaluationReport: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Governance & Sponsorship Header */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800">
              UNIPODS AI for Public Good Challenge · MoHAIS Initiative
            </span>
            <h2 className="text-lg font-bold text-slate-900 mt-0.5">
              Pilot Evaluation Framework &amp; Data Governance
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Expression of Interest (EOI) Milestone Tracker and Evaluation Metrics
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              Pilot Active (Week 4 of 6 Prototype Stage)
            </span>
          </div>
        </div>

        {/* Stakeholder Roles Table (from EOI Section 10) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-4 text-xs">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div className="text-slate-500 text-[11px]">Executive Sponsor</div>
            <div className="font-semibold text-slate-900 mt-0.5">Permanent Secretary</div>
            <div className="text-[11px] text-slate-500">Ministry of Home Affairs &amp; Internal Security</div>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div className="text-slate-500 text-[11px]">Programme Focal Point</div>
            <div className="font-semibold text-slate-900 mt-0.5">Spriano Banda</div>
            <div className="text-[11px] text-slate-500">Chief Systems Development Officer</div>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div className="text-slate-500 text-[11px]">Business Stakeholders</div>
            <div className="font-semibold text-slate-900 mt-0.5">Passport Office Leadership</div>
            <div className="text-[11px] text-slate-500">Vetting Officers &amp; Registry Administrators</div>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div className="text-slate-500 text-[11px]">Technical Stakeholders</div>
            <div className="font-semibold text-slate-900 mt-0.5">MoHAIS ICT Department</div>
            <div className="text-[11px] text-slate-500">OPAS Technical &amp; Data Administrators</div>
          </div>
        </div>
      </div>

      {/* Success Indicators Matrix (from EOI Section 9) */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-700" />
            Evaluation Indicators: Baseline vs. Pilot Results
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Technical validation findings comparing pre-pilot baseline with AI-assisted enhancement layer
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-semibold">
                <th className="py-2.5 px-3">Evaluation Area</th>
                <th className="py-2.5 px-3">Primary Indicator</th>
                <th className="py-2.5 px-3">Baseline (Legacy OPAS)</th>
                <th className="py-2.5 px-3">Pilot Performance</th>
                <th className="py-2.5 px-3">Measurement Approach</th>
                <th className="py-2.5 px-3 text-right">Variance Impact</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-900">Contact Validation</td>
                <td className="py-2.5 px-3">Invalid phone / email formats flagged pre-submission</td>
                <td className="py-2.5 px-3 text-slate-500">18.6% delivery failure</td>
                <td className="py-2.5 px-3 font-semibold text-emerald-700">1.8% failure (90% caught)</td>
                <td className="py-2.5 px-3 text-slate-500">RFC regex &amp; E.164 country code validator</td>
                <td className="py-2.5 px-3 text-right font-semibold text-emerald-700">-90.3% error rate</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-900">Application Completion</td>
                <td className="py-2.5 px-3">Paid-but-unsubmitted cases detected &amp; prompted</td>
                <td className="py-2.5 px-3 text-slate-500">Avg. 22 days dormant</td>
                <td className="py-2.5 px-3 font-semibold text-emerald-700">Avg. 3.2 days to submit</td>
                <td className="py-2.5 px-3 text-slate-500">Automated workflow scan &amp; scheduled SMS</td>
                <td className="py-2.5 px-3 text-right font-semibold text-emerald-700">+85.4% velocity</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-900">Reverted Case Management</td>
                <td className="py-2.5 px-3">Backlog clearance of ~1,500 outstanding reverted cases</td>
                <td className="py-2.5 px-3 text-slate-500">14% monthly resolution</td>
                <td className="py-2.5 px-3 font-semibold text-emerald-700">58.6% monthly resolution</td>
                <td className="py-2.5 px-3 text-slate-500">Targeted reversion remedy notices with pre-check</td>
                <td className="py-2.5 px-3 text-right font-semibold text-emerald-700">+4.2x clearance rate</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-900">Citizen Assistance</td>
                <td className="py-2.5 px-3">Guidance accuracy and self-service FAQ resolution</td>
                <td className="py-2.5 px-3 text-slate-500">100% manual officer enquiries</td>
                <td className="py-2.5 px-3 font-semibold text-emerald-700">76.2% resolved via AI Assistant</td>
                <td className="py-2.5 px-3 text-slate-500">Approved MoHAIS FAQ grounding model</td>
                <td className="py-2.5 px-3 text-right font-semibold text-emerald-700">-76% manual volume</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-900">Operational Efficiency</td>
                <td className="py-2.5 px-3">Passport officer hours on repetitive phone/counter queries</td>
                <td className="py-2.5 px-3 text-slate-500">3.5 hrs / officer / day</td>
                <td className="py-2.5 px-3 font-semibold text-emerald-700">0.8 hrs / officer / day</td>
                <td className="py-2.5 px-3 text-slate-500">Weekly officer workload timesheet comparison</td>
                <td className="py-2.5 px-3 text-right font-semibold text-emerald-700">-77% time diverted</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Timeline (EOI Section 7) & Governance Safeguards (EOI Section 6.1 & 10.1) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Pilot Timeline */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-700" />
            Pilot Roadmap Milestones (Weeks 1 – 6)
          </h3>
          <div className="space-y-2.5 text-xs">
            <div className="flex items-start gap-2.5 p-2 rounded bg-slate-50 border border-slate-200">
              <span className="font-mono text-emerald-700 font-bold text-[11px]">W1</span>
              <div>
                <span className="font-semibold text-slate-900">Requirements &amp; Baseline Assessment</span>
                <p className="text-[11px] text-slate-500">Confirm user needs, establish governance requirements and baseline.</p>
              </div>
            </div>
            <div className="flex items-start gap-2.5 p-2 rounded bg-slate-50 border border-slate-200">
              <span className="font-mono text-emerald-700 font-bold text-[11px]">W2</span>
              <div>
                <span className="font-semibold text-slate-900">Data Preparation &amp; System Design</span>
                <p className="text-[11px] text-slate-500">Prepare synthetic datasets, define validation rules, design virtual assistant.</p>
              </div>
            </div>
            <div className="flex items-start gap-2.5 p-2 rounded bg-emerald-50 border border-emerald-300">
              <span className="font-mono text-emerald-800 font-bold text-[11px]">W3–4</span>
              <div>
                <span className="font-semibold text-emerald-950">Prototype Development (Current)</span>
                <p className="text-[11px] text-emerald-800">Implement guidance assistant, validation logic, notification dispatcher, and dashboard.</p>
              </div>
            </div>
            <div className="flex items-start gap-2.5 p-2 rounded bg-slate-50 border border-slate-200">
              <span className="font-mono text-slate-500 font-bold text-[11px]">W5</span>
              <div>
                <span className="font-semibold text-slate-900">Testing &amp; Security Evaluation</span>
                <p className="text-[11px] text-slate-500">Test data protection, response quality, notification rules, and accuracy with stakeholders.</p>
              </div>
            </div>
            <div className="flex items-start gap-2.5 p-2 rounded bg-slate-50 border border-slate-200">
              <span className="font-mono text-slate-500 font-bold text-[11px]">W6</span>
              <div>
                <span className="font-semibold text-slate-900">Pilot Demonstration &amp; Reporting</span>
                <p className="text-[11px] text-slate-500">Demonstrate working prototype to MoHAIS executive team and submit UNIPODS report.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Governance & Anti-Risk Safeguards */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
            <Lock className="w-4 h-4 text-emerald-700" />
            Data Protection &amp; Governance Principles
          </h3>
          <div className="space-y-2 text-xs">
            <div className="p-2.5 bg-slate-50 border border-slate-200 rounded">
              <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                Human-in-the-Loop Oversight
              </div>
              <p className="text-[11px] text-slate-600 mt-0.5">
                AI outputs support applicants and officers but do NOT replace authorized decision-makers. Final approval or rejection of passport dossiers remains strictly under human officer authority.
              </p>
            </div>

            <div className="p-2.5 bg-slate-50 border border-slate-200 rounded">
              <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-emerald-600" />
                Synthetic &amp; Sandboxed Data Isolation
              </div>
              <p className="text-[11px] text-slate-600 mt-0.5">
                The pilot operates with approved synthetic test records replicating real OPAS edge cases, preventing exposure of live citizen biometric or national identity data.
              </p>
            </div>

            <div className="p-2.5 bg-slate-50 border border-slate-200 rounded">
              <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                Frequency Capping &amp; Anti-Spam Schedule
              </div>
              <p className="text-[11px] text-slate-600 mt-0.5">
                Automated reminder notifications enforce a 72-hour quiet interval per applicant to eliminate duplicate or aggressive messaging.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
