import React, { useState, useMemo } from 'react';
import {
  Users,
  AlertCircle,
  Clock,
  CheckCircle,
  FileWarning,
  Send,
  Search,
  Filter,
  Sparkles,
  ArrowUpRight,
  ArrowRight,
  TrendingDown,
  BarChart,
  Calendar,
  Layers,
  ShieldCheck,
  CheckCircle2,
  RefreshCw,
  X,
} from 'lucide-react';
import { PassportApplication, NotificationLog } from '../../types/passport';
import { CaseTriageModal } from './CaseTriageModal';
import { PilotEvaluationReport } from './PilotEvaluationReport';
import { ActionQueueTab } from './ActionQueueTab';
import { calculateActionQueueSummary, buildActionQueue } from '../../utils/actionQueue';
import { validatePhoneNumber, validateEmail } from '../../utils/validation';
import { PillarsModule } from '../common/PillarsModule';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
} from 'recharts';

interface OfficerDashboardProps {
  applications: PassportApplication[];
  onUpdateStatus: (id: string, newStatus: PassportApplication['status'], notes?: string) => void;
  onAddNotification: (id: string, notif: NotificationLog) => void;
  onSelectApplication: (app: PassportApplication) => void;
  selectedAppForCitizenView?: PassportApplication;
  onOpenAssistant?: () => void;
}

export const OfficerDashboard: React.FC<OfficerDashboardProps> = ({
  applications,
  onUpdateStatus,
  onAddNotification,
  onSelectApplication,
  onOpenAssistant,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'action-queue' | 'pillars' | 'registry' | 'evaluation'>('overview');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCaseForModal, setSelectedCaseForModal] = useState<PassportApplication | null>(null);
  const [batchReminderSent, setBatchReminderSent] = useState(false);
  const [chartDataSource, setChartDataSource] = useState<'national' | 'sandbox'>('national');
  const [hoveredSlice, setHoveredSlice] = useState<{
    name: string;
    value: number;
    color: string;
    description: string;
    filterKey: string;
  } | null>(null);

  // Status Distribution Data for Recharts Donut
  const donutChartData = useMemo(() => {
    if (chartDataSource === 'national') {
      return [
        { name: 'Pending Review', value: 2810, color: '#2563EB', filterKey: 'REVIEW', description: 'Under officer vetting' },
        { name: 'Reverted Cases', value: 1488, color: '#DC2626', filterKey: 'REVERTED', description: 'Awaiting citizen action' },
        { name: 'Paid Unsubmitted', value: 342, color: '#D97706', filterKey: 'PAID_UNSUBMITTED', description: 'Fee received, draft unsubmitted' },
        { name: 'Biometrics Scheduled', value: 4230, color: '#7C3AED', filterKey: 'BIOMETRICS', description: 'Enrollment confirmed' },
        { name: 'Approved & Printing', value: 3450, color: '#0284C7', filterKey: 'ALL', description: 'ICAO booklet printing' },
        { name: 'Ready for Collection', value: 1860, color: '#059669', filterKey: 'READY', description: 'At passport office counters' },
      ];
    }

    // Dynamic from current active session applications
    const statusMap: Record<string, { name: string; color: string; filterKey: string; description: string }> = {
      'Submitted - Under Review': { name: 'Pending Review', color: '#2563EB', filterKey: 'REVIEW', description: 'Under officer vetting' },
      'Reverted': { name: 'Reverted Cases', color: '#DC2626', filterKey: 'REVERTED', description: 'Awaiting citizen action' },
      'Paid - Unsubmitted': { name: 'Paid Unsubmitted', color: '#D97706', filterKey: 'PAID_UNSUBMITTED', description: 'Fee received, draft unsubmitted' },
      'Biometrics Scheduled': { name: 'Biometrics Scheduled', color: '#7C3AED', filterKey: 'BIOMETRICS', description: 'Enrollment confirmed' },
      'Processing & Printing': { name: 'Approved & Printing', color: '#0284C7', filterKey: 'ALL', description: 'ICAO booklet printing' },
      'Ready for Collection': { name: 'Ready for Collection', color: '#059669', filterKey: 'READY', description: 'At passport office counters' },
      'Draft': { name: 'Draft Intake', color: '#64748B', filterKey: 'ALL', description: 'In-progress intake' },
    };

    const countMap: Record<string, number> = {};
    applications.forEach((app) => {
      countMap[app.status] = (countMap[app.status] || 0) + 1;
    });

    return Object.entries(countMap).map(([status, count]) => {
      const info = statusMap[status] || { name: status, color: '#64748B', filterKey: 'ALL', description: '' };
      return {
        name: info.name,
        value: count,
        color: info.color,
        filterKey: info.filterKey,
        description: info.description,
      };
    });
  }, [applications, chartDataSource]);

  const totalDonutCount = useMemo(() => {
    return donutChartData.reduce((acc, curr) => acc + curr.value, 0);
  }, [donutChartData]);

  // Compute Live Metrics from applications
  const metrics = useMemo(() => {
    const total = applications.length;
    const reverted = applications.filter((a) => a.status === 'Reverted');
    const paidUnsubmitted = applications.filter((a) => a.status === 'Paid - Unsubmitted');
    const underReview = applications.filter((a) => a.status === 'Submitted - Under Review');
    const biometrics = applications.filter((a) => a.status === 'Biometrics Scheduled');
    const ready = applications.filter((a) => a.status === 'Ready for Collection');

    // Contact invalidity count
    const invalidContactCount = applications.filter((a) => {
      const p = validatePhoneNumber(a.contact.phone, a.contact.phoneCountryCode);
      const e = validateEmail(a.contact.email);
      return !p.isValid || p.warning || !e.isValid || e.warning;
    }).length;

    // Total fee held in paid unsubmitted
    const feeHeld = paidUnsubmitted.reduce((acc, curr) => acc + (curr.feeAmount || 500), 0);

    return {
      total,
      revertedCount: reverted.length,
      paidUnsubmittedCount: paidUnsubmitted.length,
      underReviewCount: underReview.length,
      biometricsCount: biometrics.length,
      readyCount: ready.length,
      invalidContactCount,
      feeHeld,
    };
  }, [applications]);

  // Focused Staff Action Queue Summary & Ordered Items
  const actionSummary = useMemo(() => calculateActionQueueSummary(applications), [applications]);
  const actionQueueItems = useMemo(() => buildActionQueue(applications), [applications]);

  // Filtered applications for Registry
  const filteredApplications = useMemo(() => {
    return applications.filter((app) => {
      const matchesStatus =
        statusFilter === 'ALL' ||
        (statusFilter === 'REVERTED' && app.status === 'Reverted') ||
        (statusFilter === 'PAID_UNSUBMITTED' && app.status === 'Paid - Unsubmitted') ||
        (statusFilter === 'REVIEW' && app.status === 'Submitted - Under Review') ||
        (statusFilter === 'BIOMETRICS' && app.status === 'Biometrics Scheduled') ||
        (statusFilter === 'READY' && app.status === 'Ready for Collection') ||
        (statusFilter === 'DRAFT' && app.status === 'Draft') ||
        (statusFilter === 'PRINTING' && app.status === 'Processing & Printing');

      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        q === '' ||
        app.fullName.toLowerCase().includes(q) ||
        app.trackingNumber.toLowerCase().includes(q) ||
        app.nrcNumber.toLowerCase().includes(q) ||
        app.contact.phone.includes(q) ||
        app.contact.email.toLowerCase().includes(q);

      return matchesStatus && matchesSearch;
    });
  }, [applications, statusFilter, searchQuery]);

  // Batch trigger automated reminders for aged cases
  const handleBatchTriggerReminders = () => {
    applications.forEach((app) => {
      if (app.status === 'Reverted' || app.status === 'Paid - Unsubmitted') {
        const notif: NotificationLog = {
          id: `batch-${Date.now()}-${app.id}`,
          timestamp: new Date().toISOString(),
          channel: 'SMS',
          subject: 'MoHAIS OPAS Scheduled Automated Notice',
          content:
            app.status === 'Reverted'
              ? `MoHAIS OPAS: Dear ${app.fullName}, your passport application #${app.trackingNumber} requires document correction to resume processing. Log into opas.mohais.gov.zm`
              : `MoHAIS OPAS: Dear ${app.fullName}, we received your payment for #${app.trackingNumber}. Please complete final submission & schedule biometrics.`,
          deliveryStatus: 'Delivered',
        };
        onAddNotification(app.id, notif);
      }
    });
    setBatchReminderSent(true);
    setTimeout(() => setBatchReminderSent(false), 4000);
  };

  return (
    <div className="space-y-6">
      {/* View Switcher / Secondary Subheader */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            MoHAIS OPAS Operational Intelligence
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Passport Office Vetting Pipeline, Bottleneck Detection &amp; Automated Reversion Management
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Sub-tab pills with Action Queue as TAB 2 */}
          <div className="flex flex-wrap items-center bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs font-semibold gap-1">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                activeTab === 'overview'
                  ? 'bg-white text-emerald-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Pipeline Overview
            </button>
            <button
              onClick={() => setActiveTab('action-queue')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'action-queue'
                  ? 'bg-amber-600 text-white shadow-xs font-bold'
                  : 'text-amber-900 bg-amber-50 hover:bg-amber-100 border border-amber-200'
              }`}
            >
              <AlertCircle className="w-3.5 h-3.5 text-amber-500" />
              <span>Action Queue</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-black ${
                activeTab === 'action-queue' ? 'bg-white text-amber-950' : 'bg-amber-200 text-amber-950'
              }`}>
                {actionSummary.totalNeedingAttention}
              </span>
            </button>
            <button
              onClick={() => setActiveTab('pillars')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'pillars'
                  ? 'bg-white text-emerald-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
              Smart Service Pillars
            </button>
            <button
              onClick={() => setActiveTab('registry')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                activeTab === 'registry'
                  ? 'bg-white text-emerald-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Application Registry ({applications.length})
            </button>
            <button
              onClick={() => setActiveTab('evaluation')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                activeTab === 'evaluation'
                  ? 'bg-white text-emerald-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Evaluation &amp; Governance
            </button>
          </div>
        </div>
      </div>

      {/* OFFICER GLOBAL SEARCH & STATUS FILTER BAR */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          {/* Search Input: NRC Number, Full Name, or Tracking Ref */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search applications by NRC number (e.g. 294812/11/1), Full Name, or Tracking Ref..."
              className="w-full text-xs pl-9 pr-8 py-2.5 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500 bg-white"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 rounded cursor-pointer"
                title="Clear search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Status Category Dropdown & Actions */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <div className="flex items-center gap-1.5 text-slate-500">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <span className="font-semibold text-slate-700">Status Category:</span>
            </div>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="text-xs font-semibold py-2 px-3 border border-slate-300 rounded-lg bg-slate-50 text-slate-800 focus:ring-1 focus:ring-emerald-500 cursor-pointer"
            >
              <option value="ALL">All Status Categories ({applications.length})</option>
              <option value="REVERTED">Reverted (Action Needed) ({metrics.revertedCount})</option>
              <option value="PAID_UNSUBMITTED">Paid - Unsubmitted ({metrics.paidUnsubmittedCount})</option>
              <option value="REVIEW">Under Review / Vetting ({metrics.underReviewCount})</option>
              <option value="BIOMETRICS">Biometrics Scheduled ({metrics.biometricsCount})</option>
              <option value="READY">Ready for Collection ({metrics.readyCount})</option>
            </select>

            {(searchQuery || statusFilter !== 'ALL') && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setStatusFilter('ALL');
                }}
                className="px-2.5 py-2 text-xs text-red-700 hover:bg-red-50 border border-red-200 rounded-lg font-medium transition-colors cursor-pointer flex items-center gap-1"
                title="Reset all search queries and status filters"
              >
                <X className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            )}
          </div>
        </div>

        {/* Quick Helper Filter Badges & Search Feedback */}
        <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-slate-500 text-[11px] font-medium">Quick Suggestions:</span>
            <button
              onClick={() => {
                setSearchQuery('Mutinta');
                setActiveTab('registry');
              }}
              className="text-[11px] bg-slate-100 hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 px-2 py-0.5 rounded border border-slate-200 cursor-pointer transition-colors"
            >
              Name: &ldquo;Mutinta&rdquo;
            </button>
            <button
              onClick={() => {
                setSearchQuery('294812/11/1');
                setActiveTab('registry');
              }}
              className="text-[11px] bg-slate-100 hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 px-2 py-0.5 rounded border border-slate-200 font-mono cursor-pointer transition-colors"
            >
              NRC: 294812/11/1
            </button>
            <button
              onClick={() => {
                setStatusFilter('REVERTED');
                setActiveTab('registry');
              }}
              className="text-[11px] bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 px-2 py-0.5 rounded font-semibold cursor-pointer transition-colors"
            >
              Status: Reverted
            </button>
            <button
              onClick={() => {
                setStatusFilter('PAID_UNSUBMITTED');
                setActiveTab('registry');
              }}
              className="text-[11px] bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 px-2 py-0.5 rounded font-semibold cursor-pointer transition-colors"
            >
              Status: Paid Unsubmitted
            </button>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-slate-500 text-[11px]">
              Showing <strong className="text-slate-900">{filteredApplications.length}</strong> of{' '}
              {applications.length} applications
            </span>
            {activeTab !== 'registry' && (
              <button
                onClick={() => setActiveTab('registry')}
                className="text-xs font-semibold text-emerald-800 hover:text-emerald-950 flex items-center gap-1 cursor-pointer"
              >
                <span>Open in Registry Table</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* VIEW 1: Overview & Pipeline Heatmap */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Executive Metrics Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Card 1: Reverted Backlog */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-semibold uppercase tracking-wider text-red-700">
                  Reverted Backlog
                </span>
                <AlertCircle className="w-4 h-4 text-red-600" />
              </div>
              <div className="text-2xl font-extrabold text-slate-900 mt-2 font-mono">
                1,488 <span className="text-xs font-sans font-normal text-slate-500">cases</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Targeting EOI ~1,500 stalled cases. 58.6% resolved via automated reminders.
              </p>
              <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-600">Sample active queue:</span>
                <span className="font-bold text-red-700">{metrics.revertedCount} cases in sandbox</span>
              </div>
            </div>

            {/* Card 2: Paid but Unsubmitted */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-semibold uppercase tracking-wider text-amber-700">
                  Paid but Unsubmitted
                </span>
                <Clock className="w-4 h-4 text-amber-600" />
              </div>
              <div className="text-2xl font-extrabold text-slate-900 mt-2 font-mono">
                342 <span className="text-xs font-sans font-normal text-slate-500">applications</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                ZMW 284,500 statutory fees deposited but stalled before final citizen submit.
              </p>
              <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-600">Sample active queue:</span>
                <span className="font-bold text-amber-700">{metrics.paidUnsubmittedCount} cases in sandbox</span>
              </div>
            </div>

            {/* Card 3: Invalid Contact Pre-Screening */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-semibold uppercase tracking-wider text-blue-700">
                  Contact Validation
                </span>
                <FileWarning className="w-4 h-4 text-blue-600" />
              </div>
              <div className="text-2xl font-extrabold text-slate-900 mt-2 font-mono">
                12.4% <span className="text-xs font-sans font-normal text-slate-500">flagged pre-submit</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Invalid phone formats and email typos caught before notification delivery fails.
              </p>
              <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-600">Sample active queue:</span>
                <span className="font-bold text-blue-700">{metrics.invalidContactCount} flagged cases</span>
              </div>
            </div>

            {/* Card 4: Reminder Conversion Rate */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-semibold uppercase tracking-wider text-emerald-700">
                  Reminder Conversion
                </span>
                <CheckCircle className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-2xl font-extrabold text-slate-900 mt-2 font-mono">
                68.4% <span className="text-xs font-sans font-normal text-slate-500">resolved &lt; 72h</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Applicants who act within 3 days of receiving automated SMS/Message Board prompt.
              </p>
              <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-600">Turnaround improvement:</span>
                <span className="font-bold text-emerald-700">28d &rarr; 9.4 days</span>
              </div>
            </div>
          </div>

          {/* Workflow Pipeline Bottleneck Heatmap */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <BarChart className="w-4 h-4 text-emerald-700" />
                  National OPAS Pipeline Stage Distribution &amp; Bottleneck Identification
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Flow analysis indicating where applicant dossiers stall in the verification lifecycle
                </p>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <button
                  onClick={handleBatchTriggerReminders}
                  disabled={batchReminderSent}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs transition-colors cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{batchReminderSent ? 'Batch Dispatched!' : 'Batch Trigger Stalled Reminders'}</span>
                </button>
              </div>
            </div>

            {/* Visual Funnel Heatmap */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2.5 text-xs">
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Stage 1</span>
                <span className="font-semibold text-slate-900 block mt-1">Draft Apps</span>
                <div className="text-base font-bold font-mono text-slate-800 mt-1">640</div>
                <div className="text-[10px] text-slate-500 mt-1">Normal intake</div>
              </div>

              <div className="p-3 rounded-lg bg-amber-50 border border-amber-300 relative">
                <span className="text-[10px] uppercase font-bold text-amber-800 block">Stage 2 ⚠️</span>
                <span className="font-semibold text-amber-950 block mt-1">Paid Unsubmitted</span>
                <div className="text-base font-bold font-mono text-amber-900 mt-1">342</div>
                <div className="text-[10px] text-amber-700 mt-1 font-semibold">Bottleneck: Fee hold</div>
              </div>

              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Stage 3</span>
                <span className="font-semibold text-slate-900 block mt-1">Under Review</span>
                <div className="text-base font-bold font-mono text-slate-800 mt-1">2,810</div>
                <div className="text-[10px] text-slate-500 mt-1">Officer vetting queue</div>
              </div>

              <div className="p-3 rounded-lg bg-red-50 border border-red-300 relative">
                <span className="text-[10px] uppercase font-bold text-red-800 block">Stage 4 ⚠️</span>
                <span className="font-semibold text-red-950 block mt-1">Reverted Cases</span>
                <div className="text-base font-bold font-mono text-red-900 mt-1">1,488</div>
                <div className="text-[10px] text-red-700 mt-1 font-semibold">Major Bottleneck</div>
              </div>

              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Stage 5</span>
                <span className="font-semibold text-slate-900 block mt-1">Biometrics</span>
                <div className="text-base font-bold font-mono text-slate-800 mt-1">4,230</div>
                <div className="text-[10px] text-slate-500 mt-1">Capture scheduled</div>
              </div>

              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Stage 6</span>
                <span className="font-semibold text-slate-900 block mt-1">Booklet Printing</span>
                <div className="text-base font-bold font-mono text-slate-800 mt-1">3,450</div>
                <div className="text-[10px] text-slate-500 mt-1">ICAO personalization</div>
              </div>

              <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-300">
                <span className="text-[10px] uppercase font-bold text-emerald-800 block">Stage 7</span>
                <span className="font-semibold text-emerald-950 block mt-1">Ready for Collection</span>
                <div className="text-base font-bold font-mono text-emerald-900 mt-1">1,860</div>
                <div className="text-[10px] text-emerald-700 mt-1">At Passport Counters</div>
              </div>
            </div>
          </div>

          {/* NEW: Passport Application Status Distribution (Donut Chart) */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <BarChart className="w-4 h-4 text-emerald-700" />
                  Passport Application Status Distribution (Donut Chart)
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Visual breakdown of application volumes by processing status (Pending Review, Reverted, Paid Unsubmitted, etc.)
                </p>
              </div>
              <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg text-xs font-semibold">
                <button
                  onClick={() => setChartDataSource('national')}
                  className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
                    chartDataSource === 'national' ? 'bg-white text-emerald-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  National Scope (14,180)
                </button>
                <button
                  onClick={() => setChartDataSource('sandbox')}
                  className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
                    chartDataSource === 'sandbox' ? 'bg-white text-emerald-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Active Session ({applications.length})
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
              {/* Donut Chart with Center Summary */}
              <div className="lg:col-span-5 relative flex items-center justify-center min-h-[280px]">
                <ResponsiveContainer width="100%" height={280}>
                  <PieChart>
                    <Pie
                      data={donutChartData}
                      cx="50%"
                      cy="50%"
                      innerRadius={72}
                      outerRadius={108}
                      paddingAngle={3}
                      dataKey="value"
                      onMouseEnter={(_, index) => setHoveredSlice(donutChartData[index])}
                      onMouseLeave={() => setHoveredSlice(null)}
                      cursor="pointer"
                    >
                      {donutChartData.map((entry, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={entry.color}
                          stroke={hoveredSlice?.name === entry.name ? '#0f172a' : '#ffffff'}
                          strokeWidth={hoveredSlice?.name === entry.name ? 2.5 : 1.5}
                        />
                      ))}
                    </Pie>
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const data: any = payload[0].payload;
                          const percent = totalDonutCount > 0 ? ((data.value / totalDonutCount) * 100).toFixed(1) : '0';
                          return (
                            <div className="bg-slate-900 text-white p-3 rounded-lg shadow-xl text-xs space-y-1 border border-slate-700 min-w-[190px]">
                              <div className="flex items-center gap-2">
                                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: data.color }} />
                                <span className="font-bold text-white">{data.name}</span>
                              </div>
                              <div className="flex items-baseline justify-between pt-1 border-t border-slate-800">
                                <span className="text-slate-400 text-[11px]">Dossiers:</span>
                                <span className="font-mono font-bold text-white">{data.value.toLocaleString()}</span>
                              </div>
                              <div className="flex items-baseline justify-between">
                                <span className="text-slate-400 text-[11px]">Pipeline Share:</span>
                                <span className="font-mono font-bold text-emerald-400">{percent}%</span>
                              </div>
                              {data.description && (
                                <p className="text-[10px] text-slate-400 pt-1 border-t border-slate-800 leading-tight">
                                  {data.description}
                                </p>
                              )}
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>

                {/* Center Label in Donut Hole */}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <span className="text-2xl font-extrabold text-slate-900 font-mono tracking-tight">
                    {hoveredSlice ? hoveredSlice.value.toLocaleString() : totalDonutCount.toLocaleString()}
                  </span>
                  <span className="text-[11px] font-semibold text-slate-500 max-w-[130px] text-center leading-tight">
                    {hoveredSlice ? hoveredSlice.name : 'Total Dossiers'}
                  </span>
                  {hoveredSlice && (
                    <span className="text-[10px] font-mono text-emerald-700 font-bold mt-0.5">
                      {((hoveredSlice.value / totalDonutCount) * 100).toFixed(1)}% of queue
                    </span>
                  )}
                </div>
              </div>

              {/* Status Breakdown Legend & One-Click Filter */}
              <div className="lg:col-span-7 space-y-2 text-xs">
                <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                  Status Category Breakdown (Click to filter queue)
                </div>
                <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg overflow-hidden bg-slate-50/50">
                  {donutChartData.map((item) => {
                    const percent = ((item.value / totalDonutCount) * 100).toFixed(1);
                    const isHovered = hoveredSlice?.name === item.name;

                    return (
                      <div
                        key={item.name}
                        onMouseEnter={() => setHoveredSlice(item)}
                        onMouseLeave={() => setHoveredSlice(null)}
                        onClick={() => {
                          setStatusFilter(item.filterKey);
                          setActiveTab('registry');
                        }}
                        className={`p-2.5 flex items-center justify-between gap-3 transition-colors cursor-pointer ${
                          isHovered ? 'bg-slate-100' : 'hover:bg-white'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <span
                            className="w-3 h-3 rounded-full shrink-0"
                            style={{ backgroundColor: item.color }}
                          />
                          <div className="min-w-0">
                            <div className="font-semibold text-slate-900 truncate flex items-center gap-1.5">
                              <span>{item.name}</span>
                              {item.name.includes('Reverted') && (
                                <span className="text-[9px] bg-red-100 text-red-800 font-bold px-1 rounded">
                                  Action Needed
                                </span>
                              )}
                              {item.name.includes('Paid Unsubmitted') && (
                                <span className="text-[9px] bg-amber-100 text-amber-800 font-bold px-1 rounded">
                                  Fee Held
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] text-slate-500 truncate">{item.description}</div>
                          </div>
                        </div>

                        <div className="flex items-center gap-3 shrink-0 text-right">
                          <div>
                            <span className="font-bold font-mono text-slate-900 block">
                              {item.value.toLocaleString()}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono">{percent}%</span>
                          </div>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setStatusFilter(item.filterKey);
                              setActiveTab('registry');
                            }}
                            className="px-2 py-1 bg-white border border-slate-200 hover:border-emerald-300 hover:text-emerald-800 rounded text-[10px] font-semibold text-slate-600 transition-colors shadow-2xs"
                          >
                            Filter Queue
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Reversion Cause Breakdown & Intelligence Insights */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Reversion Reasons Breakdown */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Root Cause Analysis: Why OPAS Applications Are Reverted
              </h3>
              <div className="space-y-3 text-xs">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium text-slate-800">
                      Passport Photo Non-Compliance (Shadows, Dark Background, Glare)
                    </span>
                    <span className="font-bold text-slate-900">38%</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2">
                    <div className="bg-red-500 h-2 rounded-full" style={{ width: '38%' }}></div>
                  </div>
                  <span className="text-[11px] text-slate-500">
                    Addressed by: Citizen Pre-Flight AI Optical Photo Inspector
                  </span>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium text-slate-800">
                      Missing Guarantor Section (Signature, Official Stamp, or NRC)
                    </span>
                    <span className="font-bold text-slate-900">24%</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2">
                    <div className="bg-amber-500 h-2 rounded-full" style={{ width: '24%' }}></div>
                  </div>
                  <span className="text-[11px] text-slate-500">
                    Addressed by: Mandatory guarantor validation pre-submission
                  </span>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium text-slate-800">
                      Discrepancy Between Green NRC and Birth Certificate Names
                    </span>
                    <span className="font-bold text-slate-900">19%</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2">
                    <div className="bg-indigo-500 h-2 rounded-full" style={{ width: '19%' }}></div>
                  </div>
                  <span className="text-[11px] text-slate-500">
                    Addressed by: Automated name token consistency checks
                  </span>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium text-slate-800">
                      Invalid or Unreachable Contact Information (Phone / Email Typos)
                    </span>
                    <span className="font-bold text-slate-900">12%</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2">
                    <div className="bg-blue-500 h-2 rounded-full" style={{ width: '12%' }}></div>
                  </div>
                  <span className="text-[11px] text-slate-500">
                    Addressed by: Real-time E.164 and RFC email syntax correction
                  </span>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium text-slate-800">
                      Missing Parental Consent for Minor Applicants
                    </span>
                    <span className="font-bold text-slate-900">7%</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2">
                    <div className="bg-purple-500 h-2 rounded-full" style={{ width: '7%' }}></div>
                  </div>
                  <span className="text-[11px] text-slate-500">
                    Addressed by: Age-aware dynamic conditional document requirements
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Priority Queue Table */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4 text-amber-600" />
                    Focused Action Queue ({actionSummary.totalNeedingAttention})
                  </h3>
                  <span className="text-[11px] text-slate-500">Sorted by longest wait duration</span>
                </div>
                <button
                  onClick={() => setActiveTab('action-queue')}
                  className="text-xs font-bold text-emerald-800 hover:text-emerald-950 flex items-center gap-1 cursor-pointer bg-emerald-50 hover:bg-emerald-100 px-2.5 py-1 rounded-lg border border-emerald-200 transition-colors"
                >
                  <span>Open Full Queue ({actionSummary.totalNeedingAttention})</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="divide-y divide-slate-100">
                {actionQueueItems.slice(0, 4).map((item) => {
                  const app = item.application;
                  const days = app.daysInStatus || 0;
                  return (
                    <div
                      key={app.id}
                      onClick={() => setSelectedCaseForModal(app)}
                      className="py-2.5 flex items-center justify-between gap-3 hover:bg-slate-50 px-2 rounded cursor-pointer transition-colors"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            days >= 14 ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'
                          }`}>
                            {days}d wait
                          </span>
                          <span className="text-xs font-semibold text-slate-900">{app.fullName}</span>
                          <span className="font-mono text-[11px] text-slate-500">{app.trackingNumber}</span>
                          {app.isUrgent && (
                            <span className="text-[9px] bg-red-500 text-white font-bold px-1 rounded">
                              EXPRESS
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-600 line-clamp-1">
                          {item.primaryReason}
                        </div>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedCaseForModal(app);
                        }}
                        className="px-2.5 py-1 text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 rounded hover:bg-emerald-100 transition-colors shrink-0"
                      >
                        AI Triage
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Pillars Showcase Embedded in Overview */}
          <PillarsModule
            applications={applications}
            onOpenAssistant={onOpenAssistant || (() => {})}
            onSelectApplication={onSelectApplication}
            onAddNotification={onAddNotification}
            onUpdateStatus={onUpdateStatus}
            isOfficerRole={true}
          />
        </div>
      )}

      {/* VIEW 2: Dedicated Focused Staff Action Queue */}
      {activeTab === 'action-queue' && (
        <ActionQueueTab
          applications={applications}
          onOpenTriageModal={(app) => setSelectedCaseForModal(app)}
          onUpdateStatus={onUpdateStatus}
          onAddNotification={onAddNotification}
          onSelectApplication={onSelectApplication}
        />
      )}

      {/* VIEW: Dedicated Smart Service Pillars View */}
      {activeTab === 'pillars' && (
        <PillarsModule
          applications={applications}
          onOpenAssistant={onOpenAssistant || (() => {})}
          onSelectApplication={onSelectApplication}
          onAddNotification={onAddNotification}
          onUpdateStatus={onUpdateStatus}
          isOfficerRole={true}
        />
      )}

      {/* VIEW 2: Full Applications Registry */}
      {activeTab === 'registry' && (
        <div className="space-y-4">
          {/* Filters & Search Toolbar */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by name, tracking number, NRC, phone..."
                className="w-full text-xs pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-emerald-500 bg-white"
              />
            </div>

            {/* Status Filter Tabs */}
            <div className="flex flex-wrap items-center gap-1.5 text-xs">
              <span className="text-slate-500 text-xs mr-1 hidden sm:inline">Filter:</span>
              {[
                { id: 'ALL', label: 'All Cases' },
                { id: 'REVERTED', label: 'Reverted' },
                { id: 'PAID_UNSUBMITTED', label: 'Paid Unsubmitted' },
                { id: 'REVIEW', label: 'Under Review' },
                { id: 'BIOMETRICS', label: 'Biometrics' },
                { id: 'READY', label: 'Ready' },
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => setStatusFilter(f.id)}
                  className={`px-2.5 py-1.5 rounded-md font-semibold transition-colors cursor-pointer ${
                    statusFilter === f.id
                      ? 'bg-emerald-800 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* Applications Data Table */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-semibold">
                    <th className="py-3 px-4">Tracking Number &amp; Applicant</th>
                    <th className="py-3 px-4">NRC &amp; Type</th>
                    <th className="py-3 px-4">Current Status</th>
                    <th className="py-3 px-4">Contact Integrity</th>
                    <th className="py-3 px-4">Days in Stage</th>
                    <th className="py-3 px-4">Office</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {filteredApplications.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-500 text-xs">
                        No applications found matching your criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredApplications.map((app) => {
                      const phoneValid = validatePhoneNumber(app.contact.phone, app.contact.phoneCountryCode).isValid;
                      const emailValid = validateEmail(app.contact.email).isValid;
                      const contactOk = phoneValid && emailValid;

                      return (
                        <tr
                          key={app.id}
                          className="hover:bg-slate-50/70 transition-colors cursor-pointer"
                          onClick={() => setSelectedCaseForModal(app)}
                        >
                          <td className="py-3 px-4">
                            <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                              <span>{app.fullName}</span>
                              {app.isUrgent && (
                                <span className="text-[9px] bg-amber-500 text-slate-950 font-bold px-1 rounded">
                                  EXPRESS
                                </span>
                              )}
                            </div>
                            <div className="font-mono text-[11px] text-slate-500">{app.trackingNumber}</div>
                          </td>

                          <td className="py-3 px-4">
                            <div className="font-mono text-slate-900">{app.nrcNumber}</div>
                            <div className="text-[11px] text-slate-500">{app.passportType}</div>
                          </td>

                          <td className="py-3 px-4">
                            <span
                              className={`inline-block px-2 py-0.5 rounded text-[11px] font-semibold ${
                                app.status === 'Reverted'
                                  ? 'bg-red-100 text-red-800'
                                  : app.status === 'Paid - Unsubmitted'
                                  ? 'bg-amber-100 text-amber-800'
                                  : app.status === 'Ready for Collection'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : app.status === 'Biometrics Scheduled'
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-slate-100 text-slate-800'
                              }`}
                            >
                              {app.status}
                            </span>
                            {app.reversionReason && (
                              <div className="text-[10px] text-red-600 line-clamp-1 mt-0.5 max-w-xs">
                                {app.reversionReason}
                              </div>
                            )}
                          </td>

                          <td className="py-3 px-4">
                            {contactOk ? (
                              <span className="text-emerald-700 font-semibold flex items-center gap-1 text-[11px]">
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                Verified E.164
                              </span>
                            ) : (
                              <span className="text-amber-700 font-semibold flex items-center gap-1 text-[11px]">
                                <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                                Flagged for Correction
                              </span>
                            )}
                            <div className="text-[11px] text-slate-500 font-mono">{app.contact.phone}</div>
                          </td>

                          <td className="py-3 px-4">
                            <span
                              className={`font-semibold ${
                                app.daysInStatus > 7 ? 'text-red-700' : 'text-slate-700'
                              }`}
                            >
                              {app.daysInStatus} days
                            </span>
                            {app.daysInStatus > 7 && (
                              <span className="block text-[10px] text-red-600">SLA Exceeded</span>
                            )}
                          </td>

                          <td className="py-3 px-4 text-slate-600">
                            {app.collectionOffice.replace('Passport Office', 'P.O.')}
                          </td>

                          <td className="py-3 px-4 text-right space-x-1" onClick={(e) => e.stopPropagation()}>
                            <button
                              onClick={() => setSelectedCaseForModal(app)}
                              className="px-2.5 py-1 text-[11px] font-semibold bg-emerald-700 text-white rounded hover:bg-emerald-800 transition-colors cursor-pointer"
                            >
                              Triage &amp; Remind
                            </button>
                            <button
                              onClick={() => {
                                onSelectApplication(app);
                              }}
                              className="px-2 py-1 text-[11px] font-semibold bg-slate-100 text-slate-700 rounded hover:bg-slate-200 transition-colors cursor-pointer"
                              title="Open in Citizen Portal View"
                            >
                              View as Citizen
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 3: Pilot Evaluation & Governance Report */}
      {activeTab === 'evaluation' && <PilotEvaluationReport />}

      {/* Case Triage Modal */}
      {selectedCaseForModal && (
        <CaseTriageModal
          application={selectedCaseForModal}
          onClose={() => setSelectedCaseForModal(null)}
          onUpdateStatus={(id, newStatus, notes) => {
            onUpdateStatus(id, newStatus, notes);
            setSelectedCaseForModal(null);
          }}
          onAddNotification={onAddNotification}
        />
      )}
    </div>
  );
};
