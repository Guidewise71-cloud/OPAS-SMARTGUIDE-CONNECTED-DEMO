import React, { useState } from 'react';
import {
  Search,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Sparkles,
  Upload,
  ArrowRight,
  Shield,
  FileText,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Send,
  MessageSquare,
  HelpCircle,
  PlusCircle,
  RefreshCw,
} from 'lucide-react';
import { PassportApplication, NotificationLog } from '../../types/passport';
import { APPROVED_FAQS } from '../../data/faqs';
import { ApplicationForm } from './ApplicationForm';
import { PillarsModule } from '../common/PillarsModule';

interface CitizenPortalProps {
  applications: PassportApplication[];
  selectedApplication: PassportApplication;
  onSelectApplication: (app: PassportApplication) => void;
  onUpdateStatus: (id: string, newStatus: PassportApplication['status'], notes?: string) => void;
  onAddNewApplication: (newApp: PassportApplication) => void;
  onOpenAssistant: () => void;
  onAddNotification?: (id: string, notif: NotificationLog) => void;
}

export const CitizenPortal: React.FC<CitizenPortalProps> = ({
  applications,
  selectedApplication,
  onSelectApplication,
  onUpdateStatus,
  onAddNewApplication,
  onOpenAssistant,
  onAddNotification,
}) => {
  const [activeTab, setActiveTab] = useState<'status' | 'pillars' | 'apply' | 'faqs' | 'messages'>('status');
  const [searchTracking, setSearchTracking] = useState('');
  const [reuploading, setReuploading] = useState(false);
  const [reuploadSuccess, setReuploadSuccess] = useState(false);
  const [aiPreCheckScore, setAiPreCheckScore] = useState<number | null>(null);

  // Stepper helper
  const getStageIndex = (status: PassportApplication['status']) => {
    switch (status) {
      case 'Draft':
        return 1;
      case 'Paid - Unsubmitted':
        return 2;
      case 'Submitted - Under Review':
        return 3;
      case 'Reverted':
        return 2.5; // flagged between review & submit
      case 'Biometrics Scheduled':
        return 4;
      case 'Processing & Printing':
        return 5;
      case 'Ready for Collection':
      case 'Completed':
        return 6;
      default:
        return 1;
    }
  };

  const currentStageNum = getStageIndex(selectedApplication.status);

  // Re-upload corrected document for reverted case
  const handleSimulateReupload = () => {
    setReuploading(true);
    setTimeout(() => {
      setAiPreCheckScore(97);
      setReuploadSuccess(true);
      setReuploading(false);

      // Auto update status after 1.5 seconds
      setTimeout(() => {
        onUpdateStatus(
          selectedApplication.id,
          'Submitted - Under Review',
          'Applicant uploaded corrected photo via OPAS Citizen Assistant. Passed AI pre-flight check.'
        );
        setReuploadSuccess(false);
      }, 1500);
    }, 1000);
  };

  // Complete submission for paid unsubmitted case
  const handleFinalizePaidSubmit = () => {
    onUpdateStatus(
      selectedApplication.id,
      'Submitted - Under Review',
      'Applicant completed final submission step after automated reminder.'
    );
  };

  return (
    <div className="space-y-6">
      {/* Subheader & Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            OPAS Citizen Passport Services
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Ministry of Home Affairs &amp; Internal Security · Self-Service &amp; Application Tracking
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs font-semibold">
            <button
              onClick={() => setActiveTab('status')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                activeTab === 'status'
                  ? 'bg-white text-emerald-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Track Application
            </button>
            <button
              onClick={() => setActiveTab('pillars')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'pillars'
                  ? 'bg-white text-emerald-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              Smart Features
            </button>
            <button
              onClick={() => setActiveTab('apply')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'apply'
                  ? 'bg-white text-emerald-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <PlusCircle className="w-3.5 h-3.5" />
              New Application
            </button>
            <button
              onClick={() => setActiveTab('messages')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                activeTab === 'messages'
                  ? 'bg-white text-emerald-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Message Board ({selectedApplication.notifications.length})
            </button>
            <button
              onClick={() => setActiveTab('faqs')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                activeTab === 'faqs'
                  ? 'bg-white text-emerald-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Approved FAQs
            </button>
          </div>
        </div>
      </div>

      {/* TAB 1: Application Tracking & Resolution Center */}
      {activeTab === 'status' && (
        <div className="space-y-6">
          {/* Tracker Search Box */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex-1 max-w-lg relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTracking}
                onChange={(e) => setSearchTracking(e.target.value)}
                placeholder="Enter Reference (e.g., ZAM-OPAS-2026-1592) or Green NRC..."
                className="w-full text-xs pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-emerald-500 bg-white"
              />
            </div>

            <div className="flex items-center gap-1.5 text-xs text-slate-500">
              <span className="hidden sm:inline">Try Demo Cases:</span>
              <button
                onClick={() => {
                  const m = applications.find((a) => a.id === 'app-002');
                  if (m) onSelectApplication(m);
                }}
                className="px-2 py-1 bg-red-50 text-red-700 border border-red-200 rounded font-semibold text-[11px] hover:bg-red-100 transition-colors cursor-pointer"
              >
                Reverted Case (Mutinta)
              </button>
              <button
                onClick={() => {
                  const p = applications.find((a) => a.id === 'app-001');
                  if (p) onSelectApplication(p);
                }}
                className="px-2 py-1 bg-amber-50 text-amber-800 border border-amber-200 rounded font-semibold text-[11px] hover:bg-amber-100 transition-colors cursor-pointer"
              >
                Paid Unsubmitted (Kondwani)
              </button>
              <button
                onClick={() => {
                  const r = applications.find((a) => a.id === 'app-006');
                  if (r) onSelectApplication(r);
                }}
                className="px-2 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded font-semibold text-[11px] hover:bg-emerald-100 transition-colors cursor-pointer"
              >
                Ready for Pickup (Mwamba)
              </button>
            </div>
          </div>

          {/* Active Application Dossier Card */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
            {/* Header info */}
            <div className="p-5 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-start gap-3.5">
                <div className="w-12 h-12 rounded-lg bg-emerald-800 flex items-center justify-center text-white shrink-0 shadow-xs">
                  <Shield className="w-6 h-6 stroke-[2]" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-slate-900">{selectedApplication.fullName}</h3>
                    <span className="font-mono text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-semibold">
                      {selectedApplication.trackingNumber}
                    </span>
                    {selectedApplication.isUrgent && (
                      <span className="text-[10px] bg-amber-500 text-slate-950 font-bold px-1.5 py-0.5 rounded">
                        EXPRESS
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-slate-500 mt-1 flex flex-wrap items-center gap-2">
                    <span>NRC: {selectedApplication.nrcNumber}</span>
                    <span aria-hidden="true">·</span>
                    <span>Type: {selectedApplication.passportType}</span>
                    <span aria-hidden="true">·</span>
                    <span>Office: {selectedApplication.collectionOffice}</span>
                  </div>
                </div>
              </div>

              {/* Status Badge & AI Guidance Trigger */}
              <div className="flex items-center gap-2.5">
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Current Stage</span>
                  <span
                    className={`inline-block px-2.5 py-1 rounded text-xs font-bold ${
                      selectedApplication.status === 'Reverted'
                        ? 'bg-red-100 text-red-800'
                        : selectedApplication.status === 'Paid - Unsubmitted'
                        ? 'bg-amber-100 text-amber-800'
                        : selectedApplication.status === 'Ready for Collection'
                        ? 'bg-emerald-100 text-emerald-800'
                        : selectedApplication.status === 'Biometrics Scheduled'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-slate-100 text-slate-800'
                    }`}
                  >
                    {selectedApplication.status}
                  </span>
                </div>

                <button
                  onClick={onOpenAssistant}
                  className="px-3 py-2 bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-lg text-xs font-semibold hover:bg-emerald-100 transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Ask Assistant About This Case</span>
                </button>
              </div>
            </div>

            {/* Visual 6-Stage Progress Stepper */}
            <div className="p-6 bg-slate-50 border-b border-slate-200">
              <span className="text-[10px] uppercase font-bold text-slate-400 block mb-3">
                Official OPAS Processing Lifecycle
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-xs">
                {[
                  { num: 1, label: 'Intake & Form' },
                  { num: 2, label: 'Statutory Fee' },
                  { num: 3, label: 'Officer Review' },
                  { num: 4, label: 'Biometrics' },
                  { num: 5, label: 'Personalization' },
                  { num: 6, label: 'Ready for Pickup' },
                ].map((s) => {
                  const isDone = currentStageNum >= s.num && selectedApplication.status !== 'Reverted';
                  const isCurrent = Math.floor(currentStageNum) === s.num;
                  const isRevertedAtThis = selectedApplication.status === 'Reverted' && s.num === 3;

                  return (
                    <div
                      key={s.num}
                      className={`p-2.5 rounded-lg border transition-all ${
                        isRevertedAtThis
                          ? 'bg-red-50 border-red-300 text-red-900'
                          : isDone
                          ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                          : isCurrent
                          ? 'bg-white border-emerald-500 shadow-xs text-slate-900 ring-1 ring-emerald-500'
                          : 'bg-white border-slate-200 text-slate-400'
                      }`}
                    >
                      <div className="flex items-center justify-between text-[11px] mb-1 font-semibold">
                        <span>Step {s.num}</span>
                        {isDone && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                        {isRevertedAtThis && <AlertTriangle className="w-3.5 h-3.5 text-red-600" />}
                      </div>
                      <div className="font-semibold text-xs leading-tight">{s.label}</div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* ACTION CENTER 1: Reverted Case Resolution Panel */}
            {selectedApplication.status === 'Reverted' && (
              <div className="p-6 bg-red-50/70 border-b border-red-200 space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                    <AlertTriangle className="w-4 h-4" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-red-950">
                      Action Required: Application Reverted by Passport Officer
                    </h4>
                    <p className="text-xs text-red-800 leading-relaxed">
                      <strong>Reason from Officer:</strong> &ldquo;{selectedApplication.reversionReason}&rdquo;
                    </p>
                    <p className="text-[11px] text-red-700">
                      Good news: You do <strong>NOT</strong> have to pay the fee again. Simply upload the corrected item below to restore your place in the processing queue.
                    </p>
                  </div>
                </div>

                {/* Upload Correction with AI Pre-Check */}
                <div className="bg-white border border-red-200 rounded-lg p-4 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        Upload Corrected Passport Photo
                      </span>
                      <span className="text-[11px] text-slate-500">
                        Plain off-white/light-grey background, even lighting, no sunglasses or shadows.
                      </span>
                    </div>

                    <button
                      onClick={handleSimulateReupload}
                      disabled={reuploading || reuploadSuccess}
                      className="px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-md shadow-xs transition-colors cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
                    >
                      {reuploading ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>Checking with AI...</span>
                        </>
                      ) : reuploadSuccess ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Approved &amp; Resubmitted!</span>
                        </>
                      ) : (
                        <>
                          <Upload className="w-3.5 h-3.5" />
                          <span>Simulate Upload Corrected Photo</span>
                        </>
                      )}
                    </button>
                  </div>

                  {reuploadSuccess && (
                    <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-md text-xs text-emerald-900 flex items-center justify-between">
                      <span className="font-semibold flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        AI Pre-Check Passed (Optical Score: {aiPreCheckScore}/100)! Moving case back to Vetting Officer.
                      </span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ACTION CENTER 2: Paid-but-Unsubmitted Alert Panel */}
            {selectedApplication.status === 'Paid - Unsubmitted' && (
              <div className="p-6 bg-amber-50 border-b border-amber-200 space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-amber-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-amber-950">
                      Statutory Payment Received — Final Submission Pending!
                    </h4>
                    <p className="text-xs text-amber-900 leading-relaxed">
                      We have verified your payment of <strong>ZMW {selectedApplication.feeAmount}</strong> (Ref: {selectedApplication.paymentReference || 'GPG-TX-994821'}). However, your application remains unsubmitted in draft status.
                    </p>
                    <p className="text-[11px] text-amber-800">
                      Click &quot;Finalize &amp; Submit Application&quot; to formally transmit your dossier to the Passport Office and trigger your biometrics booking.
                    </p>
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    onClick={handleFinalizePaidSubmit}
                    className="px-5 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-md shadow-xs transition-colors cursor-pointer flex items-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Finalize &amp; Submit Application to Passport Office</span>
                  </button>
                </div>
              </div>
            )}

            {/* Details Grid */}
            <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
              {/* Column 1: Contact Info */}
              <div className="space-y-2">
                <span className="text-[11px] uppercase font-bold text-slate-400 block">Contact Information</span>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                  <div className="flex items-center gap-2 text-slate-700">
                    <Phone className="w-3.5 h-3.5 text-slate-500" />
                    <span className="font-mono">{selectedApplication.contact.phone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-700">
                    <Mail className="w-3.5 h-3.5 text-slate-500" />
                    <span className="truncate">{selectedApplication.contact.email}</span>
                  </div>
                  <div className="flex items-start gap-2 text-slate-700">
                    <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
                    <span>
                      {selectedApplication.contact.residentialAddress}, {selectedApplication.contact.district}
                    </span>
                  </div>
                </div>
              </div>

              {/* Column 2: Guarantor Info */}
              <div className="space-y-2">
                <span className="text-[11px] uppercase font-bold text-slate-400 block">Verified Guarantor</span>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1.5">
                  <div className="font-semibold text-slate-900">{selectedApplication.guarantor.fullName}</div>
                  <div className="text-slate-600">{selectedApplication.guarantor.profession}</div>
                  <div className="text-[11px] text-slate-500 font-mono">
                    NRC: {selectedApplication.guarantor.nrcNumber}
                  </div>
                  <div className="text-[11px] text-slate-500">{selectedApplication.guarantor.organization}</div>
                </div>
              </div>

              {/* Column 3: Biometrics & Collection Info */}
              <div className="space-y-2">
                <span className="text-[11px] uppercase font-bold text-slate-400 block">Collection &amp; Biometrics</span>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                  <div>
                    <div className="text-slate-500 text-[11px]">Pickup Office:</div>
                    <div className="font-semibold text-slate-900">{selectedApplication.collectionOffice}</div>
                  </div>
                  {selectedApplication.biometricsDate && (
                    <div>
                      <div className="text-slate-500 text-[11px]">Appointment Confirmed:</div>
                      <div className="font-semibold text-emerald-800 flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        {selectedApplication.biometricsDate}
                      </div>
                    </div>
                  )}
                  {selectedApplication.status === 'Ready for Collection' && (
                    <div className="p-2 bg-emerald-100/70 border border-emerald-300 rounded text-emerald-950 font-semibold text-[11px]">
                      Booklet ready at Counter 4. Bring original Green NRC.
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Pillars Showcase: Contact Validation, Case Completion, Reverted Response */}
          <PillarsModule
            applications={applications}
            onOpenAssistant={onOpenAssistant}
            onSelectApplication={onSelectApplication}
            onAddNotification={onAddNotification || (() => {})}
            onUpdateStatus={onUpdateStatus}
            isOfficerRole={false}
          />
        </div>
      )}

      {/* Dedicated Smart Features Pillar View */}
      {activeTab === 'pillars' && (
        <PillarsModule
          applications={applications}
          onOpenAssistant={onOpenAssistant}
          onSelectApplication={onSelectApplication}
          onAddNotification={onAddNotification || (() => {})}
          onUpdateStatus={onUpdateStatus}
          isOfficerRole={false}
        />
      )}

      {/* TAB 2: New Application Form */}
      {activeTab === 'apply' && (
        <ApplicationForm
          onSubmitSuccess={(newApp) => {
            onAddNewApplication(newApp);
            onSelectApplication(newApp);
            setActiveTab('status');
          }}
          onCancel={() => setActiveTab('status')}
        />
      )}

      {/* TAB 3: Message Board Notifications */}
      {activeTab === 'messages' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Official OPAS Message Board &amp; SMS Dispatch Log
              </h3>
              <p className="text-xs text-slate-500">
                Authorized notifications sent to {selectedApplication.fullName} ({selectedApplication.trackingNumber})
              </p>
            </div>
            <span className="text-xs font-mono bg-slate-100 px-2.5 py-1 rounded font-semibold text-slate-700">
              {selectedApplication.notifications.length} Logs
            </span>
          </div>

          <div className="space-y-3">
            {selectedApplication.notifications.map((n) => (
              <div
                key={n.id}
                className="p-4 rounded-lg border border-slate-200 bg-slate-50/70 text-xs space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900">{n.subject || 'OPAS Alert'}</span>
                    <span className="text-[10px] bg-slate-200 text-slate-800 px-1.5 py-0.2 rounded font-mono font-semibold">
                      {n.channel}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-500 font-mono">
                      {new Date(n.timestamp).toLocaleString()}
                    </span>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-semibold px-1.5 py-0.5 rounded">
                      {n.deliveryStatus}
                    </span>
                  </div>
                </div>
                <p className="text-slate-700 leading-relaxed">{n.content}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: Approved FAQs Knowledge Base */}
      {activeTab === 'faqs' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-5">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900">
              Approved MoHAIS Passport FAQs &amp; Operational Knowledge Base
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Verified immigration procedures used by the AI Guidance Assistant
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {APPROVED_FAQS.map((faq) => (
              <div key={faq.id} className="p-4 rounded-lg border border-slate-200 bg-slate-50/50 space-y-2 text-xs">
                <span className="text-[10px] uppercase font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  {faq.category}
                </span>
                <h4 className="font-bold text-slate-900 text-xs mt-1">{faq.question}</h4>
                <div className="text-slate-700 whitespace-pre-wrap leading-relaxed">{faq.answer}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
