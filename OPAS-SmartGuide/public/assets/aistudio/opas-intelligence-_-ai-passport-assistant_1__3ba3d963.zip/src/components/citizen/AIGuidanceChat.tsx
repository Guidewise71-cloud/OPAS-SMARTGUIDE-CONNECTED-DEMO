import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  X,
  Bot,
  User,
  Shield,
  HelpCircle,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  ChevronRight,
  RefreshCw,
} from 'lucide-react';
import { PassportApplication } from '../../types/passport';

interface AIGuidanceChatProps {
  isOpen: boolean;
  onClose: () => void;
  activeApplication?: PassportApplication;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  audioBase64?: string;
}

const QUICK_PROMPTS = [
  'Contact information format rules (+260 & email)',
  'How do I fix my reverted application?',
  'Why is my case Paid-but-Unsubmitted?',
  'What are the passport photo requirements?',
  'How much is a 32-page vs 48-page passport?',
  'What documents are needed for first-time applicants?',
];

export const AIGuidanceChat: React.FC<AIGuidanceChatProps> = ({
  isOpen,
  onClose,
  activeApplication,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      sender: 'assistant',
      text: activeApplication
        ? `Hello! I am your MoHAIS OPAS Assistant. I am tracking application #${activeApplication.trackingNumber} (${activeApplication.status}). How can I help make your passport journey faster and easier today?`
        : 'Welcome to the Ministry of Home Affairs and Internal Security (MoHAIS) Passport Guidance Assistant. I can help with contact validation, outstanding steps, reverted cases, photo rules, and fee payments. How can I assist you?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [autoVoice, setAutoVoice] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Clean up audio on unmount
  useEffect(() => {
    return () => {
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Voice playback handler (Gemini TTS with browser fallback)
  const handlePlayVoice = async (msgId: string, text: string, audioBase64?: string) => {
    // If currently speaking this message, pause
    if (isSpeaking === msgId) {
      if (audioPlayerRef.current) audioPlayerRef.current.pause();
      if ('speechSynthesis' in window) window.speechSynthesis.cancel();
      setIsSpeaking(null);
      return;
    }

    setIsSpeaking(msgId);

    try {
      let b64 = audioBase64;
      if (!b64) {
        const res = await fetch('/api/assistant/tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text, voice: 'Kore' }),
        });
        const data = await res.json();
        b64 = data.audioBase64;
      }

      if (b64) {
        const audio = new Audio(`data:audio/wav;base64,${b64}`);
        audioPlayerRef.current = audio;
        audio.onended = () => setIsSpeaking(null);
        audio.onerror = () => {
          fallbackSpeech(text, msgId);
        };
        await audio.play();
      } else {
        fallbackSpeech(text, msgId);
      }
    } catch {
      fallbackSpeech(text, msgId);
    }
  };

  const fallbackSpeech = (text: string, msgId: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text.replace(/[\*\_#`]/g, '').substring(0, 300));
      utterance.rate = 1.0;
      utterance.onend = () => setIsSpeaking(null);
      utterance.onerror = () => setIsSpeaking(null);
      window.speechSynthesis.speak(utterance);
    } else {
      setIsSpeaking(null);
    }
  };

  // Microphone Voice Input (Speech Recognition)
  const handleToggleMic = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setMessages((prev) => [
        ...prev,
        {
          id: `sys-${Date.now()}`,
          sender: 'assistant',
          text: 'Speech recognition is not supported by your current browser. You can type your message in the chat box below.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => setIsListening(true);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          setInput(transcript);
          handleSend(transcript);
        }
        setIsListening(false);
      };
      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);

      recognition.start();
    } catch (err) {
      console.error(err);
      setIsListening(false);
    }
  };

  const handleSend = async (messageText: string) => {
    if (!messageText.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: messageText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/assistant/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: messageText,
          history: messages.map((m) => ({ sender: m.sender, text: m.text })),
          contextData: activeApplication
            ? {
                applicantName: activeApplication.fullName,
                trackingNumber: activeApplication.trackingNumber,
                applicationStatus: activeApplication.status,
                reversionReason: activeApplication.reversionReason,
              }
            : {},
        }),
      });

      const data = await response.json();
      const botText = data.reply || 'Thank you for reaching out. Please check your application status on OPAS.';
      const botMsgId = `bot-${Date.now()}`;

      const botMsg: ChatMessage = {
        id: botMsgId,
        sender: 'assistant',
        text: botText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMsg]);

      // If autoVoice is enabled, automatically speak the answer
      if (autoVoice) {
        handlePlayVoice(botMsgId, botText);
      }
    } catch (err) {
      console.error(err);
      const fallbackMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        sender: 'assistant',
        text: 'For detailed guidance, you can also consult the official MoHAIS Passport Helpdesk at Makishi Road, Lusaka or call +260 211 252 649.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-300 overflow-hidden flex flex-col h-[580px] animate-in fade-in slide-in-from-bottom-4 duration-200">
      {/* Header */}
      <div className="bg-emerald-900 text-white p-3.5 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-emerald-700 flex items-center justify-center text-emerald-100 shadow-xs">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold">MoHAIS Passport Assistant</span>
              <span className="text-[10px] bg-emerald-800 text-emerald-200 px-1.5 py-0.2 rounded font-mono">
                Voice &amp; AI
              </span>
            </div>
            <p className="text-[11px] text-emerald-200/80">
              Assisted Guidance · Contact Validation · Reversion Support
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          {/* Auto voice toggle */}
          <button
            onClick={() => setAutoVoice(!autoVoice)}
            className={`p-1.5 rounded transition-colors cursor-pointer ${
              autoVoice ? 'text-emerald-200 bg-emerald-800' : 'text-emerald-400/60 hover:text-emerald-200'
            }`}
            title={autoVoice ? 'Auto-voice speech: ON' : 'Auto-voice speech: OFF'}
          >
            {autoVoice ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          <button
            onClick={onClose}
            className="text-emerald-300 hover:text-white p-1 rounded hover:bg-emerald-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Active Application Context Pill */}
      {activeApplication && (
        <div className="bg-emerald-50 px-3 py-1.5 border-b border-emerald-100 text-[11px] text-emerald-900 flex items-center justify-between">
          <span>
            Active Case: <strong>{activeApplication.trackingNumber}</strong> ({activeApplication.status})
          </span>
          <span className="text-emerald-700 font-semibold">{activeApplication.fullName}</span>
        </div>
      )}

      {/* Chat Messages */}
      <div className="flex-1 p-3.5 overflow-y-auto space-y-3 bg-slate-50 text-xs">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex items-start gap-2 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {m.sender === 'assistant' && (
              <div className="w-6 h-6 rounded-full bg-emerald-800 text-white flex items-center justify-center shrink-0 mt-0.5 text-[10px] font-bold">
                OPAS
              </div>
            )}
            <div
              className={`max-w-[85%] rounded-xl p-3 shadow-xs relative group ${
                m.sender === 'user'
                  ? 'bg-emerald-800 text-white rounded-br-xs'
                  : 'bg-white text-slate-800 border border-slate-200 rounded-bl-xs'
              }`}
            >
              <div className="whitespace-pre-wrap leading-relaxed">{m.text}</div>

              <div className="flex items-center justify-between mt-1.5 pt-1 border-t border-black/5">
                {m.sender === 'assistant' ? (
                  <button
                    onClick={() => handlePlayVoice(m.id, m.text, m.audioBase64)}
                    className="text-[10px] text-emerald-700 hover:text-emerald-900 font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    {isSpeaking === m.id ? (
                      <>
                        <VolumeX className="w-3 h-3 text-red-600 animate-pulse" />
                        <span className="text-red-600">Stop Speech</span>
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-3 h-3 text-emerald-600" />
                        <span>Listen to Reply</span>
                      </>
                    )}
                  </button>
                ) : (
                  <div></div>
                )}
                <span
                  className={`text-[9px] ${
                    m.sender === 'user' ? 'text-emerald-200' : 'text-slate-400'
                  }`}
                >
                  {m.timestamp}
                </span>
              </div>
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex items-center gap-2 text-slate-500 text-xs py-2">
            <div className="w-6 h-6 rounded-full bg-emerald-800 text-white flex items-center justify-center shrink-0 text-[10px]">
              ...
            </div>
            <div className="bg-white border border-slate-200 rounded-xl px-3 py-2 text-slate-500 italic">
              Consulting MoHAIS passport knowledge base...
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts */}
      <div className="p-2 bg-white border-t border-slate-100 overflow-x-auto whitespace-nowrap flex gap-1.5 scrollbar-thin">
        {QUICK_PROMPTS.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(prompt)}
            className="text-[11px] bg-slate-100 hover:bg-emerald-50 text-slate-700 hover:text-emerald-900 border border-slate-200 hover:border-emerald-300 px-2.5 py-1 rounded-full shrink-0 transition-colors cursor-pointer"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Input Box with Voice Mic */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend(input);
        }}
        className="p-3 bg-white border-t border-slate-200 flex items-center gap-2"
      >
        <button
          type="button"
          onClick={handleToggleMic}
          className={`p-2 rounded-lg transition-colors cursor-pointer ${
            isListening
              ? 'bg-red-600 text-white animate-pulse'
              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
          }`}
          title={isListening ? 'Listening to voice...' : 'Speak your question (Microphone)'}
        >
          {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
        </button>

        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={isListening ? 'Listening... speak now' : 'Ask a question or speak your issue...'}
          className="flex-1 text-xs px-3 py-2 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-emerald-500 bg-white"
        />
        <button
          type="submit"
          disabled={!input.trim() || loading}
          className="p-2 rounded-lg bg-emerald-800 text-white hover:bg-emerald-900 disabled:opacity-40 transition-colors cursor-pointer"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
