/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { AuthPortal } from './components/auth/AuthPortal';
import { OfficerDashboard } from './components/officer/OfficerDashboard';
import { CitizenPortal } from './components/citizen/CitizenPortal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AIGuidanceChat } from './components/citizen/AIGuidanceChat';
import { INITIAL_APPLICATIONS } from './data/mockApplications';
import { INITIAL_USERS } from './data/mockUsers';
import { PassportApplication, NotificationLog } from './types/passport';
import { UserAccount } from './types/auth';
import { Shield, Sparkles } from 'lucide-react';

export default function App() {
  const [users, setUsers] = useState<UserAccount[]>(INITIAL_USERS);
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(INITIAL_USERS[4]); // Mutinta Mweetwa (citizen) by default, or can log out anytime
  const [currentView, setCurrentView] = useState<'citizen' | 'officer' | 'admin'>('citizen');
  const [applications, setApplications] = useState<PassportApplication[]>(INITIAL_APPLICATIONS);
  const [selectedApplicationId, setSelectedApplicationId] = useState<string>('app-002');
  const [isAssistantOpen, setIsAssistantOpen] = useState(false);

  const selectedApplication =
    applications.find((a) => a.id === selectedApplicationId) || applications[0];

  // Auth Handlers
  const handleLogin = (user: UserAccount) => {
    setCurrentUser(user);
    if (user.role === 'admin') {
      setCurrentView('admin');
    } else if (user.role === 'officer') {
      setCurrentView('officer');
    } else {
      setCurrentView('citizen');
      // If citizen has existing application by NRC or email, set as active
      const citizenApp = applications.find(
        (a) =>
          (user.nrcNumber && a.nrcNumber === user.nrcNumber) ||
          a.contact.email.toLowerCase() === user.email.toLowerCase()
      );
      if (citizenApp) {
        setSelectedApplicationId(citizenApp.id);
      }
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };

  const handleRegisterCitizen = (newCitizen: UserAccount) => {
    setUsers((prev) => [newCitizen, ...prev]);
  };

  // Admin Officer Provisioning Handlers
  const handleAddOfficer = (newOfficer: UserAccount) => {
    setUsers((prev) => [newOfficer, ...prev]);
  };

  const handleUpdateOfficerStatus = (userId: string, newStatus: 'ACTIVE' | 'SUSPENDED') => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, status: newStatus } : u))
    );
  };

  const handleResetPassword = (userId: string, newPass: string) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, password: newPass } : u))
    );
  };

  // Application Updates
  const handleUpdateStatus = (
    id: string,
    newStatus: PassportApplication['status'],
    notes?: string
  ) => {
    setApplications((prev) =>
      prev.map((app) => {
        if (app.id === id) {
          return {
            ...app,
            status: newStatus,
            officerNotes: notes || app.officerNotes,
            daysInStatus: 0,
            lastUpdated: new Date().toISOString(),
          };
        }
        return app;
      })
    );
  };

  const handleAddNotification = (id: string, notif: NotificationLog) => {
    setApplications((prev) =>
      prev.map((app) => {
        if (app.id === id) {
          return {
            ...app,
            notifications: [notif, ...app.notifications],
            lastUpdated: new Date().toISOString(),
          };
        }
        return app;
      })
    );
  };

  const handleAddNewApplication = (newApp: PassportApplication) => {
    setApplications((prev) => [newApp, ...prev]);
    setSelectedApplicationId(newApp.id);
  };

  const handleSelectScenario = (scenarioId: string) => {
    setSelectedApplicationId(scenarioId);
    // If switching scenario while in citizen view, align demo user
    if (scenarioId === 'app-002') {
      const mutinta = users.find((u) => u.email === 'mutinta.mweetwa@gmail.com');
      if (mutinta && currentUser?.role === 'citizen') setCurrentUser(mutinta);
    } else if (scenarioId === 'app-001') {
      const kondwani = users.find((u) => u.email === 'k.phiri@outlook.com');
      if (kondwani && currentUser?.role === 'citizen') setCurrentUser(kondwani);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans">
      {/* Official MoHAIS Top Header */}
      <Header
        currentUser={currentUser}
        currentView={currentView}
        onViewChange={(view) => setCurrentView(view)}
        onOpenAssistant={() => setIsAssistantOpen(true)}
        onSelectScenario={handleSelectScenario}
        activeScenarioId={selectedApplicationId}
        onLogout={handleLogout}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-8 py-6">
        {!currentUser ? (
          /* Single Unified Login & Citizen Account Creation Portal */
          <AuthPortal
            users={users}
            onLogin={handleLogin}
            onRegisterCitizen={handleRegisterCitizen}
          />
        ) : currentView === 'admin' ? (
          /* MoHAIS Administrator Dashboard (Officer Provisioning & System Management) */
          <AdminDashboard
            users={users}
            onAddOfficer={handleAddOfficer}
            onUpdateOfficerStatus={handleUpdateOfficerStatus}
            onResetPassword={handleResetPassword}
            onViewOfficerConsole={() => setCurrentView('officer')}
          />
        ) : currentView === 'officer' ? (
          /* Passport Officer Operational Console */
          <OfficerDashboard
            applications={applications}
            onUpdateStatus={handleUpdateStatus}
            onAddNotification={handleAddNotification}
            onSelectApplication={(app) => {
              setSelectedApplicationId(app.id);
              setCurrentView('citizen');
            }}
            selectedAppForCitizenView={selectedApplication}
            onOpenAssistant={() => setIsAssistantOpen(true)}
          />
        ) : (
          /* Citizen Portal */
          <CitizenPortal
            applications={applications}
            selectedApplication={selectedApplication}
            onSelectApplication={(app) => setSelectedApplicationId(app.id)}
            onUpdateStatus={handleUpdateStatus}
            onAddNewApplication={handleAddNewApplication}
            onOpenAssistant={() => setIsAssistantOpen(true)}
            onAddNotification={handleAddNotification}
          />
        )}
      </main>

      {/* Floating 24/7 AI Guidance Assistant Widget */}
      <AIGuidanceChat
        isOpen={isAssistantOpen}
        onClose={() => setIsAssistantOpen(false)}
        activeApplication={selectedApplication}
      />

      {/* Floating Action Button for Assistant (when closed) */}
      {!isAssistantOpen && (
        <button
          onClick={() => setIsAssistantOpen(true)}
          className="fixed bottom-5 right-5 z-40 bg-emerald-800 hover:bg-emerald-900 text-white rounded-full p-3.5 shadow-xl flex items-center gap-2 text-xs font-bold transition-transform hover:scale-105 cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-emerald-300" />
          <span>MoHAIS Assistant</span>
        </button>
      )}

      {/* Official Government Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded bg-emerald-800 flex items-center justify-center text-white">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <span className="font-semibold text-slate-800">
                Republic of Zambia · Ministry of Home Affairs and Internal Security (MoHAIS)
              </span>
              <p className="text-[11px] text-slate-400">
                Online Passport Application System (OPAS) Enhancement Pilot · UNIPODS AI for Public Good Challenge
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs text-slate-600">
            <span>Passport Office, Makishi Road, Lusaka</span>
            <span aria-hidden="true">·</span>
            <span>Support: +260 211 252 649</span>
            <span aria-hidden="true">·</span>
            <span>opas-support@mohais.gov.zm</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
