export type ApplicationStatus =
  | 'Draft'
  | 'Paid - Unsubmitted'
  | 'Submitted - Under Review'
  | 'Reverted'
  | 'Biometrics Scheduled'
  | 'Processing & Printing'
  | 'Ready for Collection'
  | 'Completed';

export type PassportType = '32-Page Ordinary' | '48-Page Frequent Traveler' | 'Diplomatic' | 'Official';

export type ServiceSpeed = 'Standard (14-21 days)' | 'Express Expedited (3-5 days)';

export interface ContactInfo {
  phone: string;
  phoneCountryCode: string;
  email: string;
  residentialAddress: string;
  district: string;
  province: string;
}

export interface GuarantorInfo {
  fullName: string;
  nrcNumber: string;
  profession: string;
  phoneNumber: string;
  organization: string;
  verified: boolean;
}

export interface UploadedDocument {
  id: string;
  name: string;
  type: 'Passport Photo' | 'National Registration Card (NRC)' | 'Birth Certificate' | 'Guarantor Form' | 'Police Report' | 'Consent Letter';
  fileUrl?: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'WARNING';
  uploadedAt: string;
  feedback?: string;
  aiScore?: number;
}

export interface NotificationLog {
  id: string;
  timestamp: string;
  channel: 'SMS' | 'Email' | 'OPAS Message Board';
  subject?: string;
  content: string;
  deliveryStatus: 'Sent' | 'Delivered' | 'Read' | 'Action Taken';
  actionTakenAt?: string;
}

export interface PassportApplication {
  id: string;
  trackingNumber: string; // e.g., ZAM-OPAS-2026-8492
  nrcNumber: string; // format: 123456/78/1
  fullName: string;
  dateOfBirth: string;
  gender: 'Male' | 'Female';
  placeOfBirth: string;
  passportType: PassportType;
  serviceSpeed: ServiceSpeed;
  feeAmount: number;
  feePaid: boolean;
  paymentReference?: string;
  paidAt?: string;
  status: ApplicationStatus;
  daysInStatus: number;
  reversionReason?: string;
  revertedItems?: string[];
  revertedAt?: string;
  contact: ContactInfo;
  guarantor: GuarantorInfo;
  documents: UploadedDocument[];
  notifications: NotificationLog[];
  officerNotes?: string;
  lastUpdated: string;
  biometricsDate?: string;
  collectionOffice: string;
  isUrgent?: boolean;
}

export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
  warnings: Record<string, string>;
  suggestions: Record<string, string>;
}

export interface AITriageAnalysis {
  urgencyLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  rootCauseAnalysis: string;
  recommendedAction: string;
  channelRecommendation: 'SMS' | 'EMAIL' | 'DIRECT_CALL' | 'AUTO_BOARD';
  slaAgingAlert: boolean;
  dataIntegrityScore: number;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  audioBase64?: string;
}
