import { ContactInfo, ValidationResult } from '../types/passport';

/**
 * Validates Zambian National Registration Card (NRC) format
 * Format: 6 digits / 2 digits / 1 digit (e.g. 294812/11/1)
 */
export function validateNRC(nrc: string): { isValid: boolean; message?: string } {
  if (!nrc || nrc.trim() === '') {
    return { isValid: false, message: 'NRC number is required.' };
  }
  const clean = nrc.trim();
  const nrcRegex = /^\d{6}\/\d{2}\/\d{1}$/;
  if (!nrcRegex.test(clean)) {
    return {
      isValid: false,
      message: 'Format must be 6 digits / 2 digits / 1 digit (e.g., 294812/11/1).',
    };
  }
  return { isValid: true };
}

/**
 * Common typo domains for email validation
 */
const COMMON_EMAIL_TYPOS: Record<string, string> = {
  'gamil.com': 'gmail.com',
  'gmial.com': 'gmail.com',
  'gmaill.com': 'gmail.com',
  'yaho.com': 'yahoo.com',
  'yahooo.com': 'yahoo.com',
  'hotmial.com': 'hotmail.com',
  'outlok.com': 'outlook.com',
};

/**
 * Validates Email Address with typo detection
 */
export function validateEmail(email: string): { isValid: boolean; warning?: string; error?: string } {
  if (!email || email.trim() === '') {
    return { isValid: false, error: 'Email address is required for official status updates.' };
  }
  const clean = email.trim().toLowerCase();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(clean)) {
    return { isValid: false, error: 'Please enter a valid email format (e.g., name@domain.com).' };
  }

  const parts = clean.split('@');
  const domain = parts[1];
  if (COMMON_EMAIL_TYPOS[domain]) {
    return {
      isValid: true,
      warning: `Did you mean @${COMMON_EMAIL_TYPOS[domain]} instead of @${domain}?`,
    };
  }

  return { isValid: true };
}

/**
 * Validates Phone number with country code and E.164 rules
 * Standard Zambian numbers: +260 97X XXXXXX, +260 96X XXXXXX, +260 95X XXXXXX, +260 76X XXXXXX, +260 77X XXXXXX
 */
export function validatePhoneNumber(phone: string, countryCode: string = '+260'): {
  isValid: boolean;
  formatted: string;
  error?: string;
  warning?: string;
} {
  if (!phone || phone.trim() === '') {
    return { isValid: false, formatted: phone, error: 'Phone number is required for SMS delivery updates.' };
  }

  let clean = phone.replace(/[\s\-\(\)]/g, '');

  // Detect national format starting with 0
  if (clean.startsWith('0')) {
    // Strip leading 0 and prepend country code
    const withoutZero = clean.substring(1);
    const corrected = `${countryCode}${withoutZero}`;
    return {
      isValid: true,
      formatted: corrected,
      warning: `Entered local format (0...). Converted to standard international format: ${corrected}`,
    };
  }

  // If already starts with +
  if (clean.startsWith('+')) {
    if (clean.length < 10 || clean.length > 15) {
      return { isValid: false, formatted: clean, error: 'International phone numbers must be between 10 and 15 digits.' };
    }
    return { isValid: true, formatted: clean };
  }

  // If no prefix, assume country code
  const formattedWithCode = `${countryCode}${clean}`;
  return {
    isValid: true,
    formatted: formattedWithCode,
    warning: `Country code ${countryCode} auto-prepended: ${formattedWithCode}`,
  };
}

/**
 * Comprehensive Contact Information Validator
 */
export function validateContactInfo(contact: ContactInfo): ValidationResult {
  const errors: Record<string, string> = {};
  const warnings: Record<string, string> = {};
  const suggestions: Record<string, string> = {};

  const emailRes = validateEmail(contact.email);
  if (emailRes.error) errors.email = emailRes.error;
  if (emailRes.warning) warnings.email = emailRes.warning;

  const phoneRes = validatePhoneNumber(contact.phone, contact.phoneCountryCode || '+260');
  if (phoneRes.error) errors.phone = phoneRes.error;
  if (phoneRes.warning) warnings.phone = phoneRes.warning;

  if (!contact.residentialAddress || contact.residentialAddress.trim().length < 5) {
    errors.residentialAddress = 'Please enter a complete residential address including street or plot number.';
  }

  if (!contact.district || contact.district.trim() === '') {
    errors.district = 'District is required.';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
    warnings,
    suggestions,
  };
}
