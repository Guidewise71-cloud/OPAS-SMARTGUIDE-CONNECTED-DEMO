import React, { useState, useEffect } from 'react';
import {
  Search,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Sparkles,
  Upload,
  ArrowRight,
  Shield,
  FileText,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Send,
  MessageSquare,
  HelpCircle,
  PlusCircle,
  RefreshCw,
  Eye,
  Smartphone,
  Settings,
  CheckCheck,
  Bot,
  Sliders,
  Bell,
  Lock,
  Globe,
  Volume2,
  CreditCard,
  Camera,
} from 'lucide-react';
import { PassportApplication, NotificationLog, UploadedDocument } from '../../types/passport';
import { APPROVED_FAQS } from '../../data/faqs';
import { ApplicationForm } from './ApplicationForm';
import { PillarsModule } from '../common/PillarsModule';
import { DocumentViewerModal } from '../common/DocumentViewerModal';
import { CitizenPhoneSimulatorModal } from '../common/CitizenPhoneSimulatorModal';
import { BiometricsSchedulerModal } from './BiometricsSchedulerModal';
import { AIGuidanceChat } from './AIGuidanceChat';
import { useChat } from '../../context/ChatContext';
import { validatePhoneNumber, validateEmail, validateNRC } from '../../utils/validation';
import { CaseDetailsForm, CaseDetailsState } from '../common/CaseDetailsForm';

interface CitizenPortalProps {
  applications: PassportApplication[];
  selectedApplication: PassportApplication;
  onSelectApplication: (app: PassportApplication) => void;
  onUpdateStatus: (id: string, newStatus: PassportApplication['status'], notes?: string) => void;
  onAddNewApplication: (newApp: PassportApplication) => void;
  onOpenAssistant: () => void;
  onAddNotification?: (id: string, notif: NotificationLog) => void;
}

export const CitizenPortal: React.FC<CitizenPortalProps> = ({
  applications,
  selectedApplication,
  onSelectApplication,
  onUpdateStatus,
  onAddNewApplication,
  onOpenAssistant,
  onAddNotification,
}) => {
  const [activeTab, setActiveTab] = useState<'status' | 'guidance' | 'checker' | 'settings' | 'pillars' | 'apply' | 'messages' | 'faqs'>('status');
  const [searchTracking, setSearchTracking] = useState('');
  const [reuploading, setReuploading] = useState(false);
  const [reuploadSuccess, setReuploadSuccess] = useState(false);
  const [aiPreCheckScore, setAiPreCheckScore] = useState<number | null>(null);
  const [inspectedDoc, setInspectedDoc] = useState<UploadedDocument | null>(null);
  const [isPhoneSimOpen, setIsPhoneSimOpen] = useState(false);
  const [isBiometricsModalOpen, setIsBiometricsModalOpen] = useState(false);

  // Settings State
  const [smsAlertsEnabled, setSmsAlertsEnabled] = useState(true);
  const [emailAlertsEnabled, setEmailAlertsEnabled] = useState(true);
  const [boardAlertsEnabled, setBoardAlertsEnabled] = useState(true);
  const [preferredLanguage, setPreferredLanguage] = useState<'English' | 'Bemba' | 'Nyanja' | 'Tonga'>('English');
  const [dataConsent, setDataConsent] = useState(true);
  const [settingsSavedNotice, setSettingsSavedNotice] = useState(false);

  // Details Checker State
  const [checkerPhone, setCheckerPhone] = useState(selectedApplication.contact.phone);
  const [checkerEmail, setCheckerEmail] = useState(selectedApplication.contact.email);
  const [checkerNotice, setCheckerNotice] = useState<string | null>(null);
  const [quickActionNotice, setQuickActionNotice] = useState<string | null>(null);

  const { setIsGuidanceScreen, setActiveApplication, autoVoice, setAutoVoice, setCurrentSection, populateQuery } = useChat();

  const handleQuickAction = (label: string, query: string) => {
    setQuickActionNotice(`Loaded "${label}" into AI Assistant`);
    populateQuery(query);
    setTimeout(() => {
      setQuickActionNotice(null);
    }, 4000);
  };

  // Inform ChatContext whether user is on full-width guidance screen and update currently navigating section
  useEffect(() => {
    setIsGuidanceScreen(activeTab === 'guidance');
    const tabToSection: Record<string, string> = {
      status: 'Dashboard',
      apply: 'My Applications',
      checker: 'Details Checker',
      settings: 'Settings',
      guidance: 'AI Guidance',
      messages: 'Messages & Notifications',
      faqs: 'FAQs & Help',
      pillars: 'Smart Features',
    };
    setCurrentSection(tabToSection[activeTab] || 'Dashboard');
  }, [activeTab, setIsGuidanceScreen, setCurrentSection]);

  // Keep activeApplication in sync
  useEffect(() => {
    setActiveApplication(selectedApplication);
    setCheckerPhone(selectedApplication.contact.phone);
    setCheckerEmail(selectedApplication.contact.email);
  }, [selectedApplication, setActiveApplication]);

  // Real-time validations for Details Checker
  const phoneValidation = validatePhoneNumber(checkerPhone, selectedApplication.contact.phoneCountryCode || '+260');
  const emailValidation = validateEmail(checkerEmail);
  const nrcValidation = validateNRC(selectedApplication.nrcNumber);

  // Stepper helper
  const getStageIndex = (status: PassportApplication['status']) => {
    switch (status) {
      case 'Draft':
        return 1;
      case 'Paid - Unsubmitted':
        return 2;
      case 'Submitted - Under Review':
        return 3;
      case 'Reverted':
        return 2.5; // flagged between review & submit
      case 'Biometrics Scheduled':
        return 4;
      case 'Processing & Printing':
        return 5;
      case 'Ready for Collection':
      case 'Completed':
        return 6;
      default:
        return 1;
    }
  };

  const currentStageNum = getStageIndex(selectedApplication.status);

  // Re-upload corrected document for reverted case
  const handleSimulateReupload = () => {
    setReuploading(true);
    setTimeout(() => {
      setAiPreCheckScore(97);
      setReuploadSuccess(true);
      setReuploading(false);

      setTimeout(() => {
        onUpdateStatus(
          selectedApplication.id,
          'Submitted - Under Review',
          'Applicant uploaded corrected photo via OPAS Citizen Assistant. Passed AI pre-flight check.'
        );
        setReuploadSuccess(false);
      }, 1500);
    }, 1000);
  };

  // Complete submission for paid unsubmitted case
  const handleFinalizePaidSubmit = () => {
    onUpdateStatus(
      selectedApplication.id,
      'Submitted - Under Review',
      'Applicant completed final submission step after automated reminder.'
    );
  };

  // Apply auto-fix in Details Checker
  const handleApplyDetailsFix = () => {
    if (phoneValidation.isValid) {
      selectedApplication.contact.phone = phoneValidation.formatted;
      setCheckerPhone(phoneValidation.formatted);
    }
    const cleanEmail = checkerEmail.replace('@gamil.com', '@gmail.com').replace('@outlok.com', '@outlook.com').replace('@yaho.com', '@yahoo.com');
    selectedApplication.contact.email = cleanEmail;
    setCheckerEmail(cleanEmail);

    setCheckerNotice('Contact details verified and normalized across OPAS.');
    setTimeout(() => setCheckerNotice(null), 3500);
  };

  const handleSaveVerifiedCaseDetails = (details: CaseDetailsState) => {
    selectedApplication.contact.province = details.province;
    selectedApplication.contact.district = details.district;
    selectedApplication.collectionOffice = details.interviewLocation;
    setCheckerNotice('Official Case Details successfully verified & synchronized with passport registry.');
    setTimeout(() => setCheckerNotice(null), 3500);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsSavedNotice(true);
    setTimeout(() => setSettingsSavedNotice(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Subheader & Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            OPAS Citizen Passport Services
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Ministry of Home Affairs &amp; Internal Security &bull; Self-Service &amp; Application Tracking
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Main Citizen Navigation Bar */}
          <div className="flex flex-wrap items-center bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs font-semibold gap-1">
            <button
              onClick={() => setActiveTab('status')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                activeTab === 'status'
                  ? 'bg-white text-emerald-900 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Dashboard
            </button>

            {/* AI Guidance Tab (Full-Width Chat Screen) */}
            <button
              onClick={() => setActiveTab('guidance')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'guidance'
                  ? 'bg-emerald-800 text-white shadow-xs font-bold'
                  : 'text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI Guidance</span>
            </button>

            {/* Details Checker Screen */}
            <button
              onClick={() => setActiveTab('checker')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'checker'
                  ? 'bg-white text-emerald-900 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <CheckCheck className="w-3.5 h-3.5 text-blue-600" />
              <span>Details Checker</span>
            </button>

            {/* Settings & Preferences Screen */}
            <button
              onClick={() => setActiveTab('settings')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'settings'
                  ? 'bg-white text-emerald-900 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Settings className="w-3.5 h-3.5 text-slate-500" />
              <span>Settings</span>
            </button>

            <button
              onClick={() => setActiveTab('pillars')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer hidden md:flex items-center gap-1.5 ${
                activeTab === 'pillars'
                  ? 'bg-white text-emerald-900 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>Smart Features</span>
            </button>

            <button
              onClick={() => setActiveTab('apply')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'apply'
                  ? 'bg-white text-emerald-900 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>My Applications</span>
            </button>

            <button
              onClick={() => setActiveTab('messages')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer flex items-center gap-1 ${
                activeTab === 'messages'
                  ? 'bg-white text-emerald-900 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>Messages</span>
              {selectedApplication.notifications.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  {selectedApplication.notifications.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('faqs')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                activeTab === 'faqs'
                  ? 'bg-white text-emerald-900 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              FAQs
            </button>
          </div>
        </div>
      </div>

      {/* =========================================================================
          SCREEN 1: THE GUIDANCE SCREEN (FULL-WIDTH CHAT, NO DUPLICATE FLOATING BUTTON)
         ========================================================================= */}
      {activeTab === 'guidance' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-700" />
                24/7 AI Passport Guidance Assistant Console
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Full-width interactive chat grounded in official MoHAIS immigration policies, with voice synthesis and real-time case context.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 font-semibold flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-emerald-600" />
                <span>Conversation Sync Active</span>
              </span>
            </div>
          </div>

          {/* Full-width AI Assistant Component sharing exact same ChatContext */}
          <AIGuidanceChat isFullWidth={true} onNavigateToTab={(tab) => setActiveTab(tab as any)} />
        </div>
      )}

      {/* =========================================================================
          SCREEN 2: THE DETAILS CHECKER SCREEN (CONTACT & APPLICATION DATA VALIDATION)
         ========================================================================= */}
      {activeTab === 'checker' && (
        <div className="space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
                <CheckCheck className="w-4 h-4 text-blue-700" />
                Contact &amp; Application Details Integrity Checker
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Flags invalid phone formats, email typos, and document inconsistencies before application submission or communication dispatch.
              </p>
            </div>
            <button
              onClick={handleApplyDetailsFix}
              className="px-3.5 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Normalize &amp; Save Verified Details</span>
            </button>
          </div>

          {checkerNotice && (
            <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl text-xs text-emerald-900 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{checkerNotice}</span>
            </div>
          )}

          {/* Validation Analysis Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Phone Checker */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 uppercase flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-emerald-700" />
                  Mobile Phone Format
                </span>
                {phoneValidation.isValid && !phoneValidation.warning ? (
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded">
                    E.164 Valid
                  </span>
                ) : (
                  <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
                    Needs Attention
                  </span>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Mobile Number (With +260 code):
                </label>
                <input
                  type="text"
                  value={checkerPhone}
                  onChange={(e) => setCheckerPhone(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-lg font-mono bg-white focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              {phoneValidation.warning && (
                <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-800 flex items-start gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                  <span>{phoneValidation.warning}</span>
                </div>
              )}
              {phoneValidation.error && (
                <div className="p-2.5 bg-red-50 border border-red-200 rounded-lg text-[11px] text-red-700 flex items-start gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-red-600 shrink-0 mt-0.5" />
                  <span>{phoneValidation.error}</span>
                </div>
              )}
              {phoneValidation.isValid && !phoneValidation.warning && (
                <p className="text-[11px] text-emerald-700 font-medium">
                  Verified Zambian standard: {phoneValidation.formatted}
                </p>
              )}
            </div>

            {/* Email Checker */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 uppercase flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-emerald-700" />
                  Email Address Syntax
                </span>
                {emailValidation.isValid && !emailValidation.warning ? (
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded">
                    RFC Valid
                  </span>
                ) : (
                  <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
                    Typo Detected
                  </span>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Email for Status &amp; Appointment Slips:
                </label>
                <input
                  type="email"
                  value={checkerEmail}
                  onChange={(e) => setCheckerEmail(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-lg bg-white focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              {emailValidation.warning && (
                <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-800 flex items-start gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                  <span>{emailValidation.warning}</span>
                </div>
              )}
              {emailValidation.error && (
                <div className="p-2.5 bg-red-50 border border-red-200 rounded-lg text-[11px] text-red-700 flex items-start gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-red-600 shrink-0 mt-0.5" />
                  <span>{emailValidation.error}</span>
                </div>
              )}
              {emailValidation.isValid && !emailValidation.warning && (
                <p className="text-[11px] text-emerald-700 font-medium">
                  Valid syntax &amp; verified domain.
                </p>
              )}
            </div>

            {/* Green NRC Checker */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 uppercase flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-emerald-700" />
                  Green NRC Identity Syntax
                </span>
                {nrcValidation.isValid ? (
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded">
                    Verified Format
                  </span>
                ) : (
                  <span className="text-[10px] bg-red-100 text-red-800 font-bold px-1.5 py-0.5 rounded">
                    Invalid Format
                  </span>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  National Registration Number:
                </label>
                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-mono text-xs font-bold text-slate-900">
                  {selectedApplication.nrcNumber}
                </div>
              </div>

              <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-[11px] text-emerald-800">
                Format matches Zambian national standard: 6 digits / 2 digits / 1 digit.
              </div>
            </div>
          </div>

          {/* Official Case Details Intake Verification Card (Matching Official MoHAIS Registration) */}
          <CaseDetailsForm
            application={selectedApplication}
            mode="verification"
            onSaveVerification={handleSaveVerifiedCaseDetails}
          />

          {/* Document Optical Integrity Checklist */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                  Dossier Documents Optical Pre-Check Summary
                </h4>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Click any document below to inspect dimensions (45x35mm), background uniformity, and officer feedback.
                </p>
              </div>
            </div>

            <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden text-xs">
              {selectedApplication.documents.map((doc) => (
                <div
                  key={doc.id}
                  onClick={() => setInspectedDoc(doc)}
                  className="p-3.5 flex items-center justify-between gap-3 hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-800 flex items-center justify-center shrink-0 border border-emerald-200">
                      <FileText className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-semibold text-slate-900 flex items-center gap-2">
                        <span>{doc.name}</span>
                        <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded font-medium flex items-center gap-1">
                          <Eye className="w-3 h-3" /> Inspect Document
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        Type: {doc.type} &bull; Uploaded: {new Date(doc.uploadedAt).toLocaleDateString()}
                      </div>
                      {doc.feedback && (
                        <div className="text-[11px] text-red-600 mt-1 font-medium bg-red-50 p-1 rounded">
                          {doc.feedback}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    {doc.aiScore && (
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 uppercase block font-semibold">Optical Quality</span>
                        <span className={`font-mono font-bold text-xs ${doc.aiScore >= 80 ? 'text-emerald-700' : 'text-red-700'}`}>
                          {doc.aiScore}/100
                        </span>
                      </div>
                    )}
                    <span
                      className={`text-xs font-semibold px-2 py-0.5 rounded ${
                        doc.status === 'APPROVED'
                          ? 'bg-emerald-100 text-emerald-800'
                          : doc.status === 'REJECTED'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {doc.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 3: THE SETTINGS SCREEN (COMMUNICATION PREFERENCES & DATA GOVERNANCE)
         ========================================================================= */}
      {activeTab === 'settings' && (
        <div className="space-y-5">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
                <Settings className="w-4 h-4 text-slate-700" />
                Citizen Preferences &amp; Notification Settings
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Configure your approved notification channels, audio voice assistance, and data privacy options.
              </p>
            </div>
          </div>

          {settingsSavedNotice && (
            <div className="p-3.5 bg-emerald-50 border border-emerald-300 rounded-xl text-xs text-emerald-900 flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span className="font-semibold">Preferences successfully saved to your OPAS citizen account!</span>
            </div>
          )}

          <form onSubmit={handleSaveSettings} className="space-y-5">
            {/* Notification Delivery Channels */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3 text-xs">
              <h4 className="font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
                <Bell className="w-4 h-4 text-emerald-700" />
                Approved Notification Channels
              </h4>
              <p className="text-slate-500 text-[11px]">
                Per MoHAIS EOI Section 3.4: Automated reminders follow approved communication schedules and 72-hour quiet intervals.
              </p>

              <div className="space-y-3 pt-2">
                <label className="flex items-center justify-between p-3 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer">
                  <div>
                    <span className="font-bold text-slate-900 block">SMS Status Notifications</span>
                    <span className="text-[11px] text-slate-500">
                      Direct alerts to {selectedApplication.contact.phone} for biometrics scheduling &amp; collection.
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={smsAlertsEnabled}
                    onChange={(e) => setSmsAlertsEnabled(e.target.checked)}
                    className="w-4 h-4 text-emerald-700 rounded"
                  />
                </label>

                <label className="flex items-center justify-between p-3 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer">
                  <div>
                    <span className="font-bold text-slate-900 block">Email Dossier Summaries</span>
                    <span className="text-[11px] text-slate-500">
                      Official email notices sent to {selectedApplication.contact.email} with PDF slips.
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={emailAlertsEnabled}
                    onChange={(e) => setEmailAlertsEnabled(e.target.checked)}
                    className="w-4 h-4 text-emerald-700 rounded"
                  />
                </label>

                <label className="flex items-center justify-between p-3 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer">
                  <div>
                    <span className="font-bold text-slate-900 block">OPAS Portal Message Board</span>
                    <span className="text-[11px] text-slate-500">
                      In-app official communications displayed on your personal dashboard.
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={boardAlertsEnabled}
                    onChange={(e) => setBoardAlertsEnabled(e.target.checked)}
                    className="w-4 h-4 text-emerald-700 rounded"
                  />
                </label>
              </div>
            </div>

            {/* Guidance Voice & Language Settings */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3 text-xs">
              <h4 className="font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
                <Globe className="w-4 h-4 text-emerald-700" />
                Assistant Language &amp; Speech Playback
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Preferred Language:</label>
                  <select
                    value={preferredLanguage}
                    onChange={(e) => setPreferredLanguage(e.target.value as any)}
                    className="w-full p-2.5 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="English">English (Official Government Standard)</option>
                    <option value="Bemba">IciBemba</option>
                    <option value="Nyanja">ChiNyanja</option>
                    <option value="Tonga">Chitonga</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Voice Playback:</label>
                  <label className="flex items-center gap-2 p-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={autoVoice}
                      onChange={(e) => setAutoVoice(e.target.checked)}
                      className="w-4 h-4 text-emerald-700 rounded"
                    />
                    <span className="text-slate-800 font-medium">Auto-read guidance answers with speech synthesis</span>
                  </label>
                </div>
              </div>
            </div>

            {/* Data Governance & Privacy Consent */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3 text-xs">
              <h4 className="font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
                <Lock className="w-4 h-4 text-emerald-700" />
                Data Protection &amp; Governance (EOI Section 6.1)
              </h4>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Your passport information is processed under the Ministry of Home Affairs data protection policy. Personal identification is strictly accessed by authorized vetting officers at designated passport centers.
              </p>
              <label className="flex items-center gap-2 p-2.5 rounded-lg bg-slate-50 border border-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={dataConsent}
                  onChange={(e) => setDataConsent(e.target.checked)}
                  className="w-4 h-4 text-emerald-700 rounded"
                />
                <span className="font-semibold text-slate-900">
                  I consent to automated optical pre-flight checks and SMS notification delivery.
                </span>
              </label>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                className="px-6 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-lg font-bold text-xs shadow-md transition-colors cursor-pointer"
              >
                Save Preferences
              </button>
            </div>
          </form>
        </div>
      )}

      {/* =========================================================================
          SCREEN 4: TRACK APPLICATION & RESOLUTION CENTER
         ========================================================================= */}
      {activeTab === 'status' && (
        <div className="space-y-6">
          {/* Tracker Search Box */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex-1 max-w-lg relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTracking}
                onChange={(e) => setSearchTracking(e.target.value)}
                placeholder="Enter Reference (e.g., ZAM-OPAS-2026-1592) or Green NRC..."
                className="w-full text-xs pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-emerald-500 bg-white"
              />
            </div>

            <div className="flex items-center gap-1.5 text-xs text-slate-500">
              <span className="hidden sm:inline">Try Demo Cases:</span>
              <button
                onClick={() => {
                  const m = applications.find((a) => a.id === 'app-002');
                  if (m) onSelectApplication(m);
                }}
                className="px-2 py-1 bg-red-50 text-red-700 border border-red-200 rounded font-semibold text-[11px] hover:bg-red-100 transition-colors cursor-pointer"
              >
                Reverted Case (Mutinta)
              </button>
              <button
                onClick={() => {
                  const p = applications.find((a) => a.id === 'app-001');
                  if (p) onSelectApplication(p);
                }}
                className="px-2 py-1 bg-amber-50 text-amber-800 border border-amber-200 rounded font-semibold text-[11px] hover:bg-amber-100 transition-colors cursor-pointer"
              >
                Paid Unsubmitted (Kondwani)
              </button>
              <button
                onClick={() => {
                  const r = applications.find((a) => a.id === 'app-006');
                  if (r) onSelectApplication(r);
                }}
                className="px-2 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded font-semibold text-[11px] hover:bg-emerald-100 transition-colors cursor-pointer"
              >
                Ready for Pickup (Mwamba)
              </button>
            </div>
          </div>

          {/* Quick Actions Row: Pre-populates Persistent AI Assistant */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 shadow-xs space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 border-b border-slate-100 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-emerald-800 text-emerald-100 flex items-center justify-center shadow-2xs shrink-0">
                  <Sparkles className="w-4 h-4 text-emerald-300" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
                    <span>AI Assistant Quick Actions</span>
                    <span className="text-[10px] bg-emerald-50 text-emerald-800 font-semibold px-2 py-0.5 rounded-full border border-emerald-200 hidden sm:inline">
                      1-Click Pre-populate
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Click any quick action below to open the persistent assistant with a pre-populated question tailored to case #{selectedApplication.trackingNumber}.
                  </p>
                </div>
              </div>

              {quickActionNotice && (
                <div className="text-[11px] text-emerald-900 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-lg font-medium flex items-center gap-1.5 animate-in fade-in shrink-0">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>{quickActionNotice}</span>
                </div>
              )}
            </div>

            {/* Row of Quick Actions Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
              {/* Button 1: Check Status */}
              <button
                type="button"
                onClick={() =>
                  handleQuickAction(
                    'Check Status',
                    `What is the current status of my passport application #${selectedApplication.trackingNumber} (${selectedApplication.status}), what are my estimated waiting days, and what exact step is required from me?`
                  )
                }
                className="group relative p-3 rounded-xl border border-slate-200 hover:border-emerald-500 bg-slate-50/70 hover:bg-emerald-50/50 text-left transition-all duration-150 hover:shadow-xs flex flex-col justify-between cursor-pointer"
                title="Ask AI Assistant to check current status and next actions"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center group-hover:scale-105 transition-transform">
                      <Clock className="w-4 h-4" />
                    </div>
                    <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100/70 px-1.5 py-0.2 rounded font-mono">
                      {selectedApplication.status}
                    </span>
                  </div>
                  <div className="text-xs font-bold text-slate-900 group-hover:text-emerald-900">
                    Check Status
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2 leading-snug">
                    Tracking #{selectedApplication.trackingNumber} timeline &amp; next required action
                  </p>
                </div>
                <div className="mt-2.5 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[10px] font-bold text-emerald-700 group-hover:text-emerald-800">
                  <span>Pre-populate Chat</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </button>

              {/* Button 2: Document Checklist */}
              <button
                type="button"
                onClick={() =>
                  handleQuickAction(
                    'Document Checklist',
                    `What is the official document checklist for my passport application? What are the requirements for Green NRC certification, Registrar General birth certificates, and authorized guarantor verification?`
                  )
                }
                className="group relative p-3 rounded-xl border border-slate-200 hover:border-blue-500 bg-slate-50/70 hover:bg-blue-50/50 text-left transition-all duration-150 hover:shadow-xs flex flex-col justify-between cursor-pointer"
                title="Ask AI Assistant for official document checklist"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-800 flex items-center justify-center group-hover:scale-105 transition-transform">
                      <FileText className="w-4 h-4" />
                    </div>
                    <span className="text-[10px] font-bold text-blue-800 bg-blue-100/70 px-1.5 py-0.2 rounded font-mono">
                      {selectedApplication.documents.length} Docs
                    </span>
                  </div>
                  <div className="text-xs font-bold text-slate-900 group-hover:text-blue-900">
                    Document Checklist
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2 leading-snug">
                    Green NRC, birth certificate &amp; official guarantor verification rules
                  </p>
                </div>
                <div className="mt-2.5 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[10px] font-bold text-blue-700 group-hover:text-blue-800">
                  <span>Pre-populate Chat</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </button>

              {/* Button 3: Help with Fees */}
              <button
                type="button"
                onClick={() =>
                  handleQuickAction(
                    'Help with Fees',
                    `What are the official passport fee schedules for 32-page ordinary (ZMW 500) vs 48-page frequent traveler (ZMW 1,000) passports, express service fees, and how do I complete payments through the Government Payment Gateway?`
                  )
                }
                className="group relative p-3 rounded-xl border border-slate-200 hover:border-amber-500 bg-slate-50/70 hover:bg-amber-50/50 text-left transition-all duration-150 hover:shadow-xs flex flex-col justify-between cursor-pointer"
                title="Ask AI Assistant about passport fees & payment gateway"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="w-7 h-7 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center group-hover:scale-105 transition-transform">
                      <CreditCard className="w-4 h-4" />
                    </div>
                    <span className="text-[10px] font-bold text-amber-800 bg-amber-100/70 px-1.5 py-0.2 rounded font-mono">
                      GPG Portal
                    </span>
                  </div>
                  <div className="text-xs font-bold text-slate-900 group-hover:text-amber-900">
                    Help with Fees
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2 leading-snug">
                    32 vs 48 pages, express costs &amp; online government payment gateway
                  </p>
                </div>
                <div className="mt-2.5 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[10px] font-bold text-amber-700 group-hover:text-amber-800">
                  <span>Pre-populate Chat</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </button>

              {/* Button 4: Photo Standards */}
              <button
                type="button"
                onClick={() =>
                  handleQuickAction(
                    'Photo Standards',
                    `What are the strict photo specifications (45mm x 35mm, plain off-white/grey background, neutral expression, spectacles glare, and religious headwear rules) to ensure my passport photo is accepted?`
                  )
                }
                className="group relative p-3 rounded-xl border border-slate-200 hover:border-purple-500 bg-slate-50/70 hover:bg-purple-50/50 text-left transition-all duration-150 hover:shadow-xs flex flex-col justify-between cursor-pointer"
                title="Ask AI Assistant about ICAO passport photo specifications"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="w-7 h-7 rounded-lg bg-purple-100 text-purple-800 flex items-center justify-center group-hover:scale-105 transition-transform">
                      <Camera className="w-4 h-4" />
                    </div>
                    <span className="text-[10px] font-bold text-purple-800 bg-purple-100/70 px-1.5 py-0.2 rounded font-mono">
                      45×35mm
                    </span>
                  </div>
                  <div className="text-xs font-bold text-slate-900 group-hover:text-purple-900">
                    Photo Standards
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2 leading-snug">
                    Background uniformity, glare prevention, expression &amp; ICAO dimensions
                  </p>
                </div>
                <div className="mt-2.5 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[10px] font-bold text-purple-700 group-hover:text-purple-800">
                  <span>Pre-populate Chat</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </button>

              {/* Button 5: Reversion Help */}
              <button
                type="button"
                onClick={() =>
                  handleQuickAction(
                    'Reversion Help',
                    selectedApplication.status === 'Reverted'
                      ? `My passport application #${selectedApplication.trackingNumber} has been reverted with reason: "${selectedApplication.reversionReason}". Can you guide me through resolving this step-by-step without paying a new fee?`
                      : `What happens if an application is reverted by a passport vetting officer, how do I submit corrections, and do I have to pay another statutory fee?`
                  )
                }
                className={`group relative p-3 rounded-xl border text-left transition-all duration-150 hover:shadow-xs flex flex-col justify-between cursor-pointer ${
                  selectedApplication.status === 'Reverted'
                    ? 'border-red-300 bg-red-50/80 hover:bg-red-100/70 hover:border-red-500'
                    : 'border-slate-200 hover:border-rose-500 bg-slate-50/70 hover:bg-rose-50/50'
                }`}
                title="Ask AI Assistant about application reversion policies"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center group-hover:scale-105 transition-transform ${
                        selectedApplication.status === 'Reverted'
                          ? 'bg-red-600 text-white'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      <AlertTriangle className="w-4 h-4" />
                    </div>
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.2 rounded font-mono ${
                        selectedApplication.status === 'Reverted'
                          ? 'bg-red-200 text-red-900 animate-pulse'
                          : 'bg-rose-100/70 text-rose-800'
                      }`}
                    >
                      {selectedApplication.status === 'Reverted' ? 'Action Needed' : 'Zero Re-fee'}
                    </span>
                  </div>
                  <div className="text-xs font-bold text-slate-900 group-hover:text-rose-900">
                    Reversion Help
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2 leading-snug">
                    {selectedApplication.status === 'Reverted'
                      ? `Fix "${selectedApplication.reversionReason?.slice(0, 30)}..."`
                      : 'How to correct flagged errors without repaying application fees'}
                  </p>
                </div>
                <div
                  className={`mt-2.5 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[10px] font-bold ${
                    selectedApplication.status === 'Reverted'
                      ? 'text-red-700 group-hover:text-red-800'
                      : 'text-rose-700 group-hover:text-rose-800'
                  }`}
                >
                  <span>Pre-populate Chat</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </button>
            </div>
          </div>

          {/* Active Application Dossier Card */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
            {/* Header info */}
            <div className="p-5 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-start gap-3.5">
                <div className="w-12 h-12 rounded-lg bg-emerald-800 flex items-center justify-center text-white shrink-0 shadow-xs">
                  <Shield className="w-6 h-6 stroke-[2]" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-slate-900">{selectedApplication.fullName}</h3>
                    <span className="font-mono text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-semibold">
                      {selectedApplication.trackingNumber}
                    </span>
                    {selectedApplication.isUrgent && (
                      <span className="text-[10px] bg-amber-500 text-slate-950 font-bold px-1.5 py-0.5 rounded">
                        EXPRESS
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-slate-500 mt-1 flex flex-wrap items-center gap-2">
                    <span>NRC: {selectedApplication.nrcNumber}</span>
                    <span aria-hidden="true">&bull;</span>
                    <span>Type: {selectedApplication.passportType}</span>
                    <span aria-hidden="true">&bull;</span>
                    <span>Office: {selectedApplication.collectionOffice}</span>
                  </div>
                </div>
              </div>

              {/* Status Badge & AI Guidance Trigger */}
              <div className="flex items-center gap-2.5">
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Current Stage</span>
                  <span
                    className={`inline-block px-2.5 py-1 rounded text-xs font-bold ${
                      selectedApplication.status === 'Reverted'
                        ? 'bg-red-100 text-red-800'
                        : selectedApplication.status === 'Paid - Unsubmitted'
                        ? 'bg-amber-100 text-amber-800'
                        : selectedApplication.status === 'Ready for Collection'
                        ? 'bg-emerald-100 text-emerald-800'
                        : selectedApplication.status === 'Biometrics Scheduled'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-slate-100 text-slate-800'
                    }`}
                  >
                    {selectedApplication.status}
                  </span>
                </div>

                <button
                  onClick={() => setActiveTab('guidance')}
                  className="px-3 py-2 bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-lg text-xs font-semibold hover:bg-emerald-100 transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Open Guidance Console</span>
                </button>
              </div>
            </div>

            {/* Visual 6-Stage Progress Stepper */}
            <div className="p-6 bg-slate-50 border-b border-slate-200">
              <span className="text-[10px] uppercase font-bold text-slate-400 block mb-3">
                Official OPAS Processing Lifecycle
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-xs">
                {[
                  { num: 1, label: 'Intake & Form' },
                  { num: 2, label: 'Statutory Fee' },
                  { num: 3, label: 'Officer Review' },
                  { num: 4, label: 'Biometrics' },
                  { num: 5, label: 'Personalization' },
                  { num: 6, label: 'Ready for Pickup' },
                ].map((s) => {
                  const isDone = currentStageNum >= s.num && selectedApplication.status !== 'Reverted';
                  const isCurrent = Math.floor(currentStageNum) === s.num;
                  const isRevertedAtThis = selectedApplication.status === 'Reverted' && s.num === 3;

                  return (
                    <div
                      key={s.num}
                      className={`p-2.5 rounded-lg border transition-all ${
                        isRevertedAtThis
                          ? 'bg-red-50 border-red-300 text-red-900'
                          : isDone
                          ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                          : isCurrent
                          ? 'bg-white border-emerald-500 shadow-xs text-slate-900 ring-1 ring-emerald-500'
                          : 'bg-white border-slate-200 text-slate-400'
                      }`}
                    >
                      <div className="flex items-center justify-between text-[11px] mb-1 font-semibold">
                        <span>Step {s.num}</span>
                        {isDone && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                        {isRevertedAtThis && <AlertTriangle className="w-3.5 h-3.5 text-red-600" />}
                      </div>
                      <div className="font-semibold text-xs leading-tight">{s.label}</div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* ACTION CENTER 1: Reverted Case Resolution Panel */}
            {selectedApplication.status === 'Reverted' && (
              <div className="p-6 bg-red-50/70 border-b border-red-200 space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                    <AlertTriangle className="w-4 h-4" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-red-950">
                      Action Required: Application Reverted by Passport Officer
                    </h4>
                    <p className="text-xs text-red-800 leading-relaxed">
                      <strong>Reason from Officer:</strong> &ldquo;{selectedApplication.reversionReason}&rdquo;
                    </p>
                    <p className="text-[11px] text-red-700">
                      Good news: You do <strong>NOT</strong> have to pay the fee again. Simply upload the corrected item below to restore your place in the processing queue.
                    </p>
                  </div>
                </div>

                {/* Upload Correction with AI Pre-Check */}
                <div className="bg-white border border-red-200 rounded-lg p-4 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        Upload Corrected Passport Photo
                      </span>
                      <span className="text-[11px] text-slate-500">
                        Plain off-white/light-grey background, even lighting, no sunglasses or shadows.
                      </span>
                    </div>
                    <button
                      onClick={handleSimulateReupload}
                      disabled={reuploading || reuploadSuccess}
                      className="px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-md shadow-xs transition-colors cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
                    >
                      {reuploading ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>Checking with AI...</span>
                        </>
                      ) : reuploadSuccess ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Approved &amp; Resubmitted!</span>
                        </>
                      ) : (
                        <>
                          <Upload className="w-3.5 h-3.5" />
                          <span>Simulate Upload Corrected Photo</span>
                        </>
                      )}
                    </button>
                  </div>

                  {reuploadSuccess && (
                    <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-md text-xs text-emerald-900 flex items-center justify-between">
                      <span className="font-semibold flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        AI Pre-Check Passed (Optical Score: {aiPreCheckScore}/100)! Moving case back to Vetting Officer.
                      </span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ACTION CENTER 2: Paid-but-Unsubmitted Alert Panel */}
            {selectedApplication.status === 'Paid - Unsubmitted' && (
              <div className="p-6 bg-amber-50 border-b border-amber-200 space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-amber-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-amber-950">
                      Statutory Payment Received &bull; Final Submission Pending!
                    </h4>
                    <p className="text-xs text-amber-900 leading-relaxed">
                      We have verified your payment of <strong>ZMW {selectedApplication.feeAmount}</strong> (Ref: {selectedApplication.paymentReference || 'GPG-TX-994821'}). However, your application remains unsubmitted in draft status.
                    </p>
                    <p className="text-[11px] text-amber-800">
                      Click &quot;Finalize &amp; Submit Application&quot; to formally transmit your dossier to the Passport Office and trigger your biometrics booking.
                    </p>
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    onClick={handleFinalizePaidSubmit}
                    className="px-5 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-md shadow-xs transition-colors cursor-pointer flex items-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Finalize &amp; Submit Application to Passport Office</span>
                  </button>
                </div>
              </div>
            )}

            {/* Details Grid */}
            <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6 text-xs border-b border-slate-100">
              {/* Column 1: Contact Info */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] uppercase font-bold text-slate-400 block">Contact Information</span>
                  <button
                    onClick={() => setIsPhoneSimOpen(true)}
                    className="text-[10px] text-emerald-800 hover:text-emerald-950 font-bold flex items-center gap-1 cursor-pointer bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200"
                  >
                    <Smartphone className="w-3 h-3" />
                    <span>SMS Handset</span>
                  </button>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                  <div className="flex items-center gap-2 text-slate-700">
                    <Phone className="w-3.5 h-3.5 text-slate-500" />
                    <span className="font-mono">{selectedApplication.contact.phone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-700">
                    <Mail className="w-3.5 h-3.5 text-slate-500" />
                    <span className="truncate">{selectedApplication.contact.email}</span>
                  </div>
                  <div className="flex items-start gap-2 text-slate-700">
                    <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
                    <span>
                      {selectedApplication.contact.residentialAddress}, {selectedApplication.contact.district}
                    </span>
                  </div>
                </div>
              </div>

              {/* Column 2: Guarantor Info */}
              <div className="space-y-2">
                <span className="text-[11px] uppercase font-bold text-slate-400 block">Verified Guarantor</span>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1.5">
                  <div className="font-semibold text-slate-900">{selectedApplication.guarantor.fullName}</div>
                  <div className="text-slate-600">{selectedApplication.guarantor.profession}</div>
                  <div className="text-[11px] text-slate-500 font-mono">
                    NRC: {selectedApplication.guarantor.nrcNumber}
                  </div>
                  <div className="text-[11px] text-slate-500">{selectedApplication.guarantor.organization}</div>
                </div>
              </div>

              {/* Column 3: Biometrics & Collection Info */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] uppercase font-bold text-slate-400 block">Collection &amp; Biometrics</span>
                  <button
                    onClick={() => setIsBiometricsModalOpen(true)}
                    className="text-[10px] text-emerald-800 hover:text-emerald-950 font-bold flex items-center gap-1 cursor-pointer bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200"
                  >
                    <Calendar className="w-3 h-3" />
                    <span>Schedule / Slip</span>
                  </button>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                  <div>
                    <div className="text-slate-500 text-[11px]">Pickup Office:</div>
                    <div className="font-semibold text-slate-900">{selectedApplication.collectionOffice}</div>
                  </div>
                  {selectedApplication.biometricsDate ? (
                    <div>
                      <div className="text-slate-500 text-[11px]">Appointment Confirmed:</div>
                      <div className="font-semibold text-emerald-800 flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        {selectedApplication.biometricsDate}
                      </div>
                    </div>
                  ) : (
                    <button
                      onClick={() => setIsBiometricsModalOpen(true)}
                      className="w-full py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded text-[11px] font-semibold transition-colors cursor-pointer flex items-center justify-center gap-1"
                    >
                      <Calendar className="w-3 h-3" />
                      <span>Book Biometrics Slot</span>
                    </button>
                  )}
                  {selectedApplication.status === 'Ready for Collection' && (
                    <div className="p-2 bg-emerald-100/70 border border-emerald-300 rounded text-emerald-950 font-semibold text-[11px]">
                      Booklet ready at Counter 4. Bring original Green NRC.
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Dossier Uploaded Documents Preview Section */}
            <div className="p-6 bg-slate-50/50 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                    Uploaded Dossier Documents ({selectedApplication.documents.length})
                  </span>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Click any document below to inspect optical inspection quality, dimensions, and officer verification notes.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {selectedApplication.documents.map((doc) => (
                  <div
                    key={doc.id}
                    onClick={() => setInspectedDoc(doc)}
                    className="p-3 bg-white border border-slate-200 hover:border-emerald-400 rounded-xl shadow-2xs hover:shadow-sm transition-all cursor-pointer flex items-center justify-between gap-2 group"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-800 flex items-center justify-center shrink-0 border border-emerald-200">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="font-semibold text-slate-900 truncate text-xs group-hover:text-emerald-900">
                          {doc.name}
                        </div>
                        <div className="text-[11px] text-slate-500 truncate">{doc.type}</div>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                          doc.status === 'APPROVED'
                            ? 'bg-emerald-100 text-emerald-800'
                            : doc.status === 'REJECTED'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {doc.status}
                      </span>
                      {doc.aiScore && (
                        <div className="text-[10px] font-mono text-slate-400 mt-0.5">
                          {doc.aiScore}/100
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Smart Features Pillars View */}
      {activeTab === 'pillars' && (
        <PillarsModule
          applications={applications}
          onOpenAssistant={() => setActiveTab('guidance')}
          onSelectApplication={onSelectApplication}
          onAddNotification={onAddNotification || (() => {})}
          onUpdateStatus={onUpdateStatus}
          isOfficerRole={false}
        />
      )}

      {/* New Application Form */}
      {activeTab === 'apply' && (
        <ApplicationForm
          onSubmitSuccess={(newApp) => {
            onAddNewApplication(newApp);
            onSelectApplication(newApp);
            setActiveTab('status');
          }}
          onCancel={() => setActiveTab('status')}
        />
      )}

      {/* Message Board Notifications */}
      {activeTab === 'messages' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Official OPAS Message Board &amp; SMS Dispatch Log
              </h3>
              <p className="text-xs text-slate-500">
                Authorized notifications sent to {selectedApplication.fullName} ({selectedApplication.trackingNumber})
              </p>
            </div>
            <span className="text-xs font-mono bg-slate-100 px-2.5 py-1 rounded font-semibold text-slate-700">
              {selectedApplication.notifications.length} Logs
            </span>
          </div>

          <div className="space-y-3">
            {selectedApplication.notifications.map((n) => (
              <div
                key={n.id}
                className="p-4 rounded-lg border border-slate-200 bg-slate-50/70 text-xs space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900">{n.subject || 'OPAS Alert'}</span>
                    <span className="text-[10px] bg-slate-200 text-slate-800 px-1.5 py-0.2 rounded font-mono font-semibold">
                      {n.channel}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-500 font-mono">
                      {new Date(n.timestamp).toLocaleString()}
                    </span>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-semibold px-1.5 py-0.5 rounded">
                      {n.deliveryStatus}
                    </span>
                  </div>
                </div>
                <p className="text-slate-700 leading-relaxed">{n.content}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Approved FAQs Knowledge Base */}
      {activeTab === 'faqs' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-5">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900">
              Approved MoHAIS Passport FAQs &amp; Operational Knowledge Base
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Verified immigration procedures used by the AI Guidance Assistant
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {APPROVED_FAQS.map((faq) => (
              <div key={faq.id} className="p-4 rounded-lg border border-slate-200 bg-slate-50/50 space-y-2 text-xs">
                <span className="text-[10px] uppercase font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  {faq.category}
                </span>
                <h4 className="font-bold text-slate-900 text-xs mt-1">{faq.question}</h4>
                <div className="text-slate-700 whitespace-pre-wrap leading-relaxed">{faq.answer}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Interactive High-Fidelity Document & Optical AI Viewer */}
      {inspectedDoc && (
        <DocumentViewerModal
          document={inspectedDoc}
          application={selectedApplication}
          onClose={() => setInspectedDoc(null)}
          isOfficerRole={false}
        />
      )}

      {/* Citizen Mobile Phone & SMS Simulator */}
      {isPhoneSimOpen && (
        <CitizenPhoneSimulatorModal
          application={selectedApplication}
          onClose={() => setIsPhoneSimOpen(false)}
        />
      )}

      {/* Biometrics Appointment Booking Modal */}
      {isBiometricsModalOpen && (
        <BiometricsSchedulerModal
          application={selectedApplication}
          onClose={() => setIsBiometricsModalOpen(false)}
          onConfirmSchedule={(dateStr, office) => {
            onUpdateStatus(
              selectedApplication.id,
              'Biometrics Scheduled',
              `Biometrics enrollment scheduled for ${dateStr} at ${office}.`
            );
            selectedApplication.biometricsDate = dateStr;
            selectedApplication.collectionOffice = office;
          }}
        />
      )}
    </div>
  );
};
