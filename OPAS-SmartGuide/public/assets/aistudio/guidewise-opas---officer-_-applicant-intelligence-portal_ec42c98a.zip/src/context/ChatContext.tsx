import React, { createContext, useContext, useState, useRef, useEffect } from 'react';
import { ChatMessage, PassportApplication, NotificationLog } from '../types/passport';

interface ChatContextType {
  messages: ChatMessage[];
  sendMessage: (text: string) => Promise<void>;
  loading: boolean;
  isAssistantOpen: boolean;
  setIsAssistantOpen: (open: boolean) => void;
  isGuidanceScreen: boolean;
  setIsGuidanceScreen: (isGuidance: boolean) => void;
  currentSection: string;
  setCurrentSection: (section: string) => void;
  activeApplication: PassportApplication | undefined;
  setActiveApplication: (app: PassportApplication) => void;
  autoVoice: boolean;
  setAutoVoice: (val: boolean) => void;
  isSpeaking: string | null;
  handlePlayVoice: (msgId: string, text: string, audioBase64?: string) => Promise<void>;
  stopSpeech: () => void;
  unreadNotificationsCount: number;
  prefilledQuery: string;
  setPrefilledQuery: (query: string) => void;
  populateQuery: (query: string, autoSend?: boolean) => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider: React.FC<{
  children: React.ReactNode;
  initialApplication?: PassportApplication;
}> = ({ children, initialApplication }) => {
  const [activeApplication, setActiveApplication] = useState<PassportApplication | undefined>(initialApplication);
  const [isAssistantOpen, setIsAssistantOpen] = useState(false);
  const [isGuidanceScreen, setIsGuidanceScreen] = useState(false);
  const [currentSection, setCurrentSection] = useState<string>('Dashboard');
  const [loading, setLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState<string | null>(null);
  const [autoVoice, setAutoVoice] = useState(false);
  const [prefilledQuery, setPrefilledQuery] = useState<string>('');

  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  const populateQuery = (query: string, autoSend: boolean = false) => {
    setIsAssistantOpen(true);
    setPrefilledQuery(query);
    if (autoSend) {
      sendMessage(query);
    }
  };

  // Initialize conversation held above the pages
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      sender: 'assistant',
      text: initialApplication
        ? `Hello! I am your official MoHAIS OPAS Assistant. I am tracking application #${initialApplication.trackingNumber} (${initialApplication.status}). How can I help make your passport journey faster and easier today?`
        : 'Welcome to the Ministry of Home Affairs and Internal Security (MoHAIS) Passport Guidance Assistant. I can help with contact validation, outstanding steps, reverted cases, photo rules, and fee payments. How can I assist you today?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  // Update activeApplication if prop changes
  useEffect(() => {
    if (initialApplication && initialApplication.id !== activeApplication?.id) {
      setActiveApplication(initialApplication);
    }
  }, [initialApplication]);

  // Clean up audio on unmount
  useEffect(() => {
    return () => {
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const stopSpeech = () => {
    if (audioPlayerRef.current) {
      audioPlayerRef.current.pause();
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(null);
  };

  const handlePlayVoice = async (msgId: string, text: string, audioBase64?: string) => {
    if (isSpeaking === msgId) {
      stopSpeech();
      return;
    }

    setIsSpeaking(msgId);

    try {
      let b64 = audioBase64;
      if (!b64) {
        const res = await fetch('/api/assistant/tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text, voice: 'Kore' }),
        });
        const data = await res.json();
        b64 = data.audioBase64;
      }

      if (b64) {
        const audio = new Audio(`data:audio/wav;base64,${b64}`);
        audioPlayerRef.current = audio;
        audio.onended = () => setIsSpeaking(null);
        audio.onerror = () => {
          fallbackSpeech(text, msgId);
        };
        await audio.play();
      } else {
        fallbackSpeech(text, msgId);
      }
    } catch {
      fallbackSpeech(text, msgId);
    }
  };

  const fallbackSpeech = (text: string, msgId: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text.replace(/[\*\_#`]/g, '').substring(0, 300));
      utterance.rate = 1.0;
      utterance.onend = () => setIsSpeaking(null);
      utterance.onerror = () => setIsSpeaking(null);
      window.speechSynthesis.speak(utterance);
    } else {
      setIsSpeaking(null);
    }
  };

  const sendMessage = async (messageText: string) => {
    if (!messageText.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: messageText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);

    try {
      const response = await fetch('/api/assistant/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: messageText,
          history: messages.map((m) => ({ sender: m.sender, text: m.text })),
          contextData: {
            currentSection,
            ...(activeApplication
              ? {
                  applicantName: activeApplication.fullName,
                  trackingNumber: activeApplication.trackingNumber,
                  applicationStatus: activeApplication.status,
                  reversionReason: activeApplication.reversionReason,
                }
              : {}),
          },
        }),
      });

      const data = await response.json();
      const botText = data.reply || 'Thank you for reaching out to MoHAIS OPAS. Please review your application details or contact the Passport Office.';
      const botMsgId = `bot-${Date.now()}`;

      const botMsg: ChatMessage = {
        id: botMsgId,
        sender: 'assistant',
        text: botText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMsg]);

      if (autoVoice) {
        handlePlayVoice(botMsgId, botText);
      }
    } catch (err) {
      console.error('Chat error:', err);
      const fallbackMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        sender: 'assistant',
        text: 'MoHAIS OPAS Assistance: For official guidelines or urgent passport enquiries, please consult the Passport Office at Makishi Road, Lusaka or call +260 211 252 649.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setLoading(false);
    }
  };

  const unreadNotificationsCount = activeApplication?.notifications?.length || 0;

  return (
    <ChatContext.Provider
      value={{
        messages,
        sendMessage,
        loading,
        isAssistantOpen,
        setIsAssistantOpen,
        isGuidanceScreen,
        setIsGuidanceScreen,
        currentSection,
        setCurrentSection,
        activeApplication,
        setActiveApplication,
        autoVoice,
        setAutoVoice,
        isSpeaking,
        handlePlayVoice,
        stopSpeech,
        unreadNotificationsCount,
        prefilledQuery,
        setPrefilledQuery,
        populateQuery,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};
