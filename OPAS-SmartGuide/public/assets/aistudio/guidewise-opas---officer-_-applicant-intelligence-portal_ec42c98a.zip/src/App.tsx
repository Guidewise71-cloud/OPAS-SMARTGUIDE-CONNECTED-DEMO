/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { AuthPortal } from './components/auth/AuthPortal';
import { OfficerDashboard } from './components/officer/OfficerDashboard';
import { CitizenPortal } from './components/citizen/CitizenPortal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AIGuidanceChat } from './components/citizen/AIGuidanceChat';
import { INITIAL_APPLICATIONS } from './data/mockApplications';
import { INITIAL_USERS } from './data/mockUsers';
import { PassportApplication, NotificationLog } from './types/passport';
import { UserAccount } from './types/auth';
import { Shield, Sparkles, MessageSquareQuote, Bell } from 'lucide-react';
import { EOIDocumentModal } from './components/common/EOIDocumentModal';
import { CitizenPhoneSimulatorModal } from './components/common/CitizenPhoneSimulatorModal';
import { ChatProvider, useChat } from './context/ChatContext';

interface AppContentProps {
  users: UserAccount[];
  setUsers: React.Dispatch<React.SetStateAction<UserAccount[]>>;
  currentUser: UserAccount | null;
  setCurrentUser: React.Dispatch<React.SetStateAction<UserAccount | null>>;
  currentView: 'citizen' | 'officer' | 'admin';
  setCurrentView: React.Dispatch<React.SetStateAction<'citizen' | 'officer' | 'admin'>>;
  applications: PassportApplication[];
  setApplications: React.Dispatch<React.SetStateAction<PassportApplication[]>>;
  selectedApplicationId: string;
  setSelectedApplicationId: React.Dispatch<React.SetStateAction<string>>;
  selectedApplication: PassportApplication;
  isEOIModalOpen: boolean;
  setIsEOIModalOpen: React.Dispatch<React.SetStateAction<boolean>>;
  isPhoneSimOpen: boolean;
  setIsPhoneSimOpen: React.Dispatch<React.SetStateAction<boolean>>;
}

function AppContent({
  users,
  setUsers,
  currentUser,
  setCurrentUser,
  currentView,
  setCurrentView,
  applications,
  setApplications,
  selectedApplicationId,
  setSelectedApplicationId,
  selectedApplication,
  isEOIModalOpen,
  setIsEOIModalOpen,
  isPhoneSimOpen,
  setIsPhoneSimOpen,
}: AppContentProps) {
  const {
    isAssistantOpen,
    setIsAssistantOpen,
    isGuidanceScreen,
    unreadNotificationsCount,
    setActiveApplication,
  } = useChat();

  // Sync selected application to ChatContext
  useEffect(() => {
    if (selectedApplication) {
      setActiveApplication(selectedApplication);
    }
  }, [selectedApplication, setActiveApplication]);

  // Auth Handlers
  const handleLogin = (user: UserAccount) => {
    setCurrentUser(user);
    if (user.role === 'admin') {
      setCurrentView('admin');
    } else if (user.role === 'officer') {
      setCurrentView('officer');
    } else {
      setCurrentView('citizen');
      // If citizen has existing application by NRC or email, set as active
      const citizenApp = applications.find(
        (a) =>
          (user.nrcNumber && a.nrcNumber === user.nrcNumber) ||
          a.contact.email.toLowerCase() === user.email.toLowerCase()
      );
      if (citizenApp) {
        setSelectedApplicationId(citizenApp.id);
      }
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentView('citizen');
    setIsAssistantOpen(false);
  };

  const handleRegisterCitizen = (newCitizen: UserAccount) => {
    setUsers((prev) => [newCitizen, ...prev]);
  };

  // Admin Officer Provisioning Handlers
  const handleAddOfficer = (newOfficer: UserAccount) => {
    setUsers((prev) => [newOfficer, ...prev]);
  };

  const handleUpdateOfficerStatus = (userId: string, newStatus: 'ACTIVE' | 'SUSPENDED') => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, status: newStatus } : u))
    );
  };

  const handleResetPassword = (userId: string, newPass: string) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, password: newPass } : u))
    );
  };

  // Application Updates
  const handleUpdateStatus = (
    id: string,
    newStatus: PassportApplication['status'],
    notes?: string
  ) => {
    setApplications((prev) =>
      prev.map((app) => {
        if (app.id === id) {
          return {
            ...app,
            status: newStatus,
            officerNotes: notes || app.officerNotes,
            daysInStatus: 0,
            lastUpdated: new Date().toISOString(),
          };
        }
        return app;
      })
    );
  };

  const handleAddNotification = (id: string, notif: NotificationLog) => {
    setApplications((prev) =>
      prev.map((app) => {
        if (app.id === id) {
          return {
            ...app,
            notifications: [notif, ...app.notifications],
            lastUpdated: new Date().toISOString(),
          };
        }
        return app;
      })
    );
  };

  const handleAddNewApplication = (newApp: PassportApplication) => {
    setApplications((prev) => [newApp, ...prev]);
    setSelectedApplicationId(newApp.id);
  };

  const handleSelectScenario = (scenarioId: string) => {
    setSelectedApplicationId(scenarioId);
    // If switching scenario while in citizen view, align demo user
    if (scenarioId === 'app-002') {
      const mutinta = users.find((u) => u.email === 'mutinta.mweetwa@gmail.com');
      if (mutinta && currentUser?.role === 'citizen') setCurrentUser(mutinta);
    } else if (scenarioId === 'app-001') {
      const kondwani = users.find((u) => u.email === 'k.phiri@outlook.com');
      if (kondwani && currentUser?.role === 'citizen') setCurrentUser(kondwani);
    }
  };

  // Strict role-based view boundary: officers only see officer dashboard, citizens only see citizen dashboard
  useEffect(() => {
    if (currentUser?.role === 'officer' && currentView !== 'officer') {
      setCurrentView('officer');
    } else if (currentUser?.role === 'citizen' && currentView !== 'citizen') {
      setCurrentView('citizen');
    }
  }, [currentUser, currentView, setCurrentView]);

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-colors duration-200 ${
      currentView === 'officer' && currentUser ? 'bg-[#18202c] text-slate-200' : 'bg-slate-50 text-slate-900'
    }`}>
      {/* Official MoHAIS Top Header */}
      <Header
        currentUser={currentUser}
        currentView={currentView}
        onViewChange={(view) => {
          // Prevent officer from navigating into citizen portal
          if (currentUser?.role === 'officer' && view !== 'officer') return;
          if (currentUser?.role === 'citizen' && view !== 'citizen') return;
          setCurrentView(view);
        }}
        onOpenAssistant={() => setIsAssistantOpen(true)}
        onSelectScenario={handleSelectScenario}
        activeScenarioId={selectedApplicationId}
        onLogout={handleLogout}
        onOpenEOIModal={() => setIsEOIModalOpen(true)}
        onOpenPhoneSimulator={() => setIsPhoneSimOpen(true)}
      />

      {/* Main Content Area */}
      <main className={`flex-1 w-full mx-auto transition-all ${
        currentView === 'officer'
          ? 'max-w-[1750px] px-2 sm:px-4 lg:px-6 py-4'
          : 'max-w-7xl px-4 sm:px-8 py-6'
      }`}>
        {!currentUser ? (
          /* Single Unified Login & Citizen Account Creation Portal */
          <AuthPortal
            users={users}
            onLogin={handleLogin}
            onRegisterCitizen={handleRegisterCitizen}
          />
        ) : currentView === 'admin' ? (
          /* MoHAIS Administrator Dashboard (Officer Provisioning & System Management) */
          <AdminDashboard
            users={users}
            onAddOfficer={handleAddOfficer}
            onUpdateOfficerStatus={handleUpdateOfficerStatus}
            onResetPassword={handleResetPassword}
            onViewOfficerConsole={() => setCurrentView('officer')}
          />
        ) : currentView === 'officer' ? (
          /* Passport Officer Operational Console (completely isolated from Citizen Portal) */
          <OfficerDashboard
            applications={applications}
            onUpdateStatus={handleUpdateStatus}
            onAddNotification={handleAddNotification}
            onSelectApplication={(app) => {
              // Officer stays strictly on officer dashboard
              setSelectedApplicationId(app.id);
            }}
            onLogout={handleLogout}
            selectedAppForCitizenView={selectedApplication}
            onOpenAssistant={() => setIsAssistantOpen(true)}
          />
        ) : (
          /* Citizen Portal */
          <CitizenPortal
            applications={applications}
            selectedApplication={selectedApplication}
            onSelectApplication={(app) => setSelectedApplicationId(app.id)}
            onUpdateStatus={handleUpdateStatus}
            onAddNewApplication={handleAddNewApplication}
            onOpenAssistant={() => setIsAssistantOpen(true)}
            onAddNotification={handleAddNotification}
          />
        )}
      </main>

      {/* Persistent AI Assistant Widget (available on citizen view EXCEPT when already viewing the Guidance screen) */}
      {currentUser && currentView !== 'officer' && !isGuidanceScreen && (
        <AIGuidanceChat isFullWidth={false} />
      )}

      {/* Floating "Need help?" Button in Bottom-Right
          - Visible on citizen portal when logged in
          - Hidden on officer dashboard & admin console
          - Features a top notification badge when unread alerts exist
      */}
      {currentUser && currentView !== 'officer' && !isGuidanceScreen && !isAssistantOpen && (
        <button
          onClick={() => setIsAssistantOpen(true)}
          className="fixed bottom-5 right-5 z-40 bg-emerald-800 hover:bg-emerald-900 text-white rounded-full pl-3.5 pr-4.5 py-3 shadow-xl hover:shadow-2xl flex items-center gap-2.5 text-xs font-bold transition-all duration-200 hover:scale-105 cursor-pointer border border-emerald-700/80 ring-2 ring-emerald-500/20 group"
          title="Need help? Open 24/7 MoHAIS Passport Assistant"
          aria-label="Need help? Open 24/7 MoHAIS Passport Assistant"
        >
          <div className="relative flex items-center justify-center">
            <div className="w-6 h-6 rounded-full bg-emerald-700 flex items-center justify-center text-emerald-200 group-hover:text-white transition-colors">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
            {unreadNotificationsCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 w-3 h-3 bg-red-500 rounded-full border-2 border-emerald-800 animate-pulse" />
            )}
          </div>
          <span className="tracking-wide">Need help?</span>
          {unreadNotificationsCount > 0 && (
            <span className="bg-red-500 text-white text-[10px] px-1.5 py-0.2 rounded-full font-bold shadow-xs">
              {unreadNotificationsCount}
            </span>
          )}
        </button>
      )}

      {/* Official UNIPODS EOI Proposal Document Modal */}
      {isEOIModalOpen && (
        <EOIDocumentModal onClose={() => setIsEOIModalOpen(false)} />
      )}

      {/* Citizen Mobile Phone & SMS Simulator Modal */}
      {isPhoneSimOpen && (
        <CitizenPhoneSimulatorModal
          application={selectedApplication}
          onClose={() => setIsPhoneSimOpen(false)}
        />
      )}

      {/* Official Government Footer */}
      <footer className={`mt-auto border-t py-6 text-sm transition-colors ${
        currentView === 'officer' && currentUser
          ? 'border-[#283548] bg-[#141b26] text-slate-300'
          : 'border-slate-200 bg-white text-slate-600'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded bg-emerald-800 flex items-center justify-center text-white shrink-0">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <span className={`font-semibold block ${currentView === 'officer' && currentUser ? 'text-slate-200' : 'text-slate-800'}`}>
                Republic of Zambia · Ministry of Home Affairs and Internal Security (MoHAIS)
              </span>
              <p className={`text-xs ${currentView === 'officer' && currentUser ? 'text-slate-400' : 'text-slate-500'}`}>
                {currentView === 'officer' && currentUser
                  ? 'Online Passport Application System (OPAS) · Department of National Registration, Passport and Citizenship'
                  : 'Online Passport Application System (OPAS) Enhancement Pilot · UNIPODS AI for Public Good Challenge'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs text-slate-600">
            <span>Passport Office, Makishi Road, Lusaka</span>
            <span aria-hidden="true">·</span>
            <span>Support: +260 211 252 649</span>
            <span aria-hidden="true">·</span>
            <span>opas-support@mohais.gov.zm</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  const [users, setUsers] = useState<UserAccount[]>(INITIAL_USERS);
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(INITIAL_USERS[4]); // Mutinta Mweetwa (citizen) by default
  const [currentView, setCurrentView] = useState<'citizen' | 'officer' | 'admin'>('citizen');
  const [applications, setApplications] = useState<PassportApplication[]>(INITIAL_APPLICATIONS);
  const [selectedApplicationId, setSelectedApplicationId] = useState<string>('app-002');
  const [isEOIModalOpen, setIsEOIModalOpen] = useState(false);
  const [isPhoneSimOpen, setIsPhoneSimOpen] = useState(false);

  const selectedApplication =
    applications.find((a) => a.id === selectedApplicationId) || applications[0];

  return (
    <ChatProvider initialApplication={selectedApplication}>
      <AppContent
        users={users}
        setUsers={setUsers}
        currentUser={currentUser}
        setCurrentUser={setCurrentUser}
        currentView={currentView}
        setCurrentView={setCurrentView}
        applications={applications}
        setApplications={setApplications}
        selectedApplicationId={selectedApplicationId}
        setSelectedApplicationId={setSelectedApplicationId}
        selectedApplication={selectedApplication}
        isEOIModalOpen={isEOIModalOpen}
        setIsEOIModalOpen={setIsEOIModalOpen}
        isPhoneSimOpen={isPhoneSimOpen}
        setIsPhoneSimOpen={setIsPhoneSimOpen}
      />
    </ChatProvider>
  );
}
