import React from 'react';
import {
  Shield,
  Sparkles,
  User,
  BarChart3,
  Building2,
  LogOut,
  Layers,
  KeyRound,
  FileText,
  Smartphone,
} from 'lucide-react';
import { UserAccount } from '../types/auth';

interface HeaderProps {
  currentUser: UserAccount | null;
  currentView: 'officer' | 'citizen' | 'admin';
  onViewChange: (view: 'officer' | 'citizen' | 'admin') => void;
  onOpenAssistant: () => void;
  onSelectScenario: (scenarioId: string) => void;
  activeScenarioId?: string;
  onLogout: () => void;
  onOpenEOIModal?: () => void;
  onOpenPhoneSimulator?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  currentView,
  onViewChange,
  onOpenAssistant,
  onSelectScenario,
  activeScenarioId,
  onLogout,
  onOpenEOIModal,
  onOpenPhoneSimulator,
}) => {
  return (
    <header className={`border-b sticky top-0 z-40 shadow-xs transition-colors ${
      currentView === 'officer'
        ? 'border-[#1b2234] bg-[#0c0f17] text-white'
        : 'border-slate-200 bg-white'
    }`}>
      {/* Top Governmental Bar */}
      <div className="bg-emerald-950 text-white px-4 sm:px-8 py-1.5 text-xs font-medium tracking-wide flex flex-wrap items-center justify-between gap-2 border-b border-emerald-900/40">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
          <span>REPUBLIC OF ZAMBIA</span>
          <span className="text-emerald-300/60" aria-hidden="true">·</span>
          <span className="text-emerald-100">Ministry of Home Affairs and Internal Security (MoHAIS)</span>
          <span className="text-emerald-300/60 hidden md:inline" aria-hidden="true">·</span>
          <span className="text-emerald-200/80 hidden md:inline">Online Passport Application System (OPAS)</span>
        </div>
        <div className="flex items-center gap-3 text-xs text-emerald-200">
          <span className="hidden sm:inline">UNIPODS AI for Public Good Challenge</span>
          <span className="bg-emerald-800/80 text-emerald-100 px-2 py-0.5 rounded text-[11px] font-mono">
            6-Month Pilot
          </span>
        </div>
      </div>

      {/* Main Navigation Header */}
      <div className="max-w-[1750px] mx-auto px-4 sm:px-6 py-3 flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Crest & Title */}
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-lg bg-emerald-700 flex items-center justify-center text-white shadow-xs">
            <Shield className="w-6 h-6 stroke-[2.2]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className={`text-lg sm:text-xl font-bold tracking-tight ${
                currentView === 'officer' ? 'text-white' : 'text-slate-900'
              }`}>
                OPAS Intelligence &amp; AI Assistant
              </h1>
              <span className="bg-amber-100 text-amber-900 text-[10px] font-semibold px-2 py-0.5 rounded uppercase tracking-wider">
                Pilot
              </span>
            </div>
            <p className={`text-xs ${
              currentView === 'officer' ? 'text-slate-400' : 'text-slate-500'
            }`}>
              Assisted Citizen Guidance · Contact Validation · Automated Reversion Tracking
            </p>
          </div>
        </div>

        {/* Action Controls & Navigation */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Quick Scenario Selector for Testing (only in citizen preview, hidden in officer dashboard) */}
          {currentView !== 'admin' && (
            <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs">
              <Layers className="w-3.5 h-3.5 text-slate-500 ml-1.5" />
              <span className="text-slate-600 font-medium hidden xl:inline mr-1">Demo Case:</span>
              <select
                value={activeScenarioId || 'app-002'}
                onChange={(e) => onSelectScenario(e.target.value)}
                className="bg-transparent text-slate-800 font-medium py-1 px-1.5 focus:outline-hidden cursor-pointer"
                title="Select test case"
              >
                <option value="app-002">Case 1: Reverted Photo (Mutinta)</option>
                <option value="app-001">Case 2: Paid Unsubmitted (Kondwani)</option>
                <option value="app-003">Case 3: Missing Guarantor (Thandiwe)</option>
                <option value="app-004">Case 4: Invalid Contact (Chilufya)</option>
                <option value="app-006">Case 5: Ready for Collection (Mwamba)</option>
              </select>
            </div>
          )}

          {/* UNIPODS EOI Proposal Document Viewer (hidden in officer dashboard) */}
          {currentView !== 'admin' && onOpenEOIModal && (
            <button
              onClick={onOpenEOIModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-colors cursor-pointer"
              title="Open UNIPODS Expression of Interest (EOI) Document"
            >
              <FileText className="w-3.5 h-3.5 text-emerald-700" />
              <span className="hidden sm:inline">EOI Proposal</span>
            </button>
          )}

          {/* Citizen Phone / SMS Alerts Preview */}
          {onOpenPhoneSimulator && (
            <button
              onClick={onOpenPhoneSimulator}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-colors cursor-pointer"
              title="Inspect real-time SMS delivery on citizen mobile handset"
            >
              <Smartphone className="w-3.5 h-3.5 text-slate-600" />
              <span className="hidden sm:inline">SMS Handset</span>
            </button>
          )}

          {/* AI Assistant Quick Trigger */}
          <button
            onClick={onOpenAssistant}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100 transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>AI Assistant</span>
          </button>

          {/* Role-Specific Navigation Switcher (for Admins / Officers) */}
          {currentUser && currentUser.role === 'admin' && (
            <div className="flex items-center bg-slate-100 p-1 rounded-lg border border-slate-200">
              <button
                onClick={() => onViewChange('admin')}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                  currentView === 'admin'
                    ? 'bg-white text-emerald-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Building2 className="w-3.5 h-3.5" />
                <span>Admin Provisioning</span>
              </button>
              <button
                onClick={() => onViewChange('officer')}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                  currentView === 'officer'
                    ? 'bg-white text-emerald-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5" />
                <span>Officer Console</span>
              </button>
            </div>
          )}

          {/* User Profile Badge & Logout */}
          {currentUser ? (
            <div className={`flex items-center gap-2 pl-2 border-l ${
              currentView === 'officer' ? 'border-[#1b2234]' : 'border-slate-200'
            }`}>
              <div className="text-right hidden sm:block">
                <div className={`text-xs font-bold flex items-center justify-end gap-1.5 ${
                  currentView === 'officer' ? 'text-white' : 'text-slate-900'
                }`}>
                  <span>{currentUser.fullName}</span>
                  <span
                    className={`text-[10px] font-mono px-1.5 py-0.2 rounded font-bold uppercase ${
                      currentUser.role === 'admin'
                        ? 'bg-purple-100 text-purple-800'
                        : currentUser.role === 'officer'
                        ? 'bg-blue-600/30 text-blue-300 border border-blue-500/30'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {currentUser.role}
                  </span>
                </div>
                <div className={`text-[11px] ${
                  currentView === 'officer' ? 'text-slate-400 font-mono' : 'text-slate-500'
                }`}>
                  {currentUser.role === 'citizen'
                    ? `NRC: ${currentUser.nrcNumber || '294812/11/1'}`
                    : currentUser.badgeNumber || currentUser.email}
                </div>
              </div>

              <button
                onClick={onLogout}
                className="p-1.5 text-slate-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                title="Sign Out of OPAS"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="text-xs text-slate-500 italic">
              Authentication Portal
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
