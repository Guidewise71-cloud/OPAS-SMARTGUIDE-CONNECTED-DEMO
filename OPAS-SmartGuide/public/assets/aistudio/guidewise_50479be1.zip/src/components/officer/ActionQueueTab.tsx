import React, { useState, useMemo } from 'react';
import {
  AlertTriangle,
  Clock,
  Sparkles,
  Search,
  Filter,
  Send,
  ArrowRight,
  ShieldAlert,
  Building2,
  CheckCircle2,
  FileText,
  UserCheck,
  PhoneCall,
  Flame,
  ChevronRight,
  ExternalLink,
  Smartphone,
} from 'lucide-react';
import { PassportApplication, NotificationLog } from '../../types/passport';
import {
  buildActionQueue,
  calculateActionQueueSummary,
  ActionQueueItem,
} from '../../utils/actionQueue';
import { CitizenPhoneSimulatorModal } from '../common/CitizenPhoneSimulatorModal';

interface ActionQueueTabProps {
  applications: PassportApplication[];
  onOpenTriageModal: (app: PassportApplication) => void;
  onUpdateStatus: (id: string, newStatus: PassportApplication['status'], notes?: string) => void;
  onAddNotification: (id: string, notif: NotificationLog) => void;
  onSelectApplication: (app: PassportApplication) => void;
}

export const ActionQueueTab: React.FC<ActionQueueTabProps> = ({
  applications,
  onOpenTriageModal,
  onUpdateStatus,
  onAddNotification,
  onSelectApplication,
}) => {
  const [filterType, setFilterType] = useState<'ALL' | 'REVERTED' | 'OVERDUE' | 'INCOMPLETE'>('ALL');
  const [officeFilter, setOfficeFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [quickReminderSentId, setQuickReminderSentId] = useState<string | null>(null);
  const [phoneSimApp, setPhoneSimApp] = useState<PassportApplication | null>(null);

  // Summary statistics
  const summary = useMemo(() => calculateActionQueueSummary(applications), [applications]);

  // Full action queue (sorted most-overdue first)
  const fullQueue = useMemo(() => buildActionQueue(applications), [applications]);

  // Filtered queue items
  const filteredQueue = useMemo(() => {
    return fullQueue.filter((item) => {
      // Type Filter
      if (filterType === 'REVERTED' && !item.isReverted) return false;
      if (filterType === 'OVERDUE' && !item.isOverdue) return false;
      if (filterType === 'INCOMPLETE' && !item.isIncomplete) return false;

      // Office Filter
      if (officeFilter !== 'ALL' && !item.application.collectionOffice.toLowerCase().includes(officeFilter.toLowerCase())) {
        return false;
      }

      // Search Filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = item.application.fullName.toLowerCase().includes(q);
        const matchesNrc = item.application.nrcNumber.toLowerCase().includes(q);
        const matchesTracking = item.application.trackingNumber.toLowerCase().includes(q);
        const matchesReason = item.primaryReason.toLowerCase().includes(q);
        if (!matchesName && !matchesNrc && !matchesTracking && !matchesReason) {
          return false;
        }
      }

      return true;
    });
  }, [fullQueue, filterType, officeFilter, searchQuery]);

  // Quick automated reminder dispatcher
  const handleQuickSendReminder = (app: PassportApplication) => {
    const isReverted = app.status === 'Reverted';
    const content = isReverted
      ? `MoHAIS OPAS: Dear ${app.fullName}, action required on reverted application #${app.trackingNumber}. Please upload required documentation on the OPAS portal.`
      : `MoHAIS OPAS: Dear ${app.fullName}, your passport application #${app.trackingNumber} requires completion. Please log in to complete your submission.`;

    onAddNotification(app.id, {
      id: `notif-${Date.now()}`,
      timestamp: new Date().toISOString(),
      channel: 'SMS',
      subject: isReverted ? 'Action Required: Reverted Passport Application' : 'Action Required: Application Incomplete',
      content,
      deliveryStatus: 'Delivered',
    });

    setQuickReminderSentId(app.id);
    setTimeout(() => {
      setQuickReminderSentId((curr) => (curr === app.id ? null : curr));
    }, 3500);
  };

  return (
    <div className="space-y-6">
      {/* SECTION BANNER */}
      <div className="bg-amber-500/10 border border-amber-300 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-amber-500 text-white rounded-lg shrink-0 mt-0.5">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                Staff Action Queue: Triage &amp; Human Intervention
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-200 text-amber-900 border border-amber-300">
                {summary.totalNeedingAttention} Cases Need Attention
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl leading-relaxed">
              Surfaces strictly cases requiring officer vetting, applicant outreach, or document corrections.
              Sorted automatically by longest aging duration to eliminate SLA bottlenecks.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => {
              setFilterType('ALL');
              setOfficeFilter('ALL');
              setSearchQuery('');
            }}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      </div>

      {/* TOP ROW: SUMMARY METRICS & PER-OFFICE BREAKDOWN */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Metric 1: Total & Category Breakdown */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
              <span className="font-semibold text-slate-700">Staff Attention Cases</span>
              <span className="text-[11px] text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded">
                {summary.totalNeedingAttention} of {applications.length} Active
              </span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-slate-900">{summary.totalNeedingAttention}</span>
              <span className="text-xs text-slate-500">cases requiring staff action</span>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-3 gap-1.5 text-center">
            <button
              onClick={() => setFilterType('REVERTED')}
              className={`p-1.5 rounded-lg border transition-colors cursor-pointer text-left ${
                filterType === 'REVERTED'
                  ? 'bg-red-100 border-red-300 text-red-900'
                  : 'bg-red-50/70 border-red-200 text-red-800 hover:bg-red-100'
              }`}
            >
              <div className="text-[10px] font-semibold text-red-700 uppercase">Reverted</div>
              <div className="text-lg font-black text-red-900">{summary.revertedCount}</div>
            </button>

            <button
              onClick={() => setFilterType('OVERDUE')}
              className={`p-1.5 rounded-lg border transition-colors cursor-pointer text-left ${
                filterType === 'OVERDUE'
                  ? 'bg-amber-100 border-amber-300 text-amber-900'
                  : 'bg-amber-50/70 border-amber-200 text-amber-800 hover:bg-amber-100'
              }`}
            >
              <div className="text-[10px] font-semibold text-amber-700 uppercase">Overdue 14d+</div>
              <div className="text-lg font-black text-amber-900">{summary.overdueCount}</div>
            </button>

            <button
              onClick={() => setFilterType('INCOMPLETE')}
              className={`p-1.5 rounded-lg border transition-colors cursor-pointer text-left ${
                filterType === 'INCOMPLETE'
                  ? 'bg-blue-100 border-blue-300 text-blue-900'
                  : 'bg-blue-50/70 border-blue-200 text-blue-800 hover:bg-blue-100'
              }`}
            >
              <div className="text-[10px] font-semibold text-blue-700 uppercase">Incomplete</div>
              <div className="text-lg font-black text-blue-900">{summary.incompleteCount}</div>
            </button>
          </div>
        </div>

        {/* Metric 2: Longest Wait Duration */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
              <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 text-red-600" />
                Longest Waiting Case
              </span>
              <span className="text-[11px] font-bold text-red-700 bg-red-50 px-1.5 py-0.5 rounded border border-red-200">
                SLA Alert
              </span>
            </div>

            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-red-600">{summary.longestWaitDays}</span>
              <span className="text-xs text-slate-500 font-semibold">Days in Stage</span>
            </div>
          </div>

          {summary.longestWaitCase ? (
            <div className="mt-3 pt-3 border-t border-slate-100 bg-slate-50 rounded-lg p-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900">{summary.longestWaitCase.fullName}</span>
                <span className="text-[10px] font-mono text-slate-500">{summary.longestWaitCase.trackingNumber}</span>
              </div>
              <div className="text-[11px] text-slate-600 mt-0.5 flex items-center justify-between">
                <span>{summary.longestWaitCase.collectionOffice.replace(' Passport Office', '')}</span>
                <button
                  onClick={() => onOpenTriageModal(summary.longestWaitCase!)}
                  className="text-emerald-700 hover:text-emerald-900 font-bold flex items-center gap-0.5 cursor-pointer text-[11px]"
                >
                  <span>Triage Now</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          ) : (
            <div className="text-xs text-slate-400 mt-4">No overdue applications.</div>
          )}
        </div>

        {/* Metric 3: Backlog Breakdown by Passport Office */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="font-semibold text-slate-700 flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-slate-500" />
              Backlog by Passport Office
            </span>
            <span className="text-[10px] text-slate-400">At a glance</span>
          </div>

          <div className="space-y-2.5">
            {summary.officeBreakdown.map((item) => (
              <div key={item.office} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-slate-700 truncate max-w-[150px]">{item.office}</span>
                  <span className="font-bold text-slate-900">
                    {item.count} <span className="text-[10px] text-slate-400 font-normal">({item.percentage}%)</span>
                  </span>
                </div>
                <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-600 rounded-full transition-all"
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* FILTER & SEARCH BAR */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        {/* Category Filter Pills */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <button
            onClick={() => setFilterType('ALL')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-colors cursor-pointer ${
              filterType === 'ALL'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            All Action Required ({summary.totalNeedingAttention})
          </button>
          <button
            onClick={() => setFilterType('REVERTED')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-colors cursor-pointer flex items-center gap-1.5 ${
              filterType === 'REVERTED'
                ? 'bg-red-700 text-white'
                : 'bg-red-50 hover:bg-red-100 text-red-800 border border-red-200'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            Reverted ({summary.revertedCount})
          </button>
          <button
            onClick={() => setFilterType('OVERDUE')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-colors cursor-pointer flex items-center gap-1.5 ${
              filterType === 'OVERDUE'
                ? 'bg-amber-600 text-white'
                : 'bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            Overdue 14d+ ({summary.overdueCount})
          </button>
          <button
            onClick={() => setFilterType('INCOMPLETE')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-colors cursor-pointer flex items-center gap-1.5 ${
              filterType === 'INCOMPLETE'
                ? 'bg-blue-700 text-white'
                : 'bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            Incomplete Intake ({summary.incompleteCount})
          </button>
        </div>

        {/* Search & Office Dropdown */}
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search queue..."
              className="text-xs pl-8 pr-2.5 py-1.5 border border-slate-300 rounded-lg bg-white w-40 sm:w-48 focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <select
            value={officeFilter}
            onChange={(e) => setOfficeFilter(e.target.value)}
            className="text-xs px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-700 font-medium"
          >
            <option value="ALL">All Stations</option>
            <option value="Lusaka">Lusaka Central</option>
            <option value="Ndola">Ndola Regional</option>
            <option value="Livingstone">Livingstone Regional</option>
          </select>
        </div>
      </div>

      {/* ACTION QUEUE LIST: SORTED MOST-OVERDUE FIRST WITH ONE-LINE REASONS */}
      <div className="space-y-3">
        {filteredQueue.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
            <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto mb-2" />
            <h4 className="text-sm font-bold text-slate-900">Queue is Clear for this Filter</h4>
            <p className="text-xs text-slate-500 mt-1">
              No applications currently require attention matching your search and category filter.
            </p>
          </div>
        ) : (
          filteredQueue.map((item, index) => {
            const app = item.application;
            const days = app.daysInStatus || 0;
            const isReminderSent = quickReminderSentId === app.id;

            return (
              <div
                key={app.id}
                className={`bg-white border rounded-xl p-4 shadow-xs transition-all hover:border-slate-400 ${
                  item.severity === 'CRITICAL'
                    ? 'border-red-300/80 bg-red-50/20'
                    : item.severity === 'HIGH'
                    ? 'border-amber-300/80 bg-amber-50/15'
                    : 'border-slate-200'
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                  {/* Left Column: Overdue badge, Name, NRC, Office */}
                  <div className="flex items-start gap-3">
                    {/* Rank & Days Pill */}
                    <div className="text-center shrink-0">
                      <div
                        className={`w-14 py-2 rounded-lg font-black text-center border ${
                          days >= 14
                            ? 'bg-red-600 text-white border-red-700 shadow-xs'
                            : days >= 8
                            ? 'bg-amber-500 text-white border-amber-600'
                            : 'bg-slate-700 text-white border-slate-800'
                        }`}
                      >
                        <div className="text-base leading-tight font-extrabold">{days}d</div>
                        <div className="text-[9px] uppercase tracking-wider font-semibold opacity-90">Wait</div>
                      </div>
                      <div className="text-[10px] text-slate-400 mt-1 font-mono">#{index + 1} in queue</div>
                    </div>

                    {/* Applicant Identity & Metadata */}
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-bold text-slate-900 hover:text-emerald-800 cursor-pointer" onClick={() => onSelectApplication(app)}>
                          {app.fullName}
                        </span>

                        <span className="font-mono text-[11px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded border border-slate-200">
                          {app.trackingNumber}
                        </span>

                        {app.isUrgent && (
                          <span className="bg-red-100 text-red-800 border border-red-200 text-[10px] font-bold px-1.5 py-0.5 rounded">
                            EXPRESS SPEED
                          </span>
                        )}

                        {/* Category Badges */}
                        {item.isReverted && (
                          <span className="bg-red-50 text-red-700 border border-red-200 text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3" />
                            Reverted
                          </span>
                        )}

                        {item.isOverdue && (
                          <span className="bg-amber-50 text-amber-800 border border-amber-200 text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            Overdue 14d+
                          </span>
                        )}

                        {item.isIncomplete && (
                          <span className="bg-blue-50 text-blue-800 border border-blue-200 text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1">
                            <FileText className="w-3 h-3" />
                            Incomplete Intake
                          </span>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500">
                        <span>NRC: <strong className="text-slate-700 font-mono">{app.nrcNumber}</strong></span>
                        <span>Station: <strong className="text-slate-700">{app.collectionOffice.replace(' Passport Office', '')}</strong></span>
                        <span>Passport: <strong className="text-slate-700">{app.passportType}</strong></span>
                        <span>Fee: <strong className={app.feePaid ? 'text-emerald-700' : 'text-red-600'}>{app.feePaid ? `Paid (ZMW ${app.feeAmount})` : 'Unpaid'}</strong></span>
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Fast Action Buttons */}
                  <div className="flex items-center gap-2 self-start lg:self-center shrink-0">
                    <button
                      onClick={() => setPhoneSimApp(app)}
                      className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors cursor-pointer"
                      title="Inspect SMS on Citizen Handset"
                    >
                      <Smartphone className="w-3.5 h-3.5 text-slate-600" />
                    </button>

                    <button
                      onClick={() => handleQuickSendReminder(app)}
                      disabled={isReminderSent}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                        isReminderSent
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : 'bg-white hover:bg-slate-50 text-slate-700 border border-slate-300'
                      }`}
                      title="Send automated SMS reminder directly to applicant"
                    >
                      {isReminderSent ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Reminder Dispatched!</span>
                        </>
                      ) : (
                        <>
                          <Send className="w-3.5 h-3.5 text-slate-500" />
                          <span>Send Reminder</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => onOpenTriageModal(app)}
                      className="px-3.5 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
                      <span>Triage Case</span>
                      <ChevronRight className="w-3.5 h-3.5 opacity-70" />
                    </button>
                  </div>
                </div>

                {/* ONE-LINE ACTION REASON CONTAINER */}
                <div className="mt-3 pt-2.5 border-t border-slate-100">
                  <div className="bg-slate-50 border-l-4 border-amber-500 rounded-r-lg px-3 py-2 flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-bold text-slate-800 shrink-0">Staff Attention Reason:</span>
                      <span className="text-slate-700 font-medium">{item.primaryReason}</span>
                    </div>

                    <button
                      onClick={() => onSelectApplication(app)}
                      className="text-[11px] text-slate-500 hover:text-emerald-800 font-semibold shrink-0 flex items-center gap-1 cursor-pointer"
                    >
                      <span>Preview File</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Citizen Phone Handset Simulator Modal */}
      {phoneSimApp && (
        <CitizenPhoneSimulatorModal
          application={phoneSimApp}
          onClose={() => setPhoneSimApp(null)}
        />
      )}
    </div>
  );
};
