import React from 'react';
import { ShieldCheck, TrendingUp } from 'lucide-react';

export const PilotEvaluationReport: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Governance & Sponsorship Header */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800">
              UNIPODS AI for Public Good Challenge · MoHAIS Initiative
            </span>
            <h2 className="text-lg font-bold text-slate-900 mt-0.5">
              Pilot Evaluation Framework &amp; Operational Metrics
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Operational Performance Evaluation and Baseline Metrics
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              Pilot Active (Week 4 of 6)
            </span>
          </div>
        </div>

        {/* Stakeholder Roles Table */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-4 text-xs">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div className="text-slate-500 text-[11px]">Executive Sponsor</div>
            <div className="font-semibold text-slate-900 mt-0.5">Permanent Secretary</div>
            <div className="text-[11px] text-slate-500">Ministry of Home Affairs &amp; Internal Security</div>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div className="text-slate-500 text-[11px]">Programme Focal Point</div>
            <div className="font-semibold text-slate-900 mt-0.5">Spriano Banda</div>
            <div className="text-[11px] text-slate-500">Chief Systems Development Officer</div>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div className="text-slate-500 text-[11px]">Business Stakeholders</div>
            <div className="font-semibold text-slate-900 mt-0.5">Passport Office Leadership</div>
            <div className="text-[11px] text-slate-500">Vetting Officers &amp; Registry Administrators</div>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div className="text-slate-500 text-[11px]">Technical Stakeholders</div>
            <div className="font-semibold text-slate-900 mt-0.5">MoHAIS ICT Department</div>
            <div className="text-[11px] text-slate-500">OPAS Technical &amp; Data Administrators</div>
          </div>
        </div>
      </div>

      {/* Success Indicators Matrix */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-700" />
            Evaluation Indicators: Baseline vs. Pilot Results
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Technical validation findings comparing pre-pilot baseline with AI-assisted enhancement layer
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-semibold">
                <th className="py-2.5 px-3">Evaluation Area</th>
                <th className="py-2.5 px-3">Primary Indicator</th>
                <th className="py-2.5 px-3">Baseline (Legacy OPAS)</th>
                <th className="py-2.5 px-3">Pilot Performance</th>
                <th className="py-2.5 px-3">Measurement Approach</th>
                <th className="py-2.5 px-3 text-right">Variance Impact</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-900">Contact Validation</td>
                <td className="py-2.5 px-3">Invalid phone / email formats flagged pre-submission</td>
                <td className="py-2.5 px-3 text-slate-500">18.6% delivery failure</td>
                <td className="py-2.5 px-3 font-semibold text-emerald-700">1.8% failure (90% caught)</td>
                <td className="py-2.5 px-3 text-slate-500">RFC regex &amp; E.164 country code validator</td>
                <td className="py-2.5 px-3 text-right font-semibold text-emerald-700">-90.3% error rate</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-900">Application Completion</td>
                <td className="py-2.5 px-3">Paid-but-unsubmitted cases detected &amp; prompted</td>
                <td className="py-2.5 px-3 text-slate-500">Avg. 22 days dormant</td>
                <td className="py-2.5 px-3 font-semibold text-emerald-700">Avg. 3.2 days to submit</td>
                <td className="py-2.5 px-3 text-slate-500">Automated workflow scan &amp; scheduled SMS</td>
                <td className="py-2.5 px-3 text-right font-semibold text-emerald-700">+85.4% velocity</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-900">Reverted Case Management</td>
                <td className="py-2.5 px-3">Backlog clearance of ~1,500 outstanding reverted cases</td>
                <td className="py-2.5 px-3 text-slate-500">14% monthly resolution</td>
                <td className="py-2.5 px-3 font-semibold text-emerald-700">58.6% monthly resolution</td>
                <td className="py-2.5 px-3 text-slate-500">Targeted reversion remedy notices with pre-check</td>
                <td className="py-2.5 px-3 text-right font-semibold text-emerald-700">+4.2x clearance rate</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-900">Citizen Assistance</td>
                <td className="py-2.5 px-3">Guidance accuracy and self-service FAQ resolution</td>
                <td className="py-2.5 px-3 text-slate-500">100% manual officer enquiries</td>
                <td className="py-2.5 px-3 font-semibold text-emerald-700">76.2% resolved via AI Assistant</td>
                <td className="py-2.5 px-3 text-slate-500">Approved MoHAIS FAQ grounding model</td>
                <td className="py-2.5 px-3 text-right font-semibold text-emerald-700">-76% manual volume</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-900">Operational Efficiency</td>
                <td className="py-2.5 px-3">Passport officer hours on repetitive phone/counter queries</td>
                <td className="py-2.5 px-3 text-slate-500">3.5 hrs / officer / day</td>
                <td className="py-2.5 px-3 font-semibold text-emerald-700">0.8 hrs / officer / day</td>
                <td className="py-2.5 px-3 text-slate-500">Weekly officer workload timesheet comparison</td>
                <td className="py-2.5 px-3 text-right font-semibold text-emerald-700">-77% time diverted</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
