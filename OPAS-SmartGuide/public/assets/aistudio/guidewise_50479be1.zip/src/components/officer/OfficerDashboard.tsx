import React, { useState, useMemo, useEffect } from 'react';
import { useChat } from '../../context/ChatContext';
import {
  Users,
  AlertCircle,
  Clock,
  CheckCircle,
  FileWarning,
  Send,
  Search,
  Filter,
  Sparkles,
  ArrowUpRight,
  ArrowRight,
  TrendingDown,
  TrendingUp,
  BarChart,
  BarChart2,
  Calendar,
  Layers,
  ShieldCheck,
  CheckCircle2,
  RefreshCw,
  X,
  Activity,
  Download,
  MapPin,
  SlidersHorizontal,
  DollarSign,
  FileSpreadsheet,
  PieChart as PieChartIcon,
  LayoutGrid,
  FileText,
  UserCheck,
  Headphones,
  GitBranch,
  MessageSquare,
  Tags,
  Plus,
  Minus,
  ChevronDown,
} from 'lucide-react';
import { PassportApplication, NotificationLog } from '../../types/passport';
import { CaseTriageModal } from './CaseTriageModal';
import { PilotEvaluationReport } from './PilotEvaluationReport';
import { ActionQueueTab } from './ActionQueueTab';
import { ExecutiveReportModal } from './ExecutiveReportModal';
import { calculateActionQueueSummary, buildActionQueue } from '../../utils/actionQueue';
import { validatePhoneNumber, validateEmail } from '../../utils/validation';
import { PillarsModule } from '../common/PillarsModule';
import {
  ResponsiveContainer,
  Tooltip,
  Legend,
  BarChart as RechartsBarChart,
  Bar,
  AreaChart,
  Area,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
} from 'recharts';

interface OfficerDashboardProps {
  applications: PassportApplication[];
  onUpdateStatus: (id: string, newStatus: PassportApplication['status'], notes?: string) => void;
  onAddNotification: (id: string, notif: NotificationLog) => void;
  onSelectApplication: (app: PassportApplication) => void;
  selectedAppForCitizenView?: PassportApplication;
  onOpenAssistant?: () => void;
}

// Circular Radial Gauge Component matching BI Template in image_02db743a.png
const RadialGauge: React.FC<{
  percentage: number;
  trend?: string;
  color: string;
  size?: number;
}> = ({ percentage, trend = '+7%', color, size = 96 }) => {
  const strokeWidth = 8;
  const radius = (size - strokeWidth * 2) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset =
    circumference - (circumference * Math.min(100, Math.max(0, percentage))) / 100;

  return (
    <div
      className="relative flex items-center justify-center shrink-0"
      style={{ width: size, height: size }}
    >
      <svg width={size} height={size} className="transform -rotate-90">
        {/* Track circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="#1e2536"
          strokeWidth={strokeWidth}
          fill="transparent"
        />
        {/* Progress circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          fill="transparent"
          className="transition-all duration-700 ease-out"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        <span className="text-lg font-black text-white font-mono leading-none">
          {percentage}%
        </span>
        {trend && (
          <span
            className="text-[10px] font-bold font-mono mt-0.5 tracking-tight"
            style={{ color }}
          >
            {trend}
          </span>
        )}
      </div>
    </div>
  );
};

export const OfficerDashboard: React.FC<OfficerDashboardProps> = ({
  applications,
  onUpdateStatus,
  onAddNotification,
  onSelectApplication,
  onOpenAssistant,
}) => {
  const [activeTab, setActiveTab] = useState<
    'overview' | 'action-queue' | 'pillars' | 'registry' | 'evaluation'
  >('overview');
  const { setCurrentSection } = useChat();

  // BI Executive Slicers State
  const [dateRange, setDateRange] = useState<'7D' | '30D' | 'Q3_2026' | 'YTD_2026' | 'ALL'>('30D');
  const [selectedStation, setSelectedStation] = useState<string>('ALL');
  const [detailTableFilter, setDetailTableFilter] = useState<string>('All');
  const [expandedRows, setExpandedRows] = useState<Record<string, boolean>>({
    ucc_sales: true,
  });

  useEffect(() => {
    const tabMap: Record<string, string> = {
      overview: 'Officer Dashboard - Executive BI Interface',
      'action-queue': 'Officer Dashboard - Action Queue',
      registry: 'Officer Dashboard - Case Registry',
      evaluation: 'Officer Dashboard - Pilot Evaluation',
      pillars: 'Officer Dashboard - Smart Features',
    };
    setCurrentSection(tabMap[activeTab] || 'Officer Dashboard');
  }, [activeTab, setCurrentSection]);

  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCaseForModal, setSelectedCaseForModal] = useState<PassportApplication | null>(null);
  const [isExecutiveReportOpen, setIsExecutiveReportOpen] = useState(false);
  const [batchReminderSent, setBatchReminderSent] = useState(false);

  // Compute Live Metrics from applications
  const metrics = useMemo(() => {
    const total = applications.length;
    const reverted = applications.filter((a) => a.status === 'Reverted');
    const paidUnsubmitted = applications.filter((a) => a.status === 'Paid - Unsubmitted');
    const underReview = applications.filter((a) => a.status === 'Submitted - Under Review');
    const biometrics = applications.filter((a) => a.status === 'Biometrics Scheduled');
    const ready = applications.filter((a) => a.status === 'Ready for Collection');

    const invalidContactCount = applications.filter((a) => {
      const p = validatePhoneNumber(a.contact.phone, a.contact.phoneCountryCode);
      const e = validateEmail(a.contact.email);
      return !p.isValid || p.warning || !e.isValid || e.warning;
    }).length;

    const feeHeld = paidUnsubmitted.reduce((acc, curr) => acc + (curr.feeAmount || 500), 0);

    return {
      total,
      revertedCount: reverted.length,
      paidUnsubmittedCount: paidUnsubmitted.length,
      underReviewCount: underReview.length,
      biometricsCount: biometrics.length,
      readyCount: ready.length,
      invalidContactCount,
      feeHeld,
    };
  }, [applications]);

  // Action Queue summary
  const actionSummary = useMemo(() => calculateActionQueueSummary(applications), [applications]);
  const actionQueueItems = useMemo(() => buildActionQueue(applications), [applications]);

  // Workload Velocity Trend Series (Area Chart with Glowing Cyan Line)
  const agentWorkloadData = useMemo(() => {
    return [
      { day: 'May 1', workload: 68, target: 55 },
      { day: 'May 2', workload: 71, target: 55 },
      { day: 'May 3', workload: 59, target: 55 },
      { day: 'May 4', workload: 67, target: 55 },
      { day: 'May 5', workload: 63, target: 55 },
      { day: 'May 6', workload: 82, target: 55 },
      { day: 'May 7', workload: 76, target: 55 },
    ];
  }, []);

  // Status Time in hours Grouped Bar Chart Data (5 columns per day)
  const statusTimeBarData = useMemo(() => {
    return [
      { day: 'May 1', available: 26, inCall: 31, away: 18, dnd: 7, busy: 18 },
      { day: 'May 2', available: 42, inCall: 32, away: 12, dnd: 8, busy: 7 },
      { day: 'May 3', available: 45, inCall: 31, away: 38, dnd: 8, busy: 13 },
      { day: 'May 4', available: 43, inCall: 19, away: 24, dnd: 8, busy: 17 },
      { day: 'May 5', available: 26, inCall: 39, away: 24, dnd: 6, busy: 7 },
      { day: 'May 6', available: 20, inCall: 31, away: 41, dnd: 5, busy: 6 },
      { day: 'May 7', available: 26, inCall: 43, away: 23, dnd: 6, busy: 8 },
    ];
  }, []);

  // Status Detail Matrix Rows matching BI template
  const statusDetailRows = useMemo(() => {
    return [
      {
        key: 'ucc_sales',
        name: 'ucc_sales',
        stationLabel: 'Lusaka HQ - Intake & Vetting',
        available: { time: '00:01:27', pct: 38 },
        inCall: { time: '00:01:27', pct: 38 },
        away: { time: '00:01:27', pct: 38 },
        dnd: { time: '00:01:27', pct: 38 },
        busy: { time: '00:01:27', pct: 38 },
        reasonCode: { time: '00:01:27', pct: 38 },
        cases: applications.filter(
          (a) => a.collectionOffice.includes('Lusaka') || a.status === 'Submitted - Under Review'
        ),
      },
      {
        key: 'ucc_marketing',
        name: 'ucc_marketing',
        stationLabel: 'Ndola Regional - Biometrics Capture',
        available: { time: '00:01:27', pct: 45 },
        inCall: { time: '00:01:27', pct: 45 },
        away: { time: '00:01:27', pct: 45 },
        dnd: { time: '00:01:27', pct: 45 },
        busy: { time: '00:01:27', pct: 45 },
        reasonCode: { time: '00:01:27', pct: 45 },
        cases: applications.filter(
          (a) => a.collectionOffice.includes('Ndola') || a.status === 'Biometrics Scheduled'
        ),
      },
      {
        key: 'ucc_backoffice',
        name: 'ucc_backoffice',
        stationLabel: 'Kitwe Centre - Remediation & Review',
        available: { time: '00:01:27', pct: 51 },
        inCall: { time: '00:01:27', pct: 51 },
        away: { time: '00:01:27', pct: 51 },
        dnd: { time: '00:01:27', pct: 51 },
        busy: { time: '00:01:27', pct: 51 },
        reasonCode: { time: '00:01:27', pct: 51 },
        cases: applications.filter((a) => a.status === 'Reverted'),
      },
      {
        key: 'ucc_production',
        name: 'ucc_production',
        stationLabel: 'Livingstone Station - Booklet Personalization',
        available: { time: '00:01:27', pct: 38 },
        inCall: { time: '00:01:27', pct: 38 },
        away: { time: '00:01:27', pct: 38 },
        dnd: { time: '00:01:27', pct: 38 },
        busy: { time: '00:01:27', pct: 38 },
        reasonCode: { time: '00:01:27', pct: 38 },
        cases: applications.filter(
          (a) => a.collectionOffice.includes('Livingstone') || a.status === 'Paid - Unsubmitted'
        ),
      },
      {
        key: 'ucc_support',
        name: 'ucc_support',
        stationLabel: 'Solwezi Centre - Counter Dispatch',
        available: { time: '00:01:27', pct: 45 },
        inCall: { time: '00:01:27', pct: 45 },
        away: { time: '00:01:27', pct: 45 },
        dnd: { time: '00:01:27', pct: 45 },
        busy: { time: '00:01:27', pct: 45 },
        reasonCode: { time: '00:01:27', pct: 45 },
        cases: applications.filter((a) => a.status === 'Ready for Collection'),
      },
      {
        key: 'ucc_purchasing',
        name: 'ucc_purchasing',
        stationLabel: 'Chipata Office - Security Stationery',
        available: { time: '00:01:27', pct: 51 },
        inCall: { time: '00:01:27', pct: 51 },
        away: { time: '00:01:27', pct: 51 },
        dnd: { time: '00:01:27', pct: 51 },
        busy: { time: '00:01:27', pct: 51 },
        reasonCode: { time: '00:01:27', pct: 51 },
        cases: applications.filter((a) => a.collectionOffice.includes('Chipata')),
      },
    ];
  }, [applications]);

  const toggleRow = (key: string) => {
    setExpandedRows((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // Filtered applications for Registry and search
  const filteredApplications = useMemo(() => {
    return applications.filter((app) => {
      const matchesStatus =
        statusFilter === 'ALL' ||
        (statusFilter === 'REVERTED' && app.status === 'Reverted') ||
        (statusFilter === 'PAID_UNSUBMITTED' && app.status === 'Paid - Unsubmitted') ||
        (statusFilter === 'REVIEW' && app.status === 'Submitted - Under Review') ||
        (statusFilter === 'BIOMETRICS' && app.status === 'Biometrics Scheduled') ||
        (statusFilter === 'READY' && app.status === 'Ready for Collection');

      const matchesStation =
        selectedStation === 'ALL' ||
        app.collectionOffice.toLowerCase().includes(selectedStation.toLowerCase());

      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        q === '' ||
        app.fullName.toLowerCase().includes(q) ||
        app.trackingNumber.toLowerCase().includes(q) ||
        app.nrcNumber.toLowerCase().includes(q) ||
        app.contact.phone.includes(q) ||
        app.contact.email.toLowerCase().includes(q);

      return matchesStatus && matchesStation && matchesSearch;
    });
  }, [applications, statusFilter, selectedStation, searchQuery]);

  // Client-side BI CSV Dataset Export
  const handleExportBICSV = () => {
    const headers = [
      'Tracking Number',
      'Applicant Full Name',
      'NRC Number',
      'Passport Type',
      'Service Speed',
      'Status',
      'Days In Status',
      'Collection Office',
      'Province',
      'Phone',
      'Email',
      'Fee Amount (ZMW)',
      'Fee Paid',
      'Express Urgent',
      'Reversion Reason',
    ];
    const rows = filteredApplications.map((app) => [
      app.trackingNumber,
      `"${(app.fullName || '').replace(/"/g, '""')}"`,
      app.nrcNumber,
      `"${app.passportType}"`,
      `"${app.serviceSpeed}"`,
      `"${app.status}"`,
      app.daysInStatus,
      `"${app.collectionOffice}"`,
      `"${app.contact.province || ''}"`,
      `"${app.contact.phone}"`,
      `"${app.contact.email}"`,
      app.feeAmount || 500,
      app.feePaid ? 'TRUE' : 'FALSE',
      app.isUrgent ? 'TRUE' : 'FALSE',
      `"${(app.reversionReason || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,\uFEFF' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute(
      'download',
      `MoHAIS_OPAS_BI_Telemetry_${new Date().toISOString().split('T')[0]}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Batch trigger automated reminders for aged cases
  const handleBatchTriggerReminders = () => {
    applications.forEach((app) => {
      if (app.status === 'Reverted' || app.status === 'Paid - Unsubmitted') {
        const notif: NotificationLog = {
          id: `batch-${Date.now()}-${app.id}`,
          timestamp: new Date().toISOString(),
          channel: 'SMS',
          subject: 'MoHAIS OPAS Scheduled Automated Notice',
          content:
            app.status === 'Reverted'
              ? `MoHAIS OPAS: Dear ${app.fullName}, your passport application #${app.trackingNumber} requires document correction to resume processing. Log into opas.mohais.gov.zm`
              : `MoHAIS OPAS: Dear ${app.fullName}, we received your payment for #${app.trackingNumber}. Please complete final submission & schedule biometrics.`,
          deliveryStatus: 'Delivered',
        };
        onAddNotification(app.id, notif);
      }
    });
    setBatchReminderSent(true);
    setTimeout(() => setBatchReminderSent(false), 4000);
  };

  return (
    <div className="flex flex-col md:flex-row gap-4 bg-[#0b0e14] text-slate-100 min-h-[960px] p-2 sm:p-4 rounded-3xl font-sans">
      {/* ============================================================ */}
      {/* 1. LEFT NAVIGATION RAIL (Vivid Cobalt Blue #0062ff) */}
      {/* ============================================================ */}
      <aside className="w-full md:w-20 lg:w-24 shrink-0 bg-[#0062ff] rounded-2xl md:rounded-3xl flex md:flex-col items-center justify-between md:justify-start py-4 px-3 md:px-0 text-white shadow-2xl space-y-0 md:space-y-6">
        {/* 4-Tile Geometric Logo Block at Top */}
        <div className="flex items-center md:flex-col gap-2">
          <div className="w-9 h-9 grid grid-cols-2 gap-1 p-0.5 bg-black/10 rounded-lg shadow-inner">
            <div className="bg-[#FF6B4A] rounded-xs" />
            <div className="bg-[#00c2ff] rounded-xs" />
            <div className="bg-[#FFB020] rounded-xs" />
            <div className="bg-[#00D492] rounded-xs" />
          </div>
        </div>

        {/* Vertical Navigation Items */}
        <nav className="flex md:flex-col items-center gap-1 md:gap-3 text-white overflow-x-auto md:overflow-visible w-full px-1">
          {/* Item 1: Status Overview (Executive BI Interface) */}
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all cursor-pointer w-full text-center ${
              activeTab === 'overview'
                ? 'bg-[#004ecc] text-white shadow-md'
                : 'text-white/80 hover:text-white hover:bg-white/10'
            }`}
            title="Status Overview (Executive BI)"
          >
            <LayoutGrid className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-semibold leading-tight tracking-tight">
              Status
              <br />
              Overview
            </span>
          </button>

          {/* Item 2: Action Queue */}
          <button
            onClick={() => setActiveTab('action-queue')}
            className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all cursor-pointer w-full text-center relative ${
              activeTab === 'action-queue'
                ? 'bg-[#004ecc] text-white shadow-md'
                : 'text-white/80 hover:text-white hover:bg-white/10'
            }`}
            title="Action Queue"
          >
            <div className="relative">
              <AlertCircle className="w-5 h-5 mb-1" />
              {actionSummary.totalNeedingAttention > 0 && (
                <span className="absolute -top-1 -right-2 bg-[#FF6B4A] text-white text-[9px] font-black rounded-full px-1 py-0.2 shadow-xs">
                  {actionSummary.totalNeedingAttention}
                </span>
              )}
            </div>
            <span className="text-[10px] font-semibold leading-tight tracking-tight">
              Action
              <br />
              Queue
            </span>
          </button>

          {/* Item 3: Application Registry */}
          <button
            onClick={() => setActiveTab('registry')}
            className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all cursor-pointer w-full text-center ${
              activeTab === 'registry'
                ? 'bg-[#004ecc] text-white shadow-md'
                : 'text-white/80 hover:text-white hover:bg-white/10'
            }`}
            title="Case Registry"
          >
            <FileText className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-semibold leading-tight tracking-tight">
              Case
              <br />
              Registry
            </span>
          </button>

          {/* Item 4: Smart Pillars */}
          <button
            onClick={() => setActiveTab('pillars')}
            className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all cursor-pointer w-full text-center ${
              activeTab === 'pillars'
                ? 'bg-[#004ecc] text-white shadow-md'
                : 'text-white/80 hover:text-white hover:bg-white/10'
            }`}
            title="Smart Service Pillars"
          >
            <Sparkles className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-semibold leading-tight tracking-tight">
              Smart
              <br />
              Pillars
            </span>
          </button>

          {/* Item 5: Pilot SLA Evaluation */}
          <button
            onClick={() => setActiveTab('evaluation')}
            className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all cursor-pointer w-full text-center ${
              activeTab === 'evaluation'
                ? 'bg-[#004ecc] text-white shadow-md'
                : 'text-white/80 hover:text-white hover:bg-white/10'
            }`}
            title="Pilot SLA Evaluation"
          >
            <ShieldCheck className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-semibold leading-tight tracking-tight">
              Pilot
              <br />
              SLA
            </span>
          </button>
        </nav>

        {/* Bottom subtle indicator */}
        <div className="hidden md:flex flex-col items-center mt-auto pt-4 text-white/60">
          <div className="w-2 h-2 rounded-full bg-[#00D492] animate-pulse" />
          <span className="text-[9px] font-mono mt-1">v3.2</span>
        </div>
      </aside>

      {/* ============================================================ */}
      {/* 2. MAIN CONTENT AREA (Deep Obsidian Charcoal #0b0e14) */}
      {/* ============================================================ */}
      <div className="flex-1 space-y-4 min-w-0">
        {/* Header Bar matching BI Template */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-2 border-b border-[#1b2334]">
          <div>
            <h1 className="text-2xl font-black text-white tracking-tight">
              Status Overview
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              MoHAIS OPAS Real-time Queue Intelligence &amp; Workload Distribution
            </p>
          </div>

          {/* Interactive Controls & Slicers Toolbar */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {/* Timeframe Slicer Pills */}
            <div className="flex items-center bg-[#131722] border border-[#1e2536] p-1 rounded-lg">
              {[
                { id: '7D', label: '7D' },
                { id: '30D', label: '30D' },
                { id: 'Q3_2026', label: 'Q3' },
                { id: 'YTD_2026', label: 'YTD' },
                { id: 'ALL', label: 'All' },
              ].map((t) => (
                <button
                  key={t.id}
                  onClick={() => setDateRange(t.id as any)}
                  className={`px-2.5 py-1 rounded-md font-semibold transition-colors cursor-pointer ${
                    dateRange === t.id
                      ? 'bg-[#0062ff] text-white shadow-xs'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {/* Station Dropdown */}
            <select
              value={selectedStation}
              onChange={(e) => setSelectedStation(e.target.value)}
              className="bg-[#131722] border border-[#1e2536] text-white text-xs font-semibold rounded-lg py-1.5 px-3 focus:outline-hidden focus:border-[#0062ff] cursor-pointer"
            >
              <option value="ALL">All Stations (National)</option>
              <option value="Lusaka">Lusaka HQ</option>
              <option value="Ndola">Ndola Regional</option>
              <option value="Kitwe">Kitwe Centre</option>
              <option value="Livingstone">Livingstone Station</option>
              <option value="Solwezi">Solwezi Centre</option>
              <option value="Chipata">Chipata Office</option>
            </select>

            {/* Export Dataset Button */}
            <button
              onClick={handleExportBICSV}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#131722] hover:bg-[#1b2334] text-slate-200 border border-[#1e2536] rounded-lg transition-colors cursor-pointer font-semibold"
              title="Export filtered records as CSV"
            >
              <Download className="w-3.5 h-3.5 text-[#00c2ff]" />
              <span>Export CSV</span>
            </button>

            {/* Executive Briefing Modal */}
            <button
              onClick={() => setIsExecutiveReportOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#0062ff] hover:bg-[#0052d9] text-white rounded-lg transition-colors cursor-pointer font-semibold shadow-xs"
              title="View Executive Summary"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Executive Briefing</span>
            </button>

            {/* Batch Remind Button */}
            <button
              onClick={handleBatchTriggerReminders}
              disabled={batchReminderSent}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#FFB020] hover:bg-amber-500 text-slate-950 font-bold rounded-lg transition-colors cursor-pointer shadow-xs"
              title="Trigger notifications for stalled applications"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{batchReminderSent ? 'Dispatched!' : 'Batch Remind'}</span>
            </button>
          </div>
        </div>

        {/* Global Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search active applications by NRC number (e.g. 294812/11/1), Full Name, or Tracking Ref..."
            className="w-full text-xs pl-9 pr-8 py-2.5 bg-[#131722] border border-[#1e2536] rounded-xl text-white placeholder-slate-500 focus:outline-hidden focus:border-[#0062ff]"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* ============================================================ */}
        {/* VIEW 1: EXECUTIVE BI INTERFACE (Status Overview) */}
        {/* ============================================================ */}
        {activeTab === 'overview' && (
          <div className="space-y-4">
            {/* Split layout: Left 5 Radial Gauge Cards, Right Analytics Grid */}
            <div className="flex flex-col xl:flex-row gap-4 items-start">
              {/* LEFT COLUMN: 5 Radial Gauge KPI Cards matching BI Template */}
              <div className="w-full xl:w-72 space-y-3 shrink-0">
                {/* 1. Available / Under Vetting (Mint Green #00D492) */}
                <div
                  onClick={() => {
                    setStatusFilter('REVIEW');
                    setActiveTab('registry');
                  }}
                  className="bg-[#121622] border border-[#1e2536] hover:border-[#00D492]/50 p-3.5 rounded-2xl flex items-center gap-3.5 shadow-md cursor-pointer transition-all group"
                >
                  <RadialGauge percentage={21} trend="+7%" color="#00D492" size={88} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-[#00D492] tracking-tight">
                        Available
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-0.5">
                      <GitBranch className="w-3 h-3 text-slate-400" />
                      <span className="truncate">UCC_sales</span>
                    </div>
                    <div className="text-lg font-mono font-black text-white mt-1">
                      115:37:15
                    </div>
                    <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-0.5">
                      <Clock className="w-3 h-3 text-slate-500" />
                      <span>Time Total ({metrics.underReviewCount} cases)</span>
                    </div>
                  </div>
                </div>

                {/* 2. In Call / Biometrics Scheduled (Vivid Blue #0088FE) */}
                <div
                  onClick={() => {
                    setStatusFilter('BIOMETRICS');
                    setActiveTab('registry');
                  }}
                  className="bg-[#121622] border border-[#1e2536] hover:border-[#0088FE]/50 p-3.5 rounded-2xl flex items-center gap-3.5 shadow-md cursor-pointer transition-all group"
                >
                  <RadialGauge percentage={21} trend="+7%" color="#0088FE" size={88} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-[#0088FE] tracking-tight">
                        In Call
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-0.5">
                      <GitBranch className="w-3 h-3 text-slate-400" />
                      <span className="truncate">UCC_marketing</span>
                    </div>
                    <div className="text-lg font-mono font-black text-white mt-1">
                      115:37:15
                    </div>
                    <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-0.5">
                      <Clock className="w-3 h-3 text-slate-500" />
                      <span>Time Total ({metrics.biometricsCount} cases)</span>
                    </div>
                  </div>
                </div>

                {/* 3. Away / Paid Unsubmitted (Warm Amber #FFB020) */}
                <div
                  onClick={() => {
                    setStatusFilter('PAID_UNSUBMITTED');
                    setActiveTab('registry');
                  }}
                  className="bg-[#121622] border border-[#1e2536] hover:border-[#FFB020]/50 p-3.5 rounded-2xl flex items-center gap-3.5 shadow-md cursor-pointer transition-all group"
                >
                  <RadialGauge percentage={21} trend="+7%" color="#FFB020" size={88} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-[#FFB020] tracking-tight">
                        Away
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-0.5">
                      <GitBranch className="w-3 h-3 text-slate-400" />
                      <span className="truncate">UCC_production</span>
                    </div>
                    <div className="text-lg font-mono font-black text-white mt-1">
                      115:37:15
                    </div>
                    <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-0.5">
                      <Clock className="w-3 h-3 text-slate-500" />
                      <span>Time Total ({metrics.paidUnsubmittedCount} cases)</span>
                    </div>
                  </div>
                </div>

                {/* 4. Do Not Disturb / Ready for Collection (Coral #FF6B4A) */}
                <div
                  onClick={() => {
                    setStatusFilter('READY');
                    setActiveTab('registry');
                  }}
                  className="bg-[#121622] border border-[#1e2536] hover:border-[#FF6B4A]/50 p-3.5 rounded-2xl flex items-center gap-3.5 shadow-md cursor-pointer transition-all group"
                >
                  <RadialGauge percentage={21} trend="+7%" color="#FF6B4A" size={88} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-[#FF6B4A] tracking-tight">
                        Do Not Disturb
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-0.5">
                      <GitBranch className="w-3 h-3 text-slate-400" />
                      <span className="truncate">UCC_support</span>
                    </div>
                    <div className="text-lg font-mono font-black text-white mt-1">
                      115:37:15
                    </div>
                    <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-0.5">
                      <Clock className="w-3 h-3 text-slate-500" />
                      <span>Time Total ({metrics.readyCount} cases)</span>
                    </div>
                  </div>
                </div>

                {/* 5. Busy / Reverted Cases (Crimson Red #EF4444) */}
                <div
                  onClick={() => {
                    setStatusFilter('REVERTED');
                    setActiveTab('registry');
                  }}
                  className="bg-[#121622] border border-[#1e2536] hover:border-[#EF4444]/50 p-3.5 rounded-2xl flex items-center gap-3.5 shadow-md cursor-pointer transition-all group"
                >
                  <RadialGauge percentage={21} trend="+7%" color="#EF4444" size={88} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-[#EF4444] tracking-tight">
                        Busy
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-0.5">
                      <GitBranch className="w-3 h-3 text-slate-400" />
                      <span className="truncate">UCC_backoffice</span>
                    </div>
                    <div className="text-lg font-mono font-black text-white mt-1">
                      115:37:15
                    </div>
                    <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-0.5">
                      <Clock className="w-3 h-3 text-slate-500" />
                      <span>Time Total ({metrics.revertedCount} cases)</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* RIGHT MAIN ANALYTICS: Top Row, Middle Row, Bottom Detail Table */}
              <div className="flex-1 space-y-4 min-w-0 w-full">
                {/* ROW 1: Reason Code Distribution + Average Agent Workload */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                  {/* Card 1: Reason Code Distribution */}
                  <div className="lg:col-span-6 bg-[#121622] border border-[#1e2536] rounded-2xl p-5 shadow-md space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-white tracking-tight">
                        Reason Code Distribution
                      </h3>
                    </div>

                    <div className="flex items-baseline gap-2">
                      <span className="text-xs text-slate-400 font-medium">Total:</span>
                      <span className="text-3xl font-black text-white font-mono tracking-tight">
                        230
                      </span>
                    </div>

                    {/* Segmented Horizontal Progress Bar */}
                    <div className="w-full h-3.5 rounded-full overflow-hidden flex bg-slate-800 shadow-inner">
                      <div
                        style={{ width: '20%' }}
                        className="bg-[#FF6B4A] hover:opacity-90 transition-all cursor-pointer"
                        title="Coffee / Syntax Validation (20%)"
                      />
                      <div
                        style={{ width: '15%' }}
                        className="bg-[#00D492] hover:opacity-90 transition-all cursor-pointer"
                        title="Lunch / NRC Verification (15%)"
                      />
                      <div
                        style={{ width: '15%' }}
                        className="bg-[#FFB020] hover:opacity-90 transition-all cursor-pointer"
                        title="Break / Fee Payment Hold (15%)"
                      />
                      <div
                        style={{ width: '20%' }}
                        className="bg-[#EF4444] hover:opacity-90 transition-all cursor-pointer"
                        title="Meeting / Minor Consent (20%)"
                      />
                      <div
                        style={{ width: '30%' }}
                        className="bg-[#0088FE] hover:opacity-90 transition-all cursor-pointer"
                        title="Administration / Photo Spec (30%)"
                      />
                    </div>

                    {/* Legend with percentages and labels */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-2 text-xs">
                      <div>
                        <div className="font-bold text-white font-mono text-sm">20%</div>
                        <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-0.5">
                          <span className="w-2 h-2 rounded-full bg-[#0088FE]" />
                          <span>Coffee</span>
                        </div>
                      </div>

                      <div>
                        <div className="font-bold text-white font-mono text-sm">15%</div>
                        <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-0.5">
                          <span className="w-2 h-2 rounded-full bg-[#00D492]" />
                          <span>Lunch</span>
                        </div>
                      </div>

                      <div>
                        <div className="font-bold text-white font-mono text-sm">15%</div>
                        <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-0.5">
                          <span className="w-2 h-2 rounded-full bg-[#FF6B4A]" />
                          <span>Break</span>
                        </div>
                      </div>

                      <div>
                        <div className="font-bold text-white font-mono text-sm">20%</div>
                        <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-0.5">
                          <span className="w-2 h-2 rounded-full bg-[#EF4444]" />
                          <span>Meeting</span>
                        </div>
                      </div>

                      <div>
                        <div className="font-bold text-white font-mono text-sm">30%</div>
                        <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-0.5">
                          <span className="w-2 h-2 rounded-full bg-[#FFB020]" />
                          <span>Administration</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Card 2: Average Agent Workload Area Chart */}
                  <div className="lg:col-span-6 bg-[#121622] border border-[#1e2536] rounded-2xl p-5 shadow-md space-y-2">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-white tracking-tight">
                        Average Agent Workload
                      </h3>
                      <span className="text-[11px] text-[#00c2ff] font-mono font-semibold">
                        Target: 55%
                      </span>
                    </div>

                    <div className="h-[150px] w-full pt-1">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart
                          data={agentWorkloadData}
                          margin={{ top: 10, right: 10, left: -25, bottom: 0 }}
                        >
                          <defs>
                            <linearGradient id="cyanWorkloadGrad" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#00c2ff" stopOpacity={0.35} />
                              <stop offset="95%" stopColor="#00c2ff" stopOpacity={0.0} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#1b2334" vertical={false} />
                          <XAxis
                            dataKey="day"
                            tick={{ fill: '#64748b', fontSize: 10 }}
                            axisLine={{ stroke: '#1b2334' }}
                            tickLine={false}
                          />
                          <YAxis
                            domain={[0, 100]}
                            ticks={[0, 40, 60, 80, 100]}
                            tick={{ fill: '#64748b', fontSize: 10 }}
                            axisLine={{ stroke: '#1b2334' }}
                            tickLine={false}
                            unit="%"
                          />
                          <Tooltip
                            content={({ active, payload, label }) => {
                              if (active && payload && payload.length) {
                                return (
                                  <div className="bg-[#0b0e14] border border-[#1e2536] text-white p-2.5 rounded-lg shadow-xl text-xs space-y-1">
                                    <div className="font-bold text-slate-300">{label}</div>
                                    <div className="flex items-center justify-between gap-3">
                                      <span className="text-[#00c2ff]">Workload:</span>
                                      <span className="font-mono font-bold">
                                        {payload[1]?.value || payload[0]?.value}%
                                      </span>
                                    </div>
                                    <div className="flex items-center justify-between gap-3 text-amber-400">
                                      <span>Benchmark SLA:</span>
                                      <span className="font-mono">55%</span>
                                    </div>
                                  </div>
                                );
                              }
                              return null;
                            }}
                          />
                          {/* Dashed Gold Benchmark Line */}
                          <Line
                            type="monotone"
                            dataKey="target"
                            stroke="#FFB020"
                            strokeDasharray="4 4"
                            strokeWidth={1.5}
                            dot={false}
                          />
                          {/* Glowing Cyan Workload Line */}
                          <Area
                            type="monotone"
                            dataKey="workload"
                            stroke="#00c2ff"
                            strokeWidth={3}
                            fillOpacity={1}
                            fill="url(#cyanWorkloadGrad)"
                            dot={{ r: 3, fill: '#00c2ff', stroke: '#0b0e14', strokeWidth: 1.5 }}
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>

                {/* ROW 2: Status Time in hours Grouped Bar Chart */}
                <div className="bg-[#121622] border border-[#1e2536] rounded-2xl p-5 shadow-md space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-bold text-white tracking-tight">
                        Status Time in hours
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Daily operational hours logged across workflow queues
                      </p>
                    </div>
                  </div>

                  <div className="h-[210px] w-full pt-1">
                    <ResponsiveContainer width="100%" height="100%">
                      <RechartsBarChart
                        data={statusTimeBarData}
                        margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="#1b2334" vertical={false} />
                        <XAxis
                          dataKey="day"
                          tick={{ fill: '#64748b', fontSize: 11 }}
                          axisLine={{ stroke: '#1b2334' }}
                          tickLine={false}
                        />
                        <YAxis
                          domain={[0, 50]}
                          ticks={[0, 12, 24, 36, 48, 50]}
                          tick={{ fill: '#64748b', fontSize: 11 }}
                          axisLine={{ stroke: '#1b2334' }}
                          tickLine={false}
                          unit="h"
                        />
                        <Tooltip
                          content={({ active, payload, label }) => {
                            if (active && payload && payload.length) {
                              return (
                                <div className="bg-[#0b0e14] border border-[#1e2536] text-white p-3 rounded-xl shadow-2xl text-xs space-y-1.5 min-w-[180px]">
                                  <div className="font-bold border-b border-[#1e2536] pb-1 text-slate-200">
                                    {label}
                                  </div>
                                  {payload.map((p: any) => (
                                    <div
                                      key={p.name}
                                      className="flex items-center justify-between gap-3"
                                    >
                                      <div className="flex items-center gap-1.5">
                                        <span
                                          className="w-2 h-2 rounded-full"
                                          style={{ backgroundColor: p.color }}
                                        />
                                        <span className="text-slate-300 capitalize">{p.name}:</span>
                                      </div>
                                      <span className="font-mono font-bold text-white">
                                        {p.value} hrs
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              );
                            }
                            return null;
                          }}
                        />
                        <Bar
                          dataKey="available"
                          name="Available"
                          fill="#00D492"
                          radius={[3, 3, 0, 0]}
                        />
                        <Bar dataKey="inCall" name="In Call" fill="#0088FE" radius={[3, 3, 0, 0]} />
                        <Bar dataKey="away" name="Away" fill="#FFB020" radius={[3, 3, 0, 0]} />
                        <Bar
                          dataKey="dnd"
                          name="Do Not Disturb"
                          fill="#FF6B4A"
                          radius={[3, 3, 0, 0]}
                        />
                        <Bar dataKey="busy" name="Busy" fill="#EF4444" radius={[3, 3, 0, 0]} />
                      </RechartsBarChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Horizontal Bar Legend matching Template */}
                  <div className="flex flex-wrap items-center justify-center gap-5 pt-2 text-xs">
                    <div className="flex items-center gap-1.5 text-slate-300">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#00D492]" />
                      <span>Available</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-slate-300">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#0088FE]" />
                      <span>In Call</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-slate-300">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#FFB020]" />
                      <span>Away</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-slate-300">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#FF6B4A]" />
                      <span>Do Not Disturb</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-slate-300">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#EF4444]" />
                      <span>Busy</span>
                    </div>
                  </div>
                </div>

                {/* ROW 3: Status Detail Interactive Table matching BI Template */}
                <div className="bg-[#121622] border border-[#1e2536] rounded-2xl p-5 shadow-md space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <h3 className="text-sm font-bold text-white tracking-tight">Status Detail</h3>

                    {/* Dropdown Filter matching [All v] button in image */}
                    <div className="flex items-center gap-2 text-xs">
                      <select
                        value={detailTableFilter}
                        onChange={(e) => setDetailTableFilter(e.target.value)}
                        className="bg-[#0b0e14] border border-[#1e2536] text-white text-xs font-semibold rounded-lg py-1 px-3 focus:outline-hidden focus:border-[#0062ff] cursor-pointer"
                      >
                        <option value="All">All</option>
                        <option value="Available">Available Only</option>
                        <option value="In Call">In Call Only</option>
                        <option value="Away">Away Only</option>
                        <option value="Busy">Busy Only</option>
                      </select>
                    </div>
                  </div>

                  {/* Dark Data Matrix Table */}
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-[#1e2536] text-slate-400 font-semibold">
                          <th className="py-2.5 px-3 w-8"></th>
                          <th className="py-2.5 px-3">Status</th>
                          <th className="py-2.5 px-3 text-[#00D492]">Available</th>
                          <th className="py-2.5 px-3 text-[#0088FE]">In Call</th>
                          <th className="py-2.5 px-3 text-[#FFB020]">Away</th>
                          <th className="py-2.5 px-3 text-[#FF6B4A]">Do Not Disturb</th>
                          <th className="py-2.5 px-3 text-[#EF4444]">Busy</th>
                          <th className="py-2.5 px-3 text-slate-300">Reason Code</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#1b2334] font-mono text-[11px]">
                        {statusDetailRows.map((row) => {
                          const isExpanded = !!expandedRows[row.key];
                          return (
                            <React.Fragment key={row.key}>
                              <tr
                                onClick={() => toggleRow(row.key)}
                                className="hover:bg-[#181e2e] transition-colors cursor-pointer group"
                              >
                                <td className="py-2.5 px-3 text-slate-400">
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      toggleRow(row.key);
                                    }}
                                    className="w-5 h-5 rounded flex items-center justify-center bg-[#1b2334] hover:bg-[#232d42] text-slate-300"
                                  >
                                    {isExpanded ? (
                                      <Minus className="w-3 h-3" />
                                    ) : (
                                      <Plus className="w-3 h-3" />
                                    )}
                                  </button>
                                </td>
                                <td className="py-2.5 px-3 font-sans font-medium text-slate-200">
                                  <div>{row.name}</div>
                                  <div className="text-[10px] text-slate-500 font-mono">
                                    {row.stationLabel}
                                  </div>
                                </td>
                                <td className="py-2.5 px-3">
                                  <span className="text-[#00D492] font-semibold mr-2">
                                    {row.available.time}
                                  </span>
                                  <span className="text-slate-400">{row.available.pct}%</span>
                                </td>
                                <td className="py-2.5 px-3">
                                  <span className="text-[#0088FE] font-semibold mr-2">
                                    {row.inCall.time}
                                  </span>
                                  <span className="text-slate-400">{row.inCall.pct}%</span>
                                </td>
                                <td className="py-2.5 px-3">
                                  <span className="text-[#FFB020] font-semibold mr-2">
                                    {row.away.time}
                                  </span>
                                  <span className="text-slate-400">{row.away.pct}%</span>
                                </td>
                                <td className="py-2.5 px-3">
                                  <span className="text-[#FF6B4A] font-semibold mr-2">
                                    {row.dnd.time}
                                  </span>
                                  <span className="text-slate-400">{row.dnd.pct}%</span>
                                </td>
                                <td className="py-2.5 px-3">
                                  <span className="text-[#EF4444] font-semibold mr-2">
                                    {row.busy.time}
                                  </span>
                                  <span className="text-slate-400">{row.busy.pct}%</span>
                                </td>
                                <td className="py-2.5 px-3">
                                  <span className="text-slate-300 font-semibold mr-2">
                                    {row.reasonCode.time}
                                  </span>
                                  <span className="text-slate-400">{row.reasonCode.pct}%</span>
                                </td>
                              </tr>

                              {/* Expanded Drawer showing real dossiers for this department/station */}
                              {isExpanded && (
                                <tr className="bg-[#0b0e14]">
                                  <td colSpan={8} className="p-3 pl-11">
                                    <div className="bg-[#121622] border border-[#1e2536] rounded-xl p-3.5 space-y-2.5">
                                      <div className="flex items-center justify-between text-xs">
                                        <span className="font-sans font-bold text-slate-200 flex items-center gap-2">
                                          <Activity className="w-3.5 h-3.5 text-[#00c2ff]" />
                                          Active Dossiers in queue for {row.name} (
                                          {row.cases.length} assigned)
                                        </span>
                                        <button
                                          onClick={() => {
                                            setActiveTab('registry');
                                          }}
                                          className="text-[11px] text-[#0062ff] hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                                        >
                                          <span>Open all in Case Registry</span>
                                          <ArrowRight className="w-3 h-3" />
                                        </button>
                                      </div>

                                      {row.cases.length === 0 ? (
                                        <div className="text-slate-500 text-xs py-2">
                                          No active bottlenecks currently stalled in this unit.
                                        </div>
                                      ) : (
                                        <div className="space-y-1.5">
                                          {row.cases.slice(0, 3).map((app) => (
                                            <div
                                              key={app.id}
                                              onClick={() => setSelectedCaseForModal(app)}
                                              className="flex items-center justify-between p-2 rounded-lg bg-[#0b0e14] hover:bg-[#1a2133] transition-colors cursor-pointer border border-[#1e2536]/80 text-xs font-sans"
                                            >
                                              <div className="flex items-center gap-2">
                                                <span className="font-bold text-white">
                                                  {app.fullName}
                                                </span>
                                                <span className="text-slate-400 font-mono text-[11px]">
                                                  {app.trackingNumber}
                                                </span>
                                                <span
                                                  className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                                                    app.status === 'Reverted'
                                                      ? 'bg-red-500/20 text-red-300'
                                                      : app.status === 'Paid - Unsubmitted'
                                                      ? 'bg-amber-500/20 text-amber-300'
                                                      : 'bg-emerald-500/20 text-emerald-300'
                                                  }`}
                                                >
                                                  {app.status}
                                                </span>
                                              </div>
                                              <div className="flex items-center gap-2">
                                                <span className="text-slate-400 text-[11px]">
                                                  {app.daysInStatus}d in queue
                                                </span>
                                                <button
                                                  onClick={(e) => {
                                                    e.stopPropagation();
                                                    setSelectedCaseForModal(app);
                                                  }}
                                                  className="px-2 py-0.5 rounded text-[11px] font-semibold bg-[#0062ff] hover:bg-[#0052d9] text-white cursor-pointer"
                                                >
                                                  Triage Case
                                                </button>
                                              </div>
                                            </div>
                                          ))}
                                        </div>
                                      )}
                                    </div>
                                  </td>
                                </tr>
                              )}
                            </React.Fragment>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            {/* Smart Service Pillars Showcase */}
            <div className="mt-6 pt-4 border-t border-[#1e2536]">
              <PillarsModule
                applications={applications}
                onOpenAssistant={onOpenAssistant || (() => {})}
                onSelectApplication={onSelectApplication}
                onAddNotification={onAddNotification}
                onUpdateStatus={onUpdateStatus}
                isOfficerRole={true}
              />
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW 2: DEDICATED ACTION QUEUE TAB */}
        {/* ============================================================ */}
        {activeTab === 'action-queue' && (
          <div className="bg-[#121622] border border-[#1e2536] rounded-2xl p-4 shadow-xl">
            <ActionQueueTab
              applications={applications}
              onOpenTriageModal={(app) => setSelectedCaseForModal(app)}
              onUpdateStatus={onUpdateStatus}
              onAddNotification={onAddNotification}
              onSelectApplication={onSelectApplication}
            />
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW 3: DEDICATED SMART SERVICE PILLARS TAB */}
        {/* ============================================================ */}
        {activeTab === 'pillars' && (
          <div className="bg-[#121622] border border-[#1e2536] rounded-2xl p-4 shadow-xl">
            <PillarsModule
              applications={applications}
              onOpenAssistant={onOpenAssistant || (() => {})}
              onSelectApplication={onSelectApplication}
              onAddNotification={onAddNotification}
              onUpdateStatus={onUpdateStatus}
              isOfficerRole={true}
            />
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW 4: APPLICATION REGISTRY TAB */}
        {/* ============================================================ */}
        {activeTab === 'registry' && (
          <div className="space-y-4">
            {/* Filter Bar */}
            <div className="bg-[#121622] border border-[#1e2536] rounded-xl p-4 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
              <span className="text-slate-400 font-semibold">Filter Status:</span>
              <div className="flex flex-wrap items-center gap-1.5">
                {[
                  { id: 'ALL', label: 'All Cases' },
                  { id: 'REVERTED', label: 'Reverted' },
                  { id: 'PAID_UNSUBMITTED', label: 'Paid Unsubmitted' },
                  { id: 'REVIEW', label: 'Under Review' },
                  { id: 'BIOMETRICS', label: 'Biometrics' },
                  { id: 'READY', label: 'Ready' },
                ].map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setStatusFilter(f.id)}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer ${
                      statusFilter === f.id
                        ? 'bg-[#0062ff] text-white shadow-xs'
                        : 'bg-[#0b0e14] text-slate-300 hover:text-white border border-[#1e2536]'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Registry Dark Table */}
            <div className="bg-[#121622] border border-[#1e2536] rounded-2xl shadow-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-[#1e2536] bg-[#0b0e14] text-slate-400 font-semibold">
                      <th className="py-3 px-4">Tracking Number &amp; Applicant</th>
                      <th className="py-3 px-4">NRC &amp; Type</th>
                      <th className="py-3 px-4">Current Status</th>
                      <th className="py-3 px-4">Contact Integrity</th>
                      <th className="py-3 px-4">Days in Stage</th>
                      <th className="py-3 px-4">Office</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1e2536] text-slate-300">
                    {filteredApplications.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-8 text-center text-slate-500 text-xs">
                          No applications found matching your criteria.
                        </td>
                      </tr>
                    ) : (
                      filteredApplications.map((app) => {
                        const phoneValid = validatePhoneNumber(
                          app.contact.phone,
                          app.contact.phoneCountryCode
                        ).isValid;
                        const emailValid = validateEmail(app.contact.email).isValid;
                        const contactOk = phoneValid && emailValid;

                        return (
                          <tr
                            key={app.id}
                            className="hover:bg-[#181e2e] transition-colors cursor-pointer"
                            onClick={() => setSelectedCaseForModal(app)}
                          >
                            <td className="py-3 px-4">
                              <div className="font-semibold text-white flex items-center gap-1.5">
                                <span>{app.fullName}</span>
                                {app.isUrgent && (
                                  <span className="text-[9px] bg-[#FFB020] text-slate-950 font-bold px-1 rounded">
                                    EXPRESS
                                  </span>
                                )}
                              </div>
                              <div className="font-mono text-[11px] text-slate-400">
                                {app.trackingNumber}
                              </div>
                            </td>

                            <td className="py-3 px-4">
                              <div className="font-mono text-slate-200">{app.nrcNumber}</div>
                              <div className="text-[11px] text-slate-400">{app.passportType}</div>
                            </td>

                            <td className="py-3 px-4">
                              <span
                                className={`inline-block px-2 py-0.5 rounded text-[11px] font-semibold ${
                                  app.status === 'Reverted'
                                    ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                                    : app.status === 'Paid - Unsubmitted'
                                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                    : app.status === 'Ready for Collection'
                                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                    : app.status === 'Biometrics Scheduled'
                                    ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                                    : 'bg-slate-700/40 text-slate-200'
                                }`}
                              >
                                {app.status}
                              </span>
                              {app.reversionReason && (
                                <div className="text-[10px] text-red-400 line-clamp-1 mt-0.5 max-w-xs">
                                  {app.reversionReason}
                                </div>
                              )}
                            </td>

                            <td className="py-3 px-4">
                              {contactOk ? (
                                <span className="text-[#00D492] font-semibold flex items-center gap-1 text-[11px]">
                                  <CheckCircle2 className="w-3.5 h-3.5 text-[#00D492]" />
                                  Verified E.164
                                </span>
                              ) : (
                                <span className="text-[#FFB020] font-semibold flex items-center gap-1 text-[11px]">
                                  <AlertCircle className="w-3.5 h-3.5 text-[#FFB020]" />
                                  Flagged
                                </span>
                              )}
                              <div className="text-[11px] text-slate-400 font-mono">
                                {app.contact.phone}
                              </div>
                            </td>

                            <td className="py-3 px-4">
                              <span
                                className={`font-semibold ${
                                  app.daysInStatus > 7 ? 'text-red-400' : 'text-slate-300'
                                }`}
                              >
                                {app.daysInStatus} days
                              </span>
                              {app.daysInStatus > 7 && (
                                <span className="block text-[10px] text-red-400">SLA Exceeded</span>
                              )}
                            </td>

                            <td className="py-3 px-4 text-slate-300">
                              {app.collectionOffice.replace('Passport Office', 'P.O.')}
                            </td>

                            <td
                              className="py-3 px-4 text-right space-x-1"
                              onClick={(e) => e.stopPropagation()}
                            >
                              <button
                                onClick={() => setSelectedCaseForModal(app)}
                                className="px-2.5 py-1 text-[11px] font-semibold bg-[#0062ff] text-white rounded-lg hover:bg-[#0052d9] transition-colors cursor-pointer"
                              >
                                Triage
                              </button>
                              <button
                                onClick={() => {
                                  onSelectApplication(app);
                                }}
                                className="px-2 py-1 text-[11px] font-semibold bg-[#1e2536] text-slate-200 rounded-lg hover:bg-[#283248] transition-colors cursor-pointer"
                                title="Open in Citizen Portal View"
                              >
                                Citizen View
                              </button>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* VIEW 5: PILOT EVALUATION TAB */}
        {/* ============================================================ */}
        {activeTab === 'evaluation' && (
          <div className="bg-[#121622] border border-[#1e2536] rounded-2xl p-4 shadow-xl">
            <PilotEvaluationReport />
          </div>
        )}
      </div>

      {/* Case Triage Modal */}
      {selectedCaseForModal && (
        <CaseTriageModal
          application={selectedCaseForModal}
          onClose={() => setSelectedCaseForModal(null)}
          onUpdateStatus={(id, newStatus, notes) => {
            onUpdateStatus(id, newStatus, notes);
            setSelectedCaseForModal(null);
          }}
          onAddNotification={onAddNotification}
        />
      )}

      {/* Operational Intelligence Executive Report Modal */}
      {isExecutiveReportOpen && (
        <ExecutiveReportModal
          applications={applications}
          onClose={() => setIsExecutiveReportOpen(false)}
        />
      )}
    </div>
  );
};
