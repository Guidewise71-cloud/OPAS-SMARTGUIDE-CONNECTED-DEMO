import React, { useState } from 'react';
import {
  Shield,
  Sparkles,
  Search,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Phone,
  Mail,
  Camera,
  CreditCard,
  FileText,
  MapPin,
  Lock,
  ChevronRight,
  UserCheck,
  Zap,
  HelpCircle,
  X,
  Menu,
  BookOpen,
  Scale,
  Compass,
  QrCode,
  ShieldCheck,
  Smartphone,
  Eye,
  Check,
  CheckCheck,
  MessageSquare,
} from 'lucide-react';
import { PassportApplication } from '../../types/passport';
import { useChat } from '../../context/ChatContext';

interface WelcomePageProps {
  onOpenLogin: () => void;
  onOpenSignUp: () => void;
  applications: PassportApplication[];
  onSelectApplication: (app: PassportApplication) => void;
}

export const WelcomePage: React.FC<WelcomePageProps> = ({
  onOpenLogin,
  onOpenSignUp,
  applications,
  onSelectApplication,
}) => {
  const [showNoticeBanner, setShowNoticeBanner] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTopicAnswer, setSelectedTopicAnswer] = useState<{
    title: string;
    description: string;
    bullets: string[];
    actionLabel: string;
    actionQuery: string;
  } | null>(null);
  const [trackModalOpen, setTrackModalOpen] = useState(false);
  const [trackingInput, setTrackingInput] = useState('');
  const [trackResult, setTrackResult] = useState<PassportApplication | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const { populateQuery, setIsAssistantOpen } = useChat();

  // Handle quick prompt clicks from the right sidebar
  const handleSidebarPromptClick = (topicKey: string) => {
    switch (topicKey) {
      case 'questions':
        setSelectedTopicAnswer({
          title: 'Ask Anything About Your Passport',
          description:
            'Our 24/7 AI Guidance Assistant is grounded in official Ministry of Home Affairs rules to answer questions regarding passport booklets, photo standards, fee payments, and counter collections.',
          bullets: [
            'Which passport type: 32-Page (ZMW 500) vs 48-Page (ZMW 1,000)',
            'Photo specifications: plain light-grey or off-white background, neutral expression',
            'First-time adult applicants: Green NRC, certified birth certificate, guarantor',
            'Replacement of lost passport: Police Report and Statutory Declaration sworn before Commissioner for Oaths',
          ],
          actionLabel: 'Chat with AI Assistant',
          actionQuery: 'What are the main requirements and fees for a Zambian passport application?',
        });
        break;
      case 'requirements':
        setSelectedTopicAnswer({
          title: 'Official Document Checklist & Requirements',
          description:
            'Ensure all mandatory civil documents are certified and legible to avoid unnecessary application reversions.',
          bullets: [
            'Green National Registration Card (NRC) original and certified copy',
            'Official Birth Certificate certified by the Registrar General',
            'Completed Guarantor Form stamped by an authorized professional (e.g. Magistrate, Lawyer, Clergy, Senior Civil Servant)',
            'Two (2) recent compliant passport photographs (45mm x 35mm)',
            'Proof of OPAS fee payment receipt from Government Payment Gateway (GPG)',
          ],
          actionLabel: 'Ask AI for Document Help',
          actionQuery: 'What is the full document checklist for adult and minor passport applicants in Zambia?',
        });
        break;
      case 'simplify':
        setSelectedTopicAnswer({
          title: '6-Stage OPAS Passport Lifecycle',
          description:
            'The entire passport application process has been simplified into 6 transparent milestones:',
          bullets: [
            '1. Online Intake & Green NRC Format Validation',
            '2. Statutory Fee Payment via Government Payment Gateway (GPG)',
            '3. Officer Vetting & AI Optical Document Pre-Flight Checks',
            '4. Biometrics Capture Appointment at Regional Passport Office',
            '5. Central Booklet Personalization & ICAO Chip Encoding',
            '6. Ready for Collection at your designated Passport Office counter',
          ],
          actionLabel: 'Explore Step-by-Step Guide',
          actionQuery: 'Can you explain the 6 stages of the OPAS passport application process?',
        });
        break;
      case 'photos':
        setSelectedTopicAnswer({
          title: 'Passport Photo Standards & Glare Prevention',
          description:
            '38% of preventable application delays are caused by non-compliant photos. Follow these strict ICAO rules:',
          bullets: [
            'Dimensions: Exactly 45mm height x 35mm width (or standard 2x2 inches)',
            'Background: Plain off-white or light grey without patterns, textures, or shadows',
            'Pose & Expression: Direct frontal eye contact, neutral facial expression, mouth closed',
            'Spectacles: Remove eyeglasses to prevent flash glare or frame shadow over eyes',
            'Headwear: Only religious or medical coverings permitted, full face contour must remain visible',
          ],
          actionLabel: 'Validate My Photo with AI',
          actionQuery: 'What are the exact specifications for passport photos to ensure they pass vetting?',
        });
        break;
      case 'reversion':
        setSelectedTopicAnswer({
          title: 'Reverted Application Remedy (Zero Repayment Fee)',
          description:
            'If an inspecting officer flags a document discrepancy, your application is reverted for correction. You NEVER need to pay the application fee again!',
          bullets: [
            'Log into your OPAS Citizen Portal to review the officer\'s specific note',
            'Upload the replacement document directly in the Reversion Resolution Center',
            'Our AI pre-flight inspector verifies optical compliance in real time',
            'Once uploaded, your dossier immediately resumes processing without losing your queue priority',
          ],
          actionLabel: 'Get Reversion Guidance',
          actionQuery: 'How do I resolve a reverted passport application without paying another fee?',
        });
        break;
      case 'comparison':
        setSelectedTopicAnswer({
          title: '32-Page Ordinary vs 48-Page Frequent Traveler',
          description:
            'Select the booklet capacity tailored to your anticipated travel frequency over the 10-year validity period:',
          bullets: [
            '32-Page Ordinary Passport: ZMW 500 statutory fee. Ideal for occasional holiday, family, and tourist travel.',
            '48-Page Frequent Traveler: ZMW 1,000 statutory fee. Recommended for frequent cross-border traders, business executives, and regional travelers.',
            'Express Service: +ZMW 500 fast-track surcharge (3-5 working days upon biometric verification).',
          ],
          actionLabel: 'Compare Passport Types',
          actionQuery: 'Should I choose a 32-page or 48-page passport? Compare fees and validity.',
        });
        break;
      default:
        break;
    }
  };

  const handleLaunchAssistantWithQuery = (query: string) => {
    setSelectedTopicAnswer(null);
    setIsAssistantOpen(true);
    populateQuery(query, true);
  };

  // Quick Tracking Lookup Handler
  const handleTrackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = trackingInput.trim().toLowerCase();
    const match = applications.find(
      (a) =>
        a.trackingNumber.toLowerCase() === clean ||
        a.nrcNumber.toLowerCase() === clean ||
        a.contact.phone.replace(/[\s\-\+]/g, '').includes(clean)
    );
    if (match) {
      setTrackResult(match);
    } else {
      setTrackResult(null);
      alert('No application found matching this reference. Try demo reference ZAM-OPAS-2026-1592 or NRC 294812/11/1.');
    }
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 font-sans flex flex-col selection:bg-emerald-600 selection:text-white">
      {/* ============================================================ */}
      {/* 1. TOP NOTICE / ANNOUNCEMENT BANNER (Replicating Screenshot Yellow Bar) */}
      {/* ============================================================ */}
      {showNoticeBanner && (
        <div className="bg-[#fbbf24] text-slate-950 px-4 py-2 text-xs sm:text-sm font-semibold flex items-center justify-between border-b border-amber-400/80 shadow-xs">
          <div className="max-w-7xl mx-auto w-full flex items-center justify-between">
            <div className="flex items-center gap-2.5 mx-auto sm:mx-0">
              <span className="bg-slate-950 text-white text-[11px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider font-mono shadow-xs">
                NEW
              </span>
              <span>
                Announcing the Enhanced OPAS Portal: 24/7 AI Guidance Assistant, Real-Time Contact Normalization &amp; Status Surveillance
              </span>
            </div>
            <button
              onClick={() => setShowNoticeBanner(false)}
              className="text-slate-900 hover:text-slate-700 p-1 cursor-pointer font-bold text-base leading-none hidden sm:block"
              title="Dismiss announcement"
              aria-label="Dismiss announcement"
            >
              &times;
            </button>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* 2. SLEEK DARK NAVIGATION BAR (Replicating Dark Navbar in Screenshot) */}
      {/* ============================================================ */}
      <header className="bg-[#0b1320] text-white border-b border-slate-800 sticky top-0 z-40 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          {/* Left: Brand Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-700 border border-emerald-500/40 flex items-center justify-center text-white shadow-xs shrink-0">
              <Shield className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div className="leading-tight">
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-base tracking-tight text-white">MoHAIS OPAS</span>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold px-1.5 py-0.2 rounded font-mono">
                  ZAMBIA
                </span>
              </div>
              <span className="text-[10px] text-slate-400 block font-medium">Passport Application System</span>
            </div>

            {/* Mobile Menu Toggle Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden ml-2 p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer"
              title="Toggle Menu"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>

          {/* Center Links (Desktop) */}
          <nav className="hidden lg:flex items-center gap-5 text-xs font-semibold text-slate-300">
            <a href="#services" className="hover:text-emerald-400 transition-colors">
              Passport Types
            </a>
            <a href="#requirements" className="hover:text-emerald-400 transition-colors">
              Requirements
            </a>
            <a href="#roadmap" className="hover:text-emerald-400 transition-colors">
              Application Guide
            </a>
            <button
              onClick={() => handleSidebarPromptClick('questions')}
              className="hover:text-emerald-400 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>AI Assistant</span>
            </button>
            <button
              onClick={() => setTrackModalOpen(true)}
              className="hover:text-emerald-400 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>Track Application</span>
            </button>
          </nav>

          {/* Search Box in Navbar (matching screenshot search pill) */}
          <div className="hidden md:flex items-center relative flex-1 max-w-xs">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && searchQuery.trim()) {
                  handleLaunchAssistantWithQuery(searchQuery);
                }
              }}
              placeholder="Search requirements, photo specs, fees..."
              className="w-full text-xs pl-8 pr-3 py-1.5 bg-[#182337] border border-slate-700/80 rounded-full text-slate-100 placeholder-slate-400 focus:outline-hidden focus:border-emerald-500 transition-all"
            />
          </div>

          {/* Right Controls: Fast-Track, Login, Sign Up Buttons (matching screenshot) */}
          <div className="flex items-center gap-2.5">
            <div className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-400/15 border border-amber-400/30 text-amber-300 text-xs font-bold">
              <Zap className="w-3.5 h-3.5 fill-amber-300" />
              <span>Express Fast-Track (3-5d)</span>
            </div>

            {/* Login Button (Triggers Login Mode) */}
            <button
              onClick={onOpenLogin}
              className="px-3.5 py-1.5 text-xs sm:text-sm font-bold text-slate-200 hover:text-white hover:bg-slate-800/80 rounded-lg transition-colors cursor-pointer"
              title="Sign in to your account"
            >
              Login
            </button>

            {/* Sign Up Button (Triggers Sign-up Mode) */}
            <button
              onClick={onOpenSignUp}
              className="px-4 py-2 text-xs sm:text-sm font-bold bg-[#2563eb] hover:bg-[#1d4ed8] text-white rounded-full shadow-md transition-all duration-150 hover:scale-105 cursor-pointer flex items-center gap-1.5"
              title="Create new citizen passport account"
            >
              <span>Sign Up</span>
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden px-4 py-3 bg-[#111c30] border-t border-slate-800 space-y-2 text-xs font-semibold">
            <a
              href="#services"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-1.5 text-slate-300 hover:text-emerald-400"
            >
              Passport Types (32 vs 48 Pages)
            </a>
            <a
              href="#requirements"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-1.5 text-slate-300 hover:text-emerald-400"
            >
              Document Checklist &amp; Requirements
            </a>
            <a
              href="#roadmap"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-1.5 text-slate-300 hover:text-emerald-400"
            >
              Application Guide &amp; Roadmap
            </a>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                setTrackModalOpen(true);
              }}
              className="block w-full text-left py-1.5 text-amber-300 hover:text-amber-200"
            >
              Track Application Status
            </button>
          </div>
        )}
      </header>

      {/* ============================================================ */}
      {/* 3. HERO & 2-COLUMN MAIN CONTENT (Replicating Screenshot Layout) */}
      {/* ============================================================ */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* ============================================================ */}
          {/* LEFT / CENTER COLUMN: HERO & SERVICE GUIDE (8 cols) */}
          {/* ============================================================ */}
          <div className="lg:col-span-8 space-y-8">
            {/* Top Heading Block (Matching Screenshot Headline Typography) */}
            <div className="space-y-3">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold uppercase tracking-wider">
                <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
                <span>Republic of Zambia &bull; Ministry of Home Affairs</span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight leading-tight">
                Welcome to Zambia Passport Application System (OPAS)
              </h1>

              <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-2xl">
                Apply for a new ordinary or frequent traveler passport, verify your Green NRC &amp; contact details in real-time, resolve reverted applications with zero repayment fees, and receive 24/7 AI-assisted guidance.
              </p>

              {/* Action Buttons: Sign Up & Login triggers */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={onOpenSignUp}
                  className="px-6 py-3 rounded-full text-sm font-bold bg-emerald-800 hover:bg-emerald-900 text-white shadow-lg shadow-emerald-900/20 transition-all hover:scale-105 cursor-pointer flex items-center gap-2"
                >
                  <span>Apply for Passport (Sign Up)</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={onOpenLogin}
                  className="px-5 py-3 rounded-full text-sm font-bold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 shadow-xs transition-colors cursor-pointer"
                >
                  Sign In to Existing Case (Login)
                </button>
                <button
                  onClick={() => setTrackModalOpen(true)}
                  className="px-4 py-3 rounded-full text-sm font-semibold text-emerald-800 hover:bg-emerald-50 transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Clock className="w-4 h-4 text-emerald-700" />
                  <span>Track Status</span>
                </button>
              </div>
            </div>

            {/* Featured Visual Card (Replicating "Frontend Technologies" Hero Visual in Screenshot) */}
            <div className="bg-[#0b1320] border-2 border-slate-800 rounded-3xl p-6 sm:p-8 text-white shadow-2xl relative overflow-hidden">
              {/* Background Ambient Glows */}
              <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute bottom-0 left-0 w-80 h-80 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

              <div className="relative z-10 space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-700 flex items-center justify-center text-white font-black text-xs">
                      ZM
                    </div>
                    <div>
                      <span className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-widest block">
                        Official e-Passport Standards
                      </span>
                      <h3 className="text-base font-bold text-white">
                        Republic of Zambia Digital Travel Document
                      </h3>
                    </div>
                  </div>
                  <span className="text-xs font-mono text-slate-400 bg-slate-900 px-2.5 py-1 rounded-md border border-slate-800">
                    ICAO Doc 9303 Compliant
                  </span>
                </div>

                {/* Passport Visual & Technology Pillars */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-center">
                  {/* Passport Visual Booklets Mockup */}
                  <div className="bg-[#121c2e] border border-slate-700/80 rounded-2xl p-5 flex flex-col justify-between space-y-4 shadow-inner">
                    <div className="flex items-center justify-between">
                      <div className="w-8 h-8 rounded-full bg-emerald-900 border border-emerald-600/60 flex items-center justify-center text-emerald-300 font-bold text-xs">
                        ZM
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 block font-mono">Validity</span>
                        <span className="text-xs font-bold text-emerald-400">10 Years (Adult)</span>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                        Biometric e-Passport
                      </div>
                      <div className="text-lg font-black text-white">
                        Zambian Citizen Passport
                      </div>
                      <p className="text-xs text-slate-300">
                        Embedded RFID chip holding cryptographic facial biometric &amp; demographic verification.
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-[11px]">
                      <span className="text-slate-400">Ordinary: <strong className="text-white">ZMW 500</strong></span>
                      <span className="text-slate-400">Frequent: <strong className="text-white">ZMW 1,000</strong></span>
                    </div>
                  </div>

                  {/* 4 Feature Badges (Mirroring tech badges in screenshot) */}
                  <div className="space-y-3">
                    <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/70 flex items-start gap-3">
                      <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400 shrink-0">
                        <Sparkles className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">24/7 Virtual Guidance Assistant</div>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Instant answers on ICAO photo specs, fee structures, and application checklists.
                        </p>
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/70 flex items-start gap-3">
                      <div className="p-2 rounded-lg bg-blue-500/20 text-blue-400 shrink-0">
                        <CheckCheck className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">Real-Time Contact Normalization</div>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Auto-converts Zambian mobile numbers to E.164 and prevents delivery failure typos.
                        </p>
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/70 flex items-start gap-3">
                      <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400 shrink-0">
                        <Clock className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">Zero Repayment on Reverted Cases</div>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Correct flagged photos or guarantor items directly without paying new application fees.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-2 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400 border-t border-slate-800">
                  <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Government Payment Gateway (GPG) Connected</span>
                  </span>
                  <span>Passport Office, Makishi Road, Lusaka</span>
                </div>
              </div>
            </div>

            {/* Passport Booklet Selection & Fee Structure (Services Section) */}
            <div id="services" className="space-y-4">
              <div>
                <h3 className="text-xl font-bold text-slate-900 tracking-tight">
                  Available Passport Categories &amp; Statutory Fees
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Select the booklet capacity tailored to your anticipated travel frequency over the 10-year validity period.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {/* 32-Page Ordinary */}
                <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col justify-between hover:border-emerald-500 transition-all">
                  <div>
                    <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded uppercase">
                      Standard Issue
                    </span>
                    <h4 className="text-base font-bold text-slate-900 mt-2">32-Page Ordinary</h4>
                    <div className="text-2xl font-black text-emerald-800 font-mono mt-1">ZMW 500</div>
                    <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                      For standard tourism, educational visits, and personal international travel.
                    </p>
                    <ul className="text-[11px] text-slate-600 space-y-1 mt-3">
                      <li className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-600" /> 14-21 working days turnaround
                      </li>
                      <li className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-600" /> 10-year validity (Adults)
                      </li>
                    </ul>
                  </div>
                  <button
                    onClick={onOpenSignUp}
                    className="w-full mt-5 py-2 text-xs font-bold bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl shadow-xs transition-colors cursor-pointer"
                  >
                    Apply for 32-Page
                  </button>
                </div>

                {/* 48-Page Frequent Traveler */}
                <div className="bg-white border-2 border-emerald-600 rounded-2xl p-5 shadow-sm flex flex-col justify-between relative">
                  <span className="absolute -top-3 right-4 bg-emerald-600 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider shadow-xs">
                    Recommended
                  </span>
                  <div>
                    <span className="text-[10px] font-mono font-bold bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded uppercase">
                      Business &amp; Trade
                    </span>
                    <h4 className="text-base font-bold text-slate-900 mt-2">48-Page Frequent Traveler</h4>
                    <div className="text-2xl font-black text-emerald-800 font-mono mt-1">ZMW 1,000</div>
                    <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                      For corporate executives, cross-border traders, and regular international travelers.
                    </p>
                    <ul className="text-[11px] text-slate-600 space-y-1 mt-3">
                      <li className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-600" /> 48 heavy-duty visa pages
                      </li>
                      <li className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-600" /> Ideal for regional SADC/COMESA
                      </li>
                    </ul>
                  </div>
                  <button
                    onClick={onOpenSignUp}
                    className="w-full mt-5 py-2 text-xs font-bold bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl shadow-xs transition-colors cursor-pointer"
                  >
                    Apply for 48-Page
                  </button>
                </div>

                {/* Express Expedited Fast-Track */}
                <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col justify-between hover:border-amber-500 transition-all">
                  <div>
                    <span className="text-[10px] font-mono font-bold bg-amber-50 text-amber-800 px-2 py-0.5 rounded uppercase flex items-center gap-1 w-fit">
                      <Zap className="w-3 h-3 fill-amber-500" /> Fast-Track Surcharge
                    </span>
                    <h4 className="text-base font-bold text-slate-900 mt-2">Express Processing</h4>
                    <div className="text-2xl font-black text-amber-700 font-mono mt-1">+ZMW 500</div>
                    <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                      Priority queuing and accelerated central personalization for emergency travel.
                    </p>
                    <ul className="text-[11px] text-slate-600 space-y-1 mt-3">
                      <li className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-amber-600" /> 3-5 working days upon biometrics
                      </li>
                      <li className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-amber-600" /> Direct counter dispatch
                      </li>
                    </ul>
                  </div>
                  <button
                    onClick={onOpenSignUp}
                    className="w-full mt-5 py-2 text-xs font-bold bg-slate-900 hover:bg-slate-800 text-white rounded-xl shadow-xs transition-colors cursor-pointer"
                  >
                    Start Express Application
                  </button>
                </div>
              </div>
            </div>

            {/* 4-Step Interactive Roadmap (Matching Roadmap.sh concept in screenshot) */}
            <div id="roadmap" className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-5">
              <div>
                <h3 className="text-lg font-bold text-slate-900 tracking-tight">
                  Official 4-Step Citizen Application Roadmap
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Follow the official sequence to ensure your dossier is approved without delay.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                  <div className="w-7 h-7 rounded-full bg-emerald-800 text-white flex items-center justify-center font-bold text-xs">
                    1
                  </div>
                  <div className="font-bold text-slate-900 text-sm">Identity &amp; Green NRC</div>
                  <p className="text-[11px] text-slate-600 leading-snug">
                    Enter full legal names and Green NRC format (123456/78/1). Contact numbers auto-normalized.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                  <div className="w-7 h-7 rounded-full bg-emerald-800 text-white flex items-center justify-center font-bold text-xs">
                    2
                  </div>
                  <div className="font-bold text-slate-900 text-sm">GPG Fee Payment</div>
                  <p className="text-[11px] text-slate-600 leading-snug">
                    Complete statutory fees (ZMW 500 / 1,000) securely through the Government Payment Gateway.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                  <div className="w-7 h-7 rounded-full bg-emerald-800 text-white flex items-center justify-center font-bold text-xs">
                    3
                  </div>
                  <div className="font-bold text-slate-900 text-sm">AI Photo Pre-Check</div>
                  <p className="text-[11px] text-slate-600 leading-snug">
                    Instant optical inspection verifies ICAO 45x35mm size and plain background before submit.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                  <div className="w-7 h-7 rounded-full bg-emerald-800 text-white flex items-center justify-center font-bold text-xs">
                    4
                  </div>
                  <div className="font-bold text-slate-900 text-sm">Biometrics &amp; Pickup</div>
                  <p className="text-[11px] text-slate-600 leading-snug">
                    Schedule biometric capture appointment at regional center and collect personalized booklet.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* ============================================================ */}
          {/* RIGHT COLUMN: AI TUTOR SIDEBAR (Directly Replicating Screenshot AI Sidebar!) */}
          {/* ============================================================ */}
          <aside className="lg:col-span-4 space-y-4">
            {/* Sidebar Top Header matching screenshot */}
            <div className="flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider">
              <Sparkles className="w-4 h-4 text-emerald-700" />
              <span>AI Assistant</span>
            </div>

            {/* AI Assistant Greeting Card (Yellow/Amber Card like screenshot) */}
            <div className="bg-[#fffbeb] border-2 border-[#fef08a] rounded-2xl p-5 shadow-xs space-y-4">
              {/* Bot Avatar & Greeting */}
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-2xl bg-[#f59e0b] text-slate-950 flex items-center justify-center font-black text-lg shadow-sm shrink-0">
                  🤖
                </div>
                <div>
                  <h4 className="font-extrabold text-sm text-slate-900 leading-tight">
                    I&apos;m your AI assistant for this portal. Ask me anything! 👋
                  </h4>
                  <p className="text-[11px] text-slate-600 mt-1 leading-snug">
                    Grounded in official Ministry of Home Affairs passport regulations.
                  </p>
                </div>
              </div>

              {/* Stack of Prompt Option Cards (Mirroring screenshot cards) */}
              <div className="space-y-2">
                {/* 1. Ask Questions */}
                <button
                  onClick={() => handleSidebarPromptClick('questions')}
                  className="w-full p-3 rounded-xl bg-white hover:bg-slate-50 border border-amber-200/80 hover:border-amber-400 text-left transition-all shadow-2xs hover:shadow-xs cursor-pointer flex items-start gap-2.5 group"
                >
                  <div className="p-1 rounded-lg bg-amber-50 text-amber-700 group-hover:bg-amber-100 mt-0.5 shrink-0">
                    <MessageSquare className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900 group-hover:text-emerald-900">
                      Ask Questions
                    </div>
                    <div className="text-[11px] text-slate-500 leading-snug">
                      Ask about fees, requirements, or passport types
                    </div>
                  </div>
                </button>

                {/* 2. Explain Concepts / Requirements */}
                <button
                  onClick={() => handleSidebarPromptClick('requirements')}
                  className="w-full p-3 rounded-xl bg-white hover:bg-slate-50 border border-amber-200/80 hover:border-amber-400 text-left transition-all shadow-2xs hover:shadow-xs cursor-pointer flex items-start gap-2.5 group"
                >
                  <div className="p-1 rounded-lg bg-blue-50 text-blue-700 group-hover:bg-blue-100 mt-0.5 shrink-0">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900 group-hover:text-emerald-900">
                      Explain Requirements
                    </div>
                    <div className="text-[11px] text-slate-500 leading-snug">
                      Summarize checklist for adults, minors &amp; replacement
                    </div>
                  </div>
                </button>

                {/* 3. Simplify Process */}
                <button
                  onClick={() => handleSidebarPromptClick('simplify')}
                  className="w-full p-3 rounded-xl bg-white hover:bg-slate-50 border border-amber-200/80 hover:border-amber-400 text-left transition-all shadow-2xs hover:shadow-xs cursor-pointer flex items-start gap-2.5 group"
                >
                  <div className="p-1 rounded-lg bg-emerald-50 text-emerald-700 group-hover:bg-emerald-100 mt-0.5 shrink-0">
                    <Zap className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900 group-hover:text-emerald-900">
                      Simplify Process
                    </div>
                    <div className="text-[11px] text-slate-500 leading-snug">
                      Explain complex stages in simple, practical terms
                    </div>
                  </div>
                </button>

                {/* 4. Photo Standards */}
                <button
                  onClick={() => handleSidebarPromptClick('photos')}
                  className="w-full p-3 rounded-xl bg-white hover:bg-slate-50 border border-amber-200/80 hover:border-amber-400 text-left transition-all shadow-2xs hover:shadow-xs cursor-pointer flex items-start gap-2.5 group"
                >
                  <div className="p-1 rounded-lg bg-purple-50 text-purple-700 group-hover:bg-purple-100 mt-0.5 shrink-0">
                    <Camera className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900 group-hover:text-emerald-900">
                      Photo Standards
                    </div>
                    <div className="text-[11px] text-slate-500 leading-snug">
                      ICAO 45x35mm dimensions, background &amp; glare rules
                    </div>
                  </div>
                </button>

                {/* 5. Reversion Remedy */}
                <button
                  onClick={() => handleSidebarPromptClick('reversion')}
                  className="w-full p-3 rounded-xl bg-white hover:bg-slate-50 border border-amber-200/80 hover:border-amber-400 text-left transition-all shadow-2xs hover:shadow-xs cursor-pointer flex items-start gap-2.5 group"
                >
                  <div className="p-1 rounded-lg bg-red-50 text-red-700 group-hover:bg-red-100 mt-0.5 shrink-0">
                    <AlertTriangle className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900 group-hover:text-emerald-900">
                      Reversion Remedy
                    </div>
                    <div className="text-[11px] text-slate-500 leading-snug">
                      How to fix reverted dossiers with zero repayment fee
                    </div>
                  </div>
                </button>

                {/* 6. 32 vs 48 Pages Comparison */}
                <button
                  onClick={() => handleSidebarPromptClick('comparison')}
                  className="w-full p-3 rounded-xl bg-white hover:bg-slate-50 border border-amber-200/80 hover:border-amber-400 text-left transition-all shadow-2xs hover:shadow-xs cursor-pointer flex items-start gap-2.5 group"
                >
                  <div className="p-1 rounded-lg bg-indigo-50 text-indigo-700 group-hover:bg-indigo-100 mt-0.5 shrink-0">
                    <Scale className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900 group-hover:text-emerald-900">
                      32 vs 48 Pages
                    </div>
                    <div className="text-[11px] text-slate-500 leading-snug">
                      Understand trade-offs and fee structures
                    </div>
                  </div>
                </button>
              </div>

              {/* Bottom Quick Callout */}
              <div className="pt-3 border-t border-amber-200/80 flex items-center justify-between">
                <span className="text-[11px] text-amber-900 font-semibold">Ready to apply?</span>
                <button
                  onClick={onOpenSignUp}
                  className="px-3.5 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-lg shadow-xs transition-colors cursor-pointer"
                >
                  Sign Up &rarr;
                </button>
              </div>
            </div>

            {/* Quick Application Lookup Card */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-3">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-700" />
                <h4 className="font-bold text-xs uppercase tracking-wide text-slate-900">
                  Track Your Existing Case
                </h4>
              </div>
              <p className="text-[11px] text-slate-500">
                Check status for an application already submitted or in progress.
              </p>
              <form onSubmit={handleTrackSubmit} className="space-y-2">
                <input
                  type="text"
                  value={trackingInput}
                  onChange={(e) => setTrackingInput(e.target.value)}
                  placeholder="Enter ZAM-OPAS-2026-..."
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-lg font-mono"
                />
                <button
                  type="submit"
                  className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
                >
                  Lookup Application
                </button>
              </form>
            </div>
          </aside>
        </div>
      </main>

      {/* ============================================================ */}
      {/* 4. INTERACTIVE TOPIC ANSWER MODAL */}
      {/* ============================================================ */}
      {selectedTopicAnswer && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 animate-in fade-in duration-150">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                  <Sparkles className="w-4 h-4 text-emerald-700" />
                </div>
                <h3 className="text-base font-bold text-slate-900">{selectedTopicAnswer.title}</h3>
              </div>
              <button
                onClick={() => setSelectedTopicAnswer(null)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">{selectedTopicAnswer.description}</p>

            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-2">
              <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block">
                Official MoHAIS Guidelines:
              </span>
              <ul className="space-y-1.5 text-xs text-slate-700">
                {selectedTopicAnswer.bullets.map((b, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{b}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => setSelectedTopicAnswer(null)}
                className="text-xs font-semibold text-slate-500 hover:text-slate-700 cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={() => handleLaunchAssistantWithQuery(selectedTopicAnswer.actionQuery)}
                className="px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{selectedTopicAnswer.actionLabel}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* 5. QUICK TRACK STATUS MODAL */}
      {/* ============================================================ */}
      {trackModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in duration-150">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-emerald-700" />
                <h3 className="text-base font-bold text-slate-900">Track Application Status</h3>
              </div>
              <button
                onClick={() => {
                  setTrackModalOpen(false);
                  setTrackResult(null);
                }}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleTrackSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Enter Tracking Reference or Green NRC:
                </label>
                <input
                  type="text"
                  value={trackingInput}
                  onChange={(e) => setTrackingInput(e.target.value)}
                  placeholder="e.g. ZAM-OPAS-2026-1592 or 318920/12/1"
                  className="w-full p-2.5 border border-slate-300 rounded-lg font-mono bg-white"
                />
              </div>
              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-lg font-bold transition-colors cursor-pointer"
              >
                Lookup Case Status
              </button>
            </form>

            {trackResult && (
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs animate-in fade-in">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900">{trackResult.fullName}</span>
                  <span
                    className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                      trackResult.status === 'Reverted'
                        ? 'bg-red-100 text-red-800'
                        : trackResult.status === 'Paid - Unsubmitted'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {trackResult.status}
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 font-mono">Ref: {trackResult.trackingNumber}</div>
                <div className="text-[11px] text-slate-600">Office: {trackResult.collectionOffice}</div>
                {trackResult.reversionReason && (
                  <p className="text-[11px] text-red-700 bg-red-50 p-2 rounded border border-red-200 mt-1 font-medium">
                    Note: {trackResult.reversionReason}
                  </p>
                )}
                <button
                  onClick={() => {
                    onSelectApplication(trackResult);
                    setTrackModalOpen(false);
                    onOpenLogin();
                  }}
                  className="w-full mt-2 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-md font-semibold text-[11px] cursor-pointer"
                >
                  Log In to Resolve this Dossier &rarr;
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Official Government Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-800 flex items-center justify-center text-white">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <span className="font-semibold text-slate-800 block">
                Republic of Zambia &bull; Ministry of Home Affairs and Internal Security (MoHAIS)
              </span>
              <p className="text-[11px] text-slate-400">
                Department of National Registration, Passports and Citizenship &bull; Online Passport Application System (OPAS)
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4 text-xs text-slate-600">
            <span>Passport Office, Makishi Road, Lusaka</span>
            <span aria-hidden="true">&bull;</span>
            <span>Support: +260 211 252 649</span>
            <span aria-hidden="true">&bull;</span>
            <span>opas-support@mohais.gov.zm</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
