import React, { useState, useEffect, useMemo } from 'react';
import {
  Search,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Sparkles,
  Upload,
  ArrowRight,
  Shield,
  FileText,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Send,
  MessageSquare,
  HelpCircle,
  PlusCircle,
  RefreshCw,
  Eye,
  Smartphone,
  Settings,
  CheckCheck,
  Bot,
  Bell,
  Lock,
  Globe,
  Volume2,
  CreditCard,
  Camera,
  Layers,
  Check,
  Printer,
  ChevronRight,
  ShieldCheck,
  AlertCircle,
  Info,
  Radio,
  ExternalLink,
  LayoutDashboard,
  Menu,
  X,
} from 'lucide-react';
import { PassportApplication, NotificationLog, UploadedDocument } from '../../types/passport';
import { APPROVED_FAQS } from '../../data/faqs';
import { ApplicationForm } from './ApplicationForm';
import { DocumentViewerModal } from '../common/DocumentViewerModal';
import { CitizenPhoneSimulatorModal } from '../common/CitizenPhoneSimulatorModal';
import { BiometricsSchedulerModal } from './BiometricsSchedulerModal';
import { AIGuidanceChat } from './AIGuidanceChat';
import { useChat } from '../../context/ChatContext';
import { validatePhoneNumber, validateEmail, validateNRC } from '../../utils/validation';
import { CaseDetailsForm, CaseDetailsState } from '../common/CaseDetailsForm';

type TabId =
  | 'status'
  | 'guidance'
  | 'checker'
  | 'monitoring'
  | 'messages'
  | 'apply'
  | 'faqs'
  | 'settings';

const PAGE_META: Record<TabId, { title: string; subtitle: string }> = {
  status: { title: 'Dashboard', subtitle: 'Your passport application at a glance.' },
  guidance: { title: 'AI Guidance', subtitle: 'Ask anything about requirements, fees and next steps.' },
  checker: { title: 'Data Validation', subtitle: 'Check your details before they reach an officer.' },
  monitoring: { title: 'Monitoring', subtitle: 'Track reversions, payments and review progress.' },
  messages: { title: 'Notifications', subtitle: 'SMS, email and message board updates.' },
  apply: { title: 'New Passport', subtitle: 'Start a new application.' },
  faqs: { title: 'Approved FAQs', subtitle: 'Verified answers published by MoHAIS.' },
  settings: { title: 'Settings', subtitle: 'Alerts, language and data governance.' },
};

interface CitizenPortalProps {
  applications: PassportApplication[];
  selectedApplication: PassportApplication;
  onSelectApplication: (app: PassportApplication) => void;
  onUpdateStatus: (id: string, newStatus: PassportApplication['status'], notes?: string) => void;
  onAddNewApplication: (newApp: PassportApplication) => void;
  onOpenAssistant: () => void;
  onAddNotification?: (id: string, notif: NotificationLog) => void;
}

export const CitizenPortal: React.FC<CitizenPortalProps> = ({
  applications,
  selectedApplication,
  onSelectApplication,
  onUpdateStatus,
  onAddNewApplication,
  onOpenAssistant,
  onAddNotification,
}) => {
  if (window.location.pathname === '/prototype-old') {
    return (
    <section className="min-h-screen bg-[#f8f8f5] px-5 py-8 text-[#0b3440] sm:px-10 sm:py-12">
      <div className="mx-auto flex max-w-[1320px] gap-8">
        <aside className="hidden w-60 shrink-0 rounded-xl border border-[#d9ddd8] bg-white p-3 shadow-sm lg:block">
          <p className="px-3 pb-4 pt-2 text-xs font-semibold uppercase tracking-wide text-[#54717a]">Applicant workspace</p>
          <nav className="space-y-1" aria-label="Citizen navigation">
            <button className="flex w-full items-center gap-3 rounded-lg bg-[#e7f1ed] px-3 py-2.5 text-left text-sm font-semibold text-[#075c50]"><LayoutDashboard className="h-4 w-4" /> Overview</button>
            <button className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm text-[#54717a] hover:bg-slate-50"><FileText className="h-4 w-4" /> My application</button>
            <button className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm text-[#54717a] hover:bg-slate-50"><Clock className="h-4 w-4" /> Track status</button>
            <button className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm text-[#54717a] hover:bg-slate-50"><Bell className="h-4 w-4" /> Notifications</button>
            <button className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm text-[#54717a] hover:bg-slate-50"><HelpCircle className="h-4 w-4" /> Help & guidance</button>
          </nav>
        </aside>
        <div className="max-w-[1100px] flex-1">
        <button
          type="button"
          aria-label="Open menu"
          className="mb-9 flex h-10 w-10 items-center justify-center rounded-md border border-slate-200 bg-white text-emerald-800 shadow-sm"
        >
          <Menu className="h-5 w-5" />
        </button>

        <p className="text-sm text-[#54717a]">Applicant workspace / Application overview</p>
        <h1 className="mt-2 text-[29px] font-bold tracking-tight text-[#0b2f39] sm:text-[32px]">Your next step, made clearer.</h1>

        <button
          type="button"
          className="mt-6 inline-flex items-center gap-2 rounded-lg border border-[#d8ddd8] bg-white px-4 py-3 text-sm font-semibold text-[#075c50] shadow-sm"
        >
          Open in OPAS
          <ExternalLink className="h-4 w-4" />
        </button>

        <p className="mt-3 text-[15px] text-[#54717a]">
          You can review what needs attention and get guidance before returning to existing OPAS.
        </p>

        <div className="mt-7 grid max-w-[1160px] grid-cols-2 gap-x-7 gap-y-7 rounded-xl border border-[#d9ddd8] bg-white px-5 py-6 shadow-sm sm:gap-x-12 sm:px-6">
          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-[#54717a]">Application reference · Demo</p>
            <p className="mt-1 text-[25px] font-semibold tracking-tight text-[#0b3440]">DEMO-02481</p>
          </div>
          <div>
            <p className="text-xs font-medium text-[#54717a]">Current OPAS status</p>
            <span className="mt-2 inline-flex rounded-md bg-[#fbf0dc] px-2.5 py-1.5 text-xs font-semibold text-[#56717a]">Reverted · Applicant action</span>
          </div>
          <div>
            <p className="text-xs font-medium text-[#54717a]">Last activity</p>
            <p className="mt-2 text-sm font-medium text-[#0b3440]">28 Oct 2026 · Officer note</p>
          </div>
          <div>
            <p className="text-xs font-medium text-[#54717a]">Payment record</p>
            <p className="mt-2 text-sm font-semibold text-[#0b3440]">Recorded in OPAS</p>
          </div>
        </div>

        <section className="mt-7 max-w-[1160px] rounded-xl border border-[#d9ddd8] bg-white px-5 py-5 shadow-sm sm:px-6" aria-labelledby="attention-heading">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h2 id="attention-heading" className="text-xl font-semibold tracking-tight text-[#0b3440]">What needs your attention</h2>
              <p className="mt-2 text-sm text-[#54717a]">Your application has been returned for corrections. It has not been rejected.</p>
            </div>
            <span className="shrink-0 rounded-md bg-[#fbf0dc] px-2.5 py-1.5 text-xs font-semibold text-[#a26212]">3 steps left</span>
          </div>

          <div className="mt-6 divide-y divide-[#d9ddd8]">
            <div className="flex gap-4 py-4 pt-0">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#fff2dc] text-sm font-semibold text-[#a26212]">1</span>
              <div>
                <h3 className="font-semibold text-[#0b3440]">Complete your address details</h3>
                <p className="mt-1 text-sm leading-5 text-[#54717a]">The residential district is missing. Check that your address details are consistent before resubmitting.</p>
                <button className="mt-2 inline-flex items-center gap-1 text-sm font-semibold text-[#075c50]">Review missing information <ArrowRight className="h-4 w-4" /></button>
              </div>
            </div>
            <div className="flex gap-4 py-4">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#fff2dc] text-sm font-semibold text-[#a26212]">2</span>
              <div>
                <h3 className="font-semibold text-[#0b3440]">Correct your contact formats</h3>
                <p className="mt-1 text-sm leading-5 text-[#54717a]">Your email is missing “@” and your phone has no country code. These checks do not verify ownership.</p>
                <button className="mt-2 inline-flex items-center gap-1 text-sm font-semibold text-[#075c50]">Check email and phone <ArrowRight className="h-4 w-4" /></button>
              </div>
            </div>
            <div className="flex gap-4 py-4">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#fff2dc] text-sm font-semibold text-[#a26212]">3</span>
              <div>
                <h3 className="font-semibold text-[#0b3440]">Review and resubmit in OPAS</h3>
                <p className="mt-1 text-sm leading-5 text-[#54717a]">Saving corrections here does not resubmit your application. Follow the officer note, then return to OPAS.</p>
                <button className="mt-2 inline-flex items-center gap-1 text-sm font-semibold text-[#075c50]">View the officer note <ArrowRight className="h-4 w-4" /></button>
              </div>
            </div>
          </div>

          <div className="border-t border-[#d9ddd8] pt-4">
            <button className="inline-flex items-center gap-2 rounded-lg bg-[#075c50] px-4 py-3 text-sm font-semibold text-white shadow-sm">Review corrections <ArrowRight className="h-4 w-4" /></button>
          </div>
        </section>

        <section className="mt-7 max-w-[1160px] rounded-xl border border-[#d9ddd8] bg-white px-5 py-6 shadow-sm sm:px-6" aria-labelledby="activity-heading">
          <div className="flex items-center justify-between gap-4">
            <h2 id="activity-heading" className="text-xl font-semibold tracking-tight text-[#0b3440]">Recent activity</h2>
            <button className="inline-flex items-center gap-1 text-sm font-medium text-[#075c50]">View in OPAS <ExternalLink className="h-3.5 w-3.5" /></button>
          </div>
          <ol className="mt-5 space-y-5">
            <li className="grid grid-cols-[8px_minmax(0,1fr)_auto] gap-x-3">
              <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-[#87a494]" />
              <div>
                <h3 className="text-sm font-semibold text-[#0b3440]">Returned for correction</h3>
                <p className="mt-1 text-sm text-[#54717a]">District missing; contact formats need review.</p>
              </div>
              <time className="text-xs text-[#54717a]">28 Oct · 14:20</time>
            </li>
            <li className="grid grid-cols-[8px_minmax(0,1fr)_auto] gap-x-3">
              <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-[#87a494]" />
              <div>
                <h3 className="text-sm font-semibold text-[#0b3440]">Application submitted</h3>
                <p className="mt-1 text-sm text-[#54717a]">Your application was sent for officer review.</p>
              </div>
              <time className="text-xs text-[#54717a]">24 Oct · 10:12</time>
            </li>
            <li className="grid grid-cols-[8px_minmax(0,1fr)_auto] gap-x-3">
              <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-[#87a494]" />
              <div>
                <h3 className="text-sm font-semibold text-[#0b3440]">Payment recorded</h3>
                <p className="mt-1 text-sm text-[#54717a]">Payment status is shown from the demo OPAS record.</p>
              </div>
              <time className="text-xs text-[#54717a]">24 Oct · 09:58</time>
            </li>
          </ol>
        </section>
        </div>
      </div>
      <nav className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-4 border-t border-[#d9ddd8] bg-white lg:hidden" aria-label="Citizen navigation">
        <button className="flex flex-col items-center gap-1 py-2 text-[11px] font-semibold text-[#075c50]"><LayoutDashboard className="h-5 w-5" />Overview</button>
        <button className="flex flex-col items-center gap-1 py-2 text-[11px] text-[#54717a]"><FileText className="h-5 w-5" />Application</button>
        <button className="flex flex-col items-center gap-1 py-2 text-[11px] text-[#54717a]"><Clock className="h-5 w-5" />Status</button>
        <button className="flex flex-col items-center gap-1 py-2 text-[11px] text-[#54717a]"><Menu className="h-5 w-5" />Menu</button>
      </nav>
    </section>
    );
  }

  if (window.location.pathname === '/') {
    return (
      <section className="min-h-screen bg-[#f0f2f5] p-4 text-slate-800 sm:p-6">
        <div className="mx-auto max-w-[1100px]">
          <div className="mb-4 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-900"><strong>Design intent:</strong> the assistant provides guidance and validation without disrupting the OPAS transaction flow. Human-officer escalation is always available.</div>
          <div className="overflow-hidden rounded-[14px] border-2 border-slate-300 bg-white shadow-lg">
            <header className="flex items-center gap-3 bg-[#0b3d91] px-5 py-3 text-sm text-white"><span className="rounded-md bg-[#f4b400] px-3 py-1 text-xs font-extrabold text-[#0b3d91]">OPAS</span><span>Online Passport Application System</span><nav className="ml-auto hidden gap-5 text-xs text-blue-100 md:flex"><button>Home</button><button>Apply</button><button>Track Application</button><button>FAQs</button><button>🇿🇲 EN</button></nav><Menu className="ml-auto h-5 w-5 md:hidden" /></header>
            <div className="flex flex-wrap gap-2 border-b border-indigo-200 bg-indigo-50 px-5 py-3 text-[11px]"><span className="rounded-full border border-green-300 bg-green-100 px-3 py-1 font-semibold text-green-800">✓ Personal Details</span><span className="rounded-full border border-green-300 bg-green-100 px-3 py-1 font-semibold text-green-800">✓ Documents</span><span className="rounded-full border border-[#0b3d91] bg-[#0b3d91] px-3 py-1 font-bold text-white">3 · Contact Details — you are here</span><span className="rounded-full border border-indigo-200 bg-white px-3 py-1 text-blue-900">4 · Review & Confirm</span><span className="rounded-full border border-indigo-200 bg-white px-3 py-1 text-blue-900">5 · Payment</span></div>
            <div className="grid gap-4 p-4 lg:grid-cols-[minmax(0,2fr)_minmax(310px,1.1fr)]">
              <main className="rounded-xl border border-dashed border-slate-400 bg-slate-50 p-4"><h2 className="mb-4 text-sm font-bold">Step 3 of 5 — Contact Details</h2><div className="space-y-3">
                <div className="rounded-lg border bg-white p-3"><label className="text-sm font-bold text-[#0b3d91]">Email address *</label><input readOnly value="chanda.mwansa@email.com" className="mt-2 w-full rounded-md border border-green-600 px-3 py-2 text-sm"/><span className="mt-2 inline-block rounded-full bg-green-100 px-2 py-0.5 text-[10px] font-bold text-green-800">✓ VALID FORMAT</span><p className="mt-1 text-xs text-green-700">Format looks correct. You’ll receive updates at this address.</p></div>
                <div className="rounded-lg border bg-white p-3"><label className="text-sm font-bold text-[#0b3d91]">Phone number *</label><input readOnly value="97 812 3456" className="mt-2 w-full rounded-md border border-amber-500 px-3 py-2 text-sm"/><span className="mt-2 inline-block rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-bold text-amber-800">⚠ CHECK COUNTRY CODE</span><p className="mt-1 text-xs leading-5 text-amber-700">Missing “+260” prefix. Zambian numbers should look like: <strong>+260 97X XXX XXX</strong>.</p></div>
                <div className="rounded-lg border bg-white p-3"><label className="text-sm font-bold text-[#0b3d91]">Residential address *</label><input readOnly value="Plot 12, Kabulonga, Lusaka" className="mt-2 w-full rounded-md border border-green-600 px-3 py-2 text-sm"/><span className="mt-2 inline-block rounded-full bg-green-100 px-2 py-0.5 text-[10px] font-bold text-green-800">✓ COMPLETE</span></div>
                <div className="rounded-lg border bg-white p-3"><p className="text-sm font-bold text-[#0b3d91]">Application completeness</p><div className="mt-2 h-3 overflow-hidden rounded bg-slate-200"><div className="h-full w-[78%] bg-green-600" /></div><p className="mt-1 text-xs text-slate-500">4 of 5 sections complete — 1 field needs attention before submission.</p></div>
              </div><div className="mt-4 flex flex-wrap gap-2"><button className="rounded-md bg-[#0b3d91] px-4 py-2 text-sm text-white">← Previous</button><button className="rounded-md bg-[#f4b400] px-4 py-2 text-sm font-bold text-[#0b3d91]">Save Draft</button><button className="rounded-md bg-[#0b3d91] px-4 py-2 text-sm text-white">Next →</button></div></main>
              <aside className="rounded-xl border border-dashed border-slate-400 bg-slate-50 p-4"><h2 className="mb-4 text-sm font-bold">🤖 AI Assistant <span className="rounded bg-[#f4b400] px-1.5 py-0.5 text-[10px] text-[#0b3d91]">BETA</span></h2><div className="space-y-3 rounded-xl border bg-white p-3 text-xs leading-5"><div className="rounded-lg border-l-4 border-[#0b3d91] bg-blue-50 p-3">Hello Chanda! I’ve checked your draft — you’re almost done. Your phone number is missing the country code.</div><div className="ml-6 rounded-lg border-l-4 border-slate-400 bg-slate-100 p-3">Yes, how do I fix it?</div><div className="rounded-lg border-l-4 border-[#0b3d91] bg-blue-50 p-3">Add <strong>+260</strong> at the start: <strong>+260 97 812 3456</strong>. I’ll re-check the format automatically.<br/><em>Format checks cannot confirm who owns the number.</em></div><div className="rounded-lg border-l-4 border-[#0b3d91] bg-blue-50 p-3">Prefer a human? <button className="font-semibold underline">Talk to a passport officer</button> — Mon–Fri, 08:00–17:00.</div><div className="flex justify-between rounded-full border border-slate-300 px-3 py-2 text-slate-400">Ask a question… <Send className="h-4 w-4 text-[#0b3d91]" /></div></div><div className="mt-3 rounded-lg border bg-white p-3 text-xs leading-5"><strong>🔔 Notification Center</strong><br/>📩 Next reminder: if no action in <strong>2 days</strong><br/>📋 OPAS Message Board: <strong>1 new message</strong> — <button className="underline">view</button><br/>✉️ Channels: SMS ☑ · Email ☑ · Message Board ☑</div></aside>
            </div>
            <footer className="flex flex-col gap-2 border-t bg-slate-50 px-5 py-3 text-[11px] text-slate-500 sm:flex-row sm:justify-between"><span>🔒 Privacy: processed under MoHAIS governance — role-based access and audit trails.</span><span>Human oversight at all times · AI never decides passport outcomes</span></footer>
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-2 rounded-xl border bg-white p-4 text-xs"><strong>Applicant journey:</strong><span className="rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-2">Enter / resume application</span><ArrowRight className="h-4 w-4 text-slate-400"/><span className="rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-2">Live validation + plain-language fixes</span><ArrowRight className="h-4 w-4 text-slate-400"/><span className="rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-2">Guided action back into OPAS</span></div>
        </div>
      </section>
    );
  }

  // Navigation tabs organized into logical modules
  const [activeTab, setActiveTab] = useState<TabId>('status');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [searchTracking, setSearchTracking] = useState('');
  const [reuploading, setReuploading] = useState(false);
  const [reuploadSuccess, setReuploadSuccess] = useState(false);
  const [aiPreCheckScore, setAiPreCheckScore] = useState<number | null>(null);
  const [inspectedDoc, setInspectedDoc] = useState<UploadedDocument | null>(null);
  const [isPhoneSimOpen, setIsPhoneSimOpen] = useState(false);
  const [isBiometricsModalOpen, setIsBiometricsModalOpen] = useState(false);

  // Settings State
  const [smsAlertsEnabled, setSmsAlertsEnabled] = useState(true);
  const [emailAlertsEnabled, setEmailAlertsEnabled] = useState(true);
  const [boardAlertsEnabled, setBoardAlertsEnabled] = useState(true);
  const [preferredLanguage, setPreferredLanguage] = useState<'English' | 'Bemba' | 'Nyanja' | 'Tonga'>('English');
  const [dataConsent, setDataConsent] = useState(true);
  const [settingsSavedNotice, setSettingsSavedNotice] = useState(false);

  // Details Checker State
  const [checkerPhone, setCheckerPhone] = useState(selectedApplication.contact.phone);
  const [checkerEmail, setCheckerEmail] = useState(selectedApplication.contact.email);
  const [checkerNotice, setCheckerNotice] = useState<string | null>(null);
  const [quickActionNotice, setQuickActionNotice] = useState<string | null>(null);
  const [monitoringFilter, setMonitoringFilter] = useState<'ALL' | 'REVERTED' | 'PAID_UNSUBMITTED' | 'INCOMPLETE' | 'REVIEW'>('ALL');

  const {
    setIsGuidanceScreen,
    setActiveApplication,
    autoVoice,
    setAutoVoice,
    setCurrentSection,
    populateQuery,
  } = useChat();

  // Helper for quick actions that prefill the persistent assistant
  const handleQuickAction = (label: string, query: string) => {
    setQuickActionNotice(`Loaded "${label}" into AI Assistant`);
    populateQuery(query);
    setTimeout(() => {
      setQuickActionNotice(null);
    }, 4000);
  };

  // Inform ChatContext whether user is on full-width guidance screen and update currently navigating section
  useEffect(() => {
    setIsGuidanceScreen(activeTab === 'guidance');
    const tabToSection: Record<string, string> = {
      status: 'Dashboard Overview',
      guidance: 'Applicant Guidance Assistant (Module 1)',
      checker: 'Data Validation Module (Module 2)',
      monitoring: 'Application Monitoring Module (Module 3)',
      messages: 'Automated Notification Prototype (Module 4)',
      apply: 'New Passport Application',
      faqs: 'Approved MoHAIS FAQs',
      settings: 'Citizen Settings & Governance',
    };
    setCurrentSection(tabToSection[activeTab] || 'Dashboard');
  }, [activeTab, setIsGuidanceScreen, setCurrentSection]);

  // Keep activeApplication in sync
  useEffect(() => {
    setActiveApplication(selectedApplication);
    setCheckerPhone(selectedApplication.contact.phone);
    setCheckerEmail(selectedApplication.contact.email);
  }, [selectedApplication, setActiveApplication]);

  // Real-time validations for Details Checker
  const phoneValidation = validatePhoneNumber(
    checkerPhone,
    selectedApplication.contact.phoneCountryCode || '+260'
  );
  const emailValidation = validateEmail(checkerEmail);
  const nrcValidation = validateNRC(selectedApplication.nrcNumber);

  // Stepper helper
  const getStageIndex = (status: PassportApplication['status']) => {
    switch (status) {
      case 'Draft':
        return 1;
      case 'Paid - Unsubmitted':
        return 2;
      case 'Submitted - Under Review':
        return 3;
      case 'Reverted':
        return 2.5; // flagged between review & submit
      case 'Biometrics Scheduled':
        return 4;
      case 'Processing & Printing':
        return 5;
      case 'Ready for Collection':
      case 'Completed':
        return 6;
      default:
        return 1;
    }
  };

  const currentStageNum = getStageIndex(selectedApplication.status);

  // Re-upload corrected document for reverted case
  const handleSimulateReupload = () => {
    setReuploading(true);
    setTimeout(() => {
      setAiPreCheckScore(97);
      setReuploadSuccess(true);
      setReuploading(false);

      setTimeout(() => {
        onUpdateStatus(
          selectedApplication.id,
          'Submitted - Under Review',
          'Applicant uploaded corrected photo via OPAS Citizen Assistant. Passed AI pre-flight optical checks.'
        );
        // Also update the document status in local array
        const photoDoc = selectedApplication.documents.find((d) => d.type === 'Passport Photo');
        if (photoDoc) {
          photoDoc.status = 'APPROVED';
          photoDoc.aiScore = 97;
          photoDoc.feedback = 'Compliant plain light background verified by AI optical pre-flight.';
        }
        setReuploadSuccess(false);
      }, 1500);
    }, 1000);
  };

  // Complete submission for paid unsubmitted case
  const handleFinalizePaidSubmit = () => {
    onUpdateStatus(
      selectedApplication.id,
      'Submitted - Under Review',
      'Applicant completed final submission step after automated surveillance reminder.'
    );
  };

  // Apply auto-fix in Details Checker
  const handleApplyDetailsFix = () => {
    if (phoneValidation.isValid) {
      selectedApplication.contact.phone = phoneValidation.formatted;
      setCheckerPhone(phoneValidation.formatted);
    }
    const cleanEmail = checkerEmail
      .replace('@gamil.com', '@gmail.com')
      .replace('@outlok.com', '@outlook.com')
      .replace('@yaho.com', '@yahoo.com');
    selectedApplication.contact.email = cleanEmail;
    setCheckerEmail(cleanEmail);

    setCheckerNotice('Contact details verified and normalized across OPAS registry.');
    setTimeout(() => setCheckerNotice(null), 3500);
  };

  const handleSaveVerifiedCaseDetails = (details: CaseDetailsState) => {
    selectedApplication.contact.province = details.province;
    selectedApplication.contact.district = details.district;
    selectedApplication.collectionOffice = details.interviewLocation;
    setCheckerNotice('Official Case Details successfully verified & synchronized with passport registry.');
    setTimeout(() => setCheckerNotice(null), 3500);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsSavedNotice(true);
    setTimeout(() => setSettingsSavedNotice(false), 3000);
  };

  // Computed monitoring list
  const filteredMonitoringApps = useMemo(() => {
    return applications.filter((app) => {
      if (monitoringFilter === 'REVERTED') return app.status === 'Reverted';
      if (monitoringFilter === 'PAID_UNSUBMITTED') return app.status === 'Paid - Unsubmitted';
      if (monitoringFilter === 'INCOMPLETE') return app.status === 'Draft' || !app.feePaid;
      if (monitoringFilter === 'REVIEW') return app.status === 'Submitted - Under Review';
      return true;
    });
  }, [applications, monitoringFilter]);

  // Overall counts for badges
  const monitoringCounts = useMemo(() => {
    const reverted = applications.filter((a) => a.status === 'Reverted').length;
    const paidUnsubmitted = applications.filter((a) => a.status === 'Paid - Unsubmitted').length;
    const incomplete = applications.filter((a) => a.status === 'Draft' || !a.feePaid).length;
    const review = applications.filter((a) => a.status === 'Submitted - Under Review').length;
    return { reverted, paidUnsubmitted, incomplete, review, total: applications.length };
  }, [applications]);

  const goTo = (tab: TabId) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const notifCount = selectedApplication.notifications.length;
  const navGroups: {
    label: string;
    items: { id: TabId; label: string; shortLabel: string; icon: React.ElementType; badge?: number; badgeTone?: 'red' | 'green' }[];
  }[] = [
    {
      label: 'Overview',
      items: [
        { id: 'status', label: 'Dashboard', shortLabel: 'Home', icon: LayoutDashboard },
        { id: 'guidance', label: 'AI Guidance', shortLabel: 'Guide', icon: Sparkles },
      ],
    },
    {
      label: 'My Application',
      items: [
        { id: 'checker', label: 'Data Validation', shortLabel: 'Validate', icon: CheckCheck },
        { id: 'monitoring', label: 'Monitoring', shortLabel: 'Track', icon: Clock, badge: monitoringCounts.reverted, badgeTone: 'red' },
        { id: 'messages', label: 'Notifications', shortLabel: 'Alerts', icon: Bell, badge: notifCount, badgeTone: 'green' },
      ],
    },
    {
      label: 'Services',
      items: [
        { id: 'apply', label: 'New Passport', shortLabel: 'Apply', icon: PlusCircle },
        { id: 'faqs', label: 'Approved FAQs', shortLabel: 'FAQs', icon: HelpCircle },
        { id: 'settings', label: 'Settings', shortLabel: 'Settings', icon: Settings },
      ],
    },
  ];

  const bottomNavItems = (['status', 'guidance', 'monitoring', 'messages'] as TabId[]).map(
    (id) => navGroups.flatMap((g) => g.items).find((i) => i.id === id)!
  );

  const sidebarContent = (
    <>
      <div className="p-4 border-b border-slate-100">
        <div className="flex items-center gap-2 mb-2">
          <span className="w-2 h-2 rounded-full bg-emerald-600" />
          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800">Citizen Self-Service</span>
        </div>
        <p className="text-sm font-extrabold text-slate-900 leading-tight">{selectedApplication.fullName}</p>
        <p className="text-[11px] font-mono text-slate-500 mt-0.5">{selectedApplication.trackingNumber}</p>
        <span className="inline-block mt-2 text-[10px] font-bold px-2 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
          {selectedApplication.status}
        </span>
      </div>
      <nav className="flex-1 p-3 space-y-4" aria-label="Citizen navigation">
        {navGroups.map((group) => (
          <div key={group.label}>
            <p className="px-3 mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">{group.label}</p>
            <div className="space-y-0.5">
              {group.items.map((item) => {
                const Icon = item.icon;
                const active = item.id === activeTab;
                return (
                  <button key={item.id} onClick={() => goTo(item.id)} aria-current={active ? 'page' : undefined}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-colors cursor-pointer ${active ? 'bg-emerald-800 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'}`}>
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="flex-1 text-left">{item.label}</span>
                    {item.badge ? <span className={`min-w-5 h-5 px-1.5 rounded-full text-[10px] font-black flex items-center justify-center ${active ? 'bg-white/20 text-white' : item.badgeTone === 'red' ? 'bg-red-100 text-red-800' : 'bg-emerald-100 text-emerald-800'}`}>{item.badge}</span> : null}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </nav>
    </>
  );

  return (
    <div className="lg:flex lg:items-start lg:gap-6">
      {/* =========================================================================
          TOP CITIZEN HERO & NAVIGATION BAR
         ========================================================================= */}
      <aside className="hidden lg:flex flex-col w-64 shrink-0 sticky top-32 max-h-[calc(100vh-9rem)] overflow-y-auto bg-white border border-slate-200 rounded-2xl shadow-xs">
        {sidebarContent}
      </aside>
      <div className="flex-1 min-w-0 space-y-5 pb-24 lg:pb-0">
        <div className="lg:hidden flex items-center justify-between gap-3 bg-white border border-slate-200 rounded-2xl px-4 py-3 shadow-xs">
          <div className="min-w-0">
            <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-800">OPAS Citizen Portal</p>
            <h2 className="text-base font-extrabold text-slate-900 truncate">{PAGE_META[activeTab].title}</h2>
          </div>
          <button
            onClick={() => setMobileMenuOpen(true)}
            className="p-2.5 rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200 cursor-pointer"
            aria-label="Open navigation menu"
          >
            <Menu className="w-5 h-5" />
          </button>
        </div>
        <div className="hidden lg:flex items-end justify-between gap-4 px-1">
          <div>
            <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">{PAGE_META[activeTab].title}</h2>
            <p className="text-sm text-slate-500 mt-0.5">{PAGE_META[activeTab].subtitle}</p>
          </div>
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 bg-white border border-slate-200 rounded-full px-3 py-1.5"><span className="w-2 h-2 rounded-full bg-emerald-600" />{selectedApplication.trackingNumber}</span>
        </div>

      {/* =========================================================================
          SCREEN 1: DASHBOARD OVERVIEW (DEFAULT TAB)
         ========================================================================= */}
      {activeTab === 'status' && (
        <div className="space-y-6">
          {/* Tracker Search & Demo Case Slicer */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex-1 max-w-lg relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTracking}
                onChange={(e) => setSearchTracking(e.target.value)}
                placeholder="Search by OPAS Reference (e.g., ZAM-OPAS-2026-1592) or Green NRC..."
                className="w-full text-xs pl-9 pr-3 py-2.5 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-emerald-500 bg-white"
              />
            </div>

            <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500">
              <span className="font-semibold text-slate-600 mr-1 hidden sm:inline">Inspect Test Case:</span>
              <button
                onClick={() => {
                  const m = applications.find((a) => a.id === 'app-002');
                  if (m) onSelectApplication(m);
                }}
                className={`px-2.5 py-1 rounded-md font-semibold text-[11px] transition-colors cursor-pointer border ${
                  selectedApplication.id === 'app-002'
                    ? 'bg-red-700 text-white border-red-800 shadow-2xs'
                    : 'bg-red-50 text-red-700 border-red-200 hover:bg-red-100'
                }`}
              >
                Case 1: Reverted Photo (Mutinta)
              </button>
              <button
                onClick={() => {
                  const p = applications.find((a) => a.id === 'app-001');
                  if (p) onSelectApplication(p);
                }}
                className={`px-2.5 py-1 rounded-md font-semibold text-[11px] transition-colors cursor-pointer border ${
                  selectedApplication.id === 'app-001'
                    ? 'bg-amber-600 text-white border-amber-700 shadow-2xs'
                    : 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
                }`}
              >
                Case 2: Paid Unsubmitted (Kondwani)
              </button>
              <button
                onClick={() => {
                  const r = applications.find((a) => a.id === 'app-006');
                  if (r) onSelectApplication(r);
                }}
                className={`px-2.5 py-1 rounded-md font-semibold text-[11px] transition-colors cursor-pointer border ${
                  selectedApplication.id === 'app-006'
                    ? 'bg-emerald-700 text-white border-emerald-800 shadow-2xs'
                    : 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                }`}
              >
                Case 5: Ready for Pickup (Mwamba)
              </button>
            </div>
          </div>

          {/* =========================================================================
              THE 4 CORE MODULES ARCHITECTURE STRIP
             ========================================================================= */}
          <div className="bg-slate-900 text-white rounded-2xl p-5 sm:p-6 shadow-md space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div>
                <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-widest font-mono">
                  Operational Core Architecture
                </span>
                <h3 className="text-base sm:text-lg font-bold text-white mt-0.5">
                  4 Key System Capabilities Supporting Your Application
                </h3>
              </div>
              <span className="text-xs text-slate-400">
                MoHAIS OPAS &bull; Active Intelligence Layer
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
              {/* Module 1: Applicant Guidance Assistant */}
              <div
                onClick={() => setActiveTab('guidance')}
                className="bg-slate-800/80 hover:bg-slate-800 border border-slate-700 hover:border-emerald-500 rounded-xl p-4 transition-all cursor-pointer flex flex-col justify-between group shadow-xs"
              >
                <div>
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="font-mono text-[10px] text-emerald-300 font-bold uppercase tracking-wider bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800/60">
                      Module 1
                    </span>
                    <Sparkles className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
                  </div>
                  <h4 className="font-bold text-sm text-white group-hover:text-emerald-300 transition-colors">
                    Applicant Guidance Assistant
                  </h4>
                  <p className="text-[11px] text-slate-300 mt-1 leading-snug">
                    Working 24/7 prototype answering approved FAQs and guiding applicants through common issues.
                  </p>
                </div>
                <div className="mt-3 pt-2.5 border-t border-slate-700/60 flex items-center justify-between text-[11px] text-emerald-400 font-semibold">
                  <span>Chat &amp; Voice Synthesis</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>

              {/* Module 2: Data Validation Module */}
              <div
                onClick={() => setActiveTab('checker')}
                className="bg-slate-800/80 hover:bg-slate-800 border border-slate-700 hover:border-blue-500 rounded-xl p-4 transition-all cursor-pointer flex flex-col justify-between group shadow-xs"
              >
                <div>
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="font-mono text-[10px] text-blue-300 font-bold uppercase tracking-wider bg-blue-950/80 px-2 py-0.5 rounded border border-blue-800/60">
                      Module 2
                    </span>
                    <CheckCheck className="w-4 h-4 text-blue-400 group-hover:scale-110 transition-transform" />
                  </div>
                  <h4 className="font-bold text-sm text-white group-hover:text-blue-300 transition-colors">
                    Data Validation Module
                  </h4>
                  <p className="text-[11px] text-slate-300 mt-1 leading-snug">
                    Mechanisms for identifying invalid contact formats, missing fields, and potential application errors.
                  </p>
                </div>
                <div className="mt-3 pt-2.5 border-t border-slate-700/60 flex items-center justify-between text-[11px] text-blue-400 font-semibold">
                  <span>+260 E.164 &amp; Typo Guard</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>

              {/* Module 3: Application Monitoring Module */}
              <div
                onClick={() => setActiveTab('monitoring')}
                className="bg-slate-800/80 hover:bg-slate-800 border border-slate-700 hover:border-amber-500 rounded-xl p-4 transition-all cursor-pointer flex flex-col justify-between group shadow-xs"
              >
                <div>
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="font-mono text-[10px] text-amber-300 font-bold uppercase tracking-wider bg-amber-950/80 px-2 py-0.5 rounded border border-amber-800/60">
                      Module 3
                    </span>
                    <Clock className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
                  </div>
                  <h4 className="font-bold text-sm text-white group-hover:text-amber-300 transition-colors">
                    Application Monitoring Module
                  </h4>
                  <p className="text-[11px] text-slate-300 mt-1 leading-snug">
                    Logic to identify incomplete, paid-but-unsubmitted, and reverted applications requiring attention.
                  </p>
                </div>
                <div className="mt-3 pt-2.5 border-t border-slate-700/60 flex items-center justify-between text-[11px] text-amber-400 font-semibold">
                  <span>Lifecycle &amp; Reversion Tracking</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>

              {/* Module 4: Automated Notification Prototype */}
              <div
                onClick={() => setActiveTab('messages')}
                className="bg-slate-800/80 hover:bg-slate-800 border border-slate-700 hover:border-purple-500 rounded-xl p-4 transition-all cursor-pointer flex flex-col justify-between group shadow-xs"
              >
                <div>
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="font-mono text-[10px] text-purple-300 font-bold uppercase tracking-wider bg-purple-950/80 px-2 py-0.5 rounded border border-purple-800/60">
                      Module 4
                    </span>
                    <Bell className="w-4 h-4 text-purple-400 group-hover:scale-110 transition-transform" />
                  </div>
                  <h4 className="font-bold text-sm text-white group-hover:text-purple-300 transition-colors">
                    Automated Notification Prototype
                  </h4>
                  <p className="text-[11px] text-slate-300 mt-1 leading-snug">
                    Functionality for generating and tracking approved reminders and message-board notifications.
                  </p>
                </div>
                <div className="mt-3 pt-2.5 border-t border-slate-700/60 flex items-center justify-between text-[11px] text-purple-400 font-semibold">
                  <span>SMS Handset Simulator</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>
          </div>

          {/* Quick Actions Row: 1-Click Assistant Question Starters */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 shadow-xs space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 border-b border-slate-100 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-emerald-800 text-emerald-100 flex items-center justify-center shadow-2xs shrink-0">
                  <Sparkles className="w-4 h-4 text-emerald-300" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
                    <span>AI Assistant Quick Actions (Module 1)</span>
                    <span className="text-[10px] bg-emerald-50 text-emerald-800 font-semibold px-2 py-0.5 rounded-full border border-emerald-200 hidden sm:inline">
                      1-Click Pre-populate
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Click any quick action below to open the persistent assistant with a pre-populated question tailored to case #{selectedApplication.trackingNumber}.
                  </p>
                </div>
              </div>

              {quickActionNotice && (
                <div className="text-[11px] text-emerald-900 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-lg font-medium flex items-center gap-1.5 animate-in fade-in shrink-0">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>{quickActionNotice}</span>
                </div>
              )}
            </div>

            {/* Row of Quick Actions Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
              {/* Button 1: Check Status */}
              <button
                type="button"
                onClick={() =>
                  handleQuickAction(
                    'Check Status',
                    `What is the current status of my passport application #${selectedApplication.trackingNumber} (${selectedApplication.status}), what are my estimated waiting days, and what exact step is required from me?`
                  )
                }
                className="group relative p-3 rounded-xl border border-slate-200 hover:border-emerald-500 bg-slate-50/70 hover:bg-emerald-50/50 text-left transition-all duration-150 hover:shadow-xs flex flex-col justify-between cursor-pointer"
                title="Ask AI Assistant to check current status and next actions"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center group-hover:scale-105 transition-transform">
                      <Clock className="w-4 h-4" />
                    </div>
                    <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100/70 px-1.5 py-0.2 rounded font-mono">
                      {selectedApplication.status}
                    </span>
                  </div>
                  <div className="text-xs font-bold text-slate-900 group-hover:text-emerald-900">
                    Check Status
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2 leading-snug">
                    Tracking #{selectedApplication.trackingNumber} timeline &amp; next required action
                  </p>
                </div>
                <div className="mt-2.5 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[10px] font-bold text-emerald-700 group-hover:text-emerald-800">
                  <span>Pre-populate Chat</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </button>

              {/* Button 2: Document Checklist */}
              <button
                type="button"
                onClick={() =>
                  handleQuickAction(
                    'Document Checklist',
                    `What is the official document checklist for my passport application? What are the requirements for Green NRC certification, Registrar General birth certificates, and authorized guarantor verification?`
                  )
                }
                className="group relative p-3 rounded-xl border border-slate-200 hover:border-blue-500 bg-slate-50/70 hover:bg-blue-50/50 text-left transition-all duration-150 hover:shadow-xs flex flex-col justify-between cursor-pointer"
                title="Ask AI Assistant for official document checklist"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-800 flex items-center justify-center group-hover:scale-105 transition-transform">
                      <FileText className="w-4 h-4" />
                    </div>
                    <span className="text-[10px] font-bold text-blue-800 bg-blue-100/70 px-1.5 py-0.2 rounded font-mono">
                      {selectedApplication.documents.length} Docs
                    </span>
                  </div>
                  <div className="text-xs font-bold text-slate-900 group-hover:text-blue-900">
                    Document Checklist
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2 leading-snug">
                    Green NRC, birth certificate &amp; official guarantor verification rules
                  </p>
                </div>
                <div className="mt-2.5 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[10px] font-bold text-blue-700 group-hover:text-blue-800">
                  <span>Pre-populate Chat</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </button>

              {/* Button 3: Help with Fees */}
              <button
                type="button"
                onClick={() =>
                  handleQuickAction(
                    'Help with Fees',
                    `What are the official passport fee schedules for 32-page ordinary (ZMW 500) vs 48-page frequent traveler (ZMW 1,000) passports, express service fees, and how do I complete payments through the Government Payment Gateway?`
                  )
                }
                className="group relative p-3 rounded-xl border border-slate-200 hover:border-amber-500 bg-slate-50/70 hover:bg-amber-50/50 text-left transition-all duration-150 hover:shadow-xs flex flex-col justify-between cursor-pointer"
                title="Ask AI Assistant about passport fees & payment gateway"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="w-7 h-7 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center group-hover:scale-105 transition-transform">
                      <CreditCard className="w-4 h-4" />
                    </div>
                    <span className="text-[10px] font-bold text-amber-800 bg-amber-100/70 px-1.5 py-0.2 rounded font-mono">
                      GPG Portal
                    </span>
                  </div>
                  <div className="text-xs font-bold text-slate-900 group-hover:text-amber-900">
                    Help with Fees
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2 leading-snug">
                    32 vs 48 pages, express costs &amp; online government payment gateway
                  </p>
                </div>
                <div className="mt-2.5 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[10px] font-bold text-amber-700 group-hover:text-amber-800">
                  <span>Pre-populate Chat</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </button>

              {/* Button 4: Photo Standards */}
              <button
                type="button"
                onClick={() =>
                  handleQuickAction(
                    'Photo Standards',
                    `What are the strict photo specifications (45mm x 35mm, plain off-white/grey background, neutral expression, spectacles glare, and religious headwear rules) to ensure my passport photo is accepted?`
                  )
                }
                className="group relative p-3 rounded-xl border border-slate-200 hover:border-purple-500 bg-slate-50/70 hover:bg-purple-50/50 text-left transition-all duration-150 hover:shadow-xs flex flex-col justify-between cursor-pointer"
                title="Ask AI Assistant about ICAO passport photo specifications"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="w-7 h-7 rounded-lg bg-purple-100 text-purple-800 flex items-center justify-center group-hover:scale-105 transition-transform">
                      <Camera className="w-4 h-4" />
                    </div>
                    <span className="text-[10px] font-bold text-purple-800 bg-purple-100/70 px-1.5 py-0.2 rounded font-mono">
                      45×35mm
                    </span>
                  </div>
                  <div className="text-xs font-bold text-slate-900 group-hover:text-purple-900">
                    Photo Standards
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2 leading-snug">
                    Background uniformity, glare prevention, expression &amp; ICAO dimensions
                  </p>
                </div>
                <div className="mt-2.5 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[10px] font-bold text-purple-700 group-hover:text-purple-800">
                  <span>Pre-populate Chat</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </button>

              {/* Button 5: Reversion Help */}
              <button
                type="button"
                onClick={() =>
                  handleQuickAction(
                    'Reversion Help',
                    selectedApplication.status === 'Reverted'
                      ? `My passport application #${selectedApplication.trackingNumber} has been reverted with reason: "${selectedApplication.reversionReason}". Can you guide me through resolving this step-by-step without paying a new fee?`
                      : `What happens if an application is reverted by a passport vetting officer, how do I submit corrections, and do I have to pay another statutory fee?`
                  )
                }
                className={`group relative p-3 rounded-xl border text-left transition-all duration-150 hover:shadow-xs flex flex-col justify-between cursor-pointer ${
                  selectedApplication.status === 'Reverted'
                    ? 'border-red-300 bg-red-50/80 hover:bg-red-100/70 hover:border-red-500'
                    : 'border-slate-200 hover:border-rose-500 bg-slate-50/70 hover:bg-rose-50/50'
                }`}
                title="Ask AI Assistant about application reversion policies"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center group-hover:scale-105 transition-transform ${
                        selectedApplication.status === 'Reverted'
                          ? 'bg-red-600 text-white'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      <AlertTriangle className="w-4 h-4" />
                    </div>
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.2 rounded font-mono ${
                        selectedApplication.status === 'Reverted'
                          ? 'bg-red-200 text-red-900 animate-pulse'
                          : 'bg-rose-100/70 text-rose-800'
                      }`}
                    >
                      {selectedApplication.status === 'Reverted' ? 'Action Needed' : 'Zero Re-fee'}
                    </span>
                  </div>
                  <div className="text-xs font-bold text-slate-900 group-hover:text-rose-900">
                    Reversion Help
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2 leading-snug">
                    {selectedApplication.status === 'Reverted'
                      ? `Fix "${selectedApplication.reversionReason?.slice(0, 30)}..."`
                      : 'How to correct flagged errors without repaying application fees'}
                  </p>
                </div>
                <div
                  className={`mt-2.5 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[10px] font-bold ${
                    selectedApplication.status === 'Reverted'
                      ? 'text-red-700 group-hover:text-red-800'
                      : 'text-rose-700 group-hover:text-rose-800'
                  }`}
                >
                  <span>Pre-populate Chat</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </button>
            </div>
          </div>

          {/* =========================================================================
              ACTIVE APPLICATION MONITORING & RESOLUTION CENTER (MODULE 3)
             ========================================================================= */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
            {/* Header info */}
            <div className="p-5 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-start gap-3.5">
                <div className="w-12 h-12 rounded-lg bg-emerald-800 flex items-center justify-center text-white shrink-0 shadow-xs">
                  <Shield className="w-6 h-6 stroke-[2]" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-slate-900">{selectedApplication.fullName}</h3>
                    <span className="font-mono text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-semibold">
                      {selectedApplication.trackingNumber}
                    </span>
                    {selectedApplication.isUrgent && (
                      <span className="text-[10px] bg-amber-500 text-slate-950 font-bold px-1.5 py-0.5 rounded">
                        EXPRESS
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-slate-500 mt-1 flex flex-wrap items-center gap-2">
                    <span>NRC: {selectedApplication.nrcNumber}</span>
                    <span aria-hidden="true">&bull;</span>
                    <span>Type: {selectedApplication.passportType}</span>
                    <span aria-hidden="true">&bull;</span>
                    <span>Office: {selectedApplication.collectionOffice}</span>
                  </div>
                </div>
              </div>

              {/* Status Badge & Actions */}
              <div className="flex items-center gap-2.5">
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Current Stage</span>
                  <span
                    className={`inline-block px-2.5 py-1 rounded text-xs font-bold ${
                      selectedApplication.status === 'Reverted'
                        ? 'bg-red-100 text-red-800'
                        : selectedApplication.status === 'Paid - Unsubmitted'
                        ? 'bg-amber-100 text-amber-800'
                        : selectedApplication.status === 'Ready for Collection'
                        ? 'bg-emerald-100 text-emerald-800'
                        : selectedApplication.status === 'Biometrics Scheduled'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-slate-100 text-slate-800'
                    }`}
                  >
                    {selectedApplication.status}
                  </span>
                </div>

                <button
                  onClick={() => setActiveTab('guidance')}
                  className="px-3 py-2 bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-lg text-xs font-semibold hover:bg-emerald-100 transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Open Guidance Console</span>
                </button>
              </div>
            </div>

            {/* Visual 6-Stage Progress Stepper */}
            <div className="p-6 bg-slate-50 border-b border-slate-200">
              <span className="text-[10px] uppercase font-bold text-slate-400 block mb-3">
                Official OPAS Processing Lifecycle (Module 3 Surveillance)
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-xs">
                {[
                  { num: 1, label: 'Intake & Form' },
                  { num: 2, label: 'Statutory Fee' },
                  { num: 3, label: 'Officer Review' },
                  { num: 4, label: 'Biometrics' },
                  { num: 5, label: 'Personalization' },
                  { num: 6, label: 'Ready for Pickup' },
                ].map((s) => {
                  const isDone = currentStageNum >= s.num && selectedApplication.status !== 'Reverted';
                  const isCurrent = Math.floor(currentStageNum) === s.num;
                  const isRevertedAtThis = selectedApplication.status === 'Reverted' && s.num === 3;

                  return (
                    <div
                      key={s.num}
                      className={`p-2.5 rounded-lg border transition-all ${
                        isRevertedAtThis
                          ? 'bg-red-50 border-red-300 text-red-900'
                          : isDone
                          ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                          : isCurrent
                          ? 'bg-white border-emerald-500 shadow-xs text-slate-900 ring-1 ring-emerald-500'
                          : 'bg-white border-slate-200 text-slate-400'
                      }`}
                    >
                      <div className="flex items-center justify-between text-[11px] mb-1 font-semibold">
                        <span>Step {s.num}</span>
                        {isDone && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                        {isRevertedAtThis && <AlertTriangle className="w-3.5 h-3.5 text-red-600" />}
                      </div>
                      <div className="font-semibold text-xs leading-tight">{s.label}</div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* ACTION CENTER 1: Reverted Case Resolution Panel */}
            {selectedApplication.status === 'Reverted' && (
              <div className="p-6 bg-red-50/70 border-b border-red-200 space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                    <AlertTriangle className="w-4 h-4" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-red-950">
                      Action Required: Application Reverted by Passport Officer
                    </h4>
                    <p className="text-xs text-red-800 leading-relaxed">
                      <strong>Reason from Officer:</strong> &ldquo;{selectedApplication.reversionReason}&rdquo;
                    </p>
                    <p className="text-[11px] text-red-700">
                      Good news: You do <strong>NOT</strong> have to pay the fee again. Simply upload the corrected item below to restore your place in the processing queue.
                    </p>
                  </div>
                </div>

                {/* Upload Correction with AI Pre-Check */}
                <div className="bg-white border border-red-200 rounded-lg p-4 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        Upload Corrected Passport Photo
                      </span>
                      <span className="text-[11px] text-slate-500">
                        Plain off-white/light-grey background, even lighting, no sunglasses or shadows.
                      </span>
                    </div>
                    <button
                      onClick={handleSimulateReupload}
                      disabled={reuploading || reuploadSuccess}
                      className="px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-md shadow-xs transition-colors cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
                    >
                      {reuploading ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>Checking with AI...</span>
                        </>
                      ) : reuploadSuccess ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Approved &amp; Resubmitted!</span>
                        </>
                      ) : (
                        <>
                          <Upload className="w-3.5 h-3.5" />
                          <span>Simulate Upload Corrected Photo</span>
                        </>
                      )}
                    </button>
                  </div>

                  {reuploadSuccess && (
                    <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-md text-xs text-emerald-900 flex items-center justify-between">
                      <span className="font-semibold flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        AI Pre-Check Passed (Optical Score: {aiPreCheckScore}/100)! Moving case back to Vetting Officer.
                      </span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ACTION CENTER 2: Paid-but-Unsubmitted Alert Panel */}
            {selectedApplication.status === 'Paid - Unsubmitted' && (
              <div className="p-6 bg-amber-50 border-b border-amber-200 space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-amber-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-amber-950">
                      Statutory Payment Received &bull; Final Submission Pending!
                    </h4>
                    <p className="text-xs text-amber-900 leading-relaxed">
                      We have verified your payment of <strong>ZMW {selectedApplication.feeAmount}</strong> (Ref: {selectedApplication.paymentReference || 'GPG-TX-994821'}). However, your application remains unsubmitted in draft status.
                    </p>
                    <p className="text-[11px] text-amber-800">
                      Click &quot;Finalize &amp; Submit Application&quot; to formally transmit your dossier to the Passport Office and trigger your biometrics booking.
                    </p>
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    onClick={handleFinalizePaidSubmit}
                    className="px-5 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-md shadow-xs transition-colors cursor-pointer flex items-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Finalize &amp; Submit Application to Passport Office</span>
                  </button>
                </div>
              </div>
            )}

            {/* Details Grid */}
            <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6 text-xs border-b border-slate-100">
              {/* Column 1: Contact Info */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] uppercase font-bold text-slate-400 block">Contact Information</span>
                  <button
                    onClick={() => setIsPhoneSimOpen(true)}
                    className="text-[10px] text-emerald-800 hover:text-emerald-950 font-bold flex items-center gap-1 cursor-pointer bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200"
                  >
                    <Smartphone className="w-3 h-3" />
                    <span>SMS Handset</span>
                  </button>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                  <div className="flex items-center gap-2 text-slate-700">
                    <Phone className="w-3.5 h-3.5 text-slate-500" />
                    <span className="font-mono">{selectedApplication.contact.phone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-700">
                    <Mail className="w-3.5 h-3.5 text-slate-500" />
                    <span className="truncate">{selectedApplication.contact.email}</span>
                  </div>
                  <div className="flex items-start gap-2 text-slate-700">
                    <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
                    <span>
                      {selectedApplication.contact.residentialAddress}, {selectedApplication.contact.district}
                    </span>
                  </div>
                </div>
              </div>

              {/* Column 2: Guarantor Info */}
              <div className="space-y-2">
                <span className="text-[11px] uppercase font-bold text-slate-400 block">Verified Guarantor</span>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1.5">
                  <div className="font-semibold text-slate-900">{selectedApplication.guarantor.fullName}</div>
                  <div className="text-slate-600">{selectedApplication.guarantor.profession}</div>
                  <div className="text-[11px] text-slate-500 font-mono">
                    NRC: {selectedApplication.guarantor.nrcNumber}
                  </div>
                  <div className="text-[11px] text-slate-500">{selectedApplication.guarantor.organization}</div>
                </div>
              </div>

              {/* Column 3: Biometrics & Collection Info */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] uppercase font-bold text-slate-400 block">Collection &amp; Biometrics</span>
                  <button
                    onClick={() => setIsBiometricsModalOpen(true)}
                    className="text-[10px] text-emerald-800 hover:text-emerald-950 font-bold flex items-center gap-1 cursor-pointer bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200"
                  >
                    <Calendar className="w-3 h-3" />
                    <span>Schedule / Slip</span>
                  </button>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                  <div>
                    <div className="text-slate-500 text-[11px]">Pickup Office:</div>
                    <div className="font-semibold text-slate-900">{selectedApplication.collectionOffice}</div>
                  </div>
                  {selectedApplication.biometricsDate ? (
                    <div>
                      <div className="text-slate-500 text-[11px]">Appointment Confirmed:</div>
                      <div className="font-semibold text-emerald-800 flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        {selectedApplication.biometricsDate}
                      </div>
                    </div>
                  ) : (
                    <button
                      onClick={() => setIsBiometricsModalOpen(true)}
                      className="w-full py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded text-[11px] font-semibold transition-colors cursor-pointer flex items-center justify-center gap-1"
                    >
                      <Calendar className="w-3 h-3" />
                      <span>Book Biometrics Slot</span>
                    </button>
                  )}
                  {selectedApplication.status === 'Ready for Collection' && (
                    <div className="p-2 bg-emerald-100/70 border border-emerald-300 rounded text-emerald-950 font-semibold text-[11px]">
                      Booklet ready at Counter 4. Bring original Green NRC.
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Dossier Uploaded Documents Preview Section */}
            <div className="p-6 bg-slate-50/50 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                    Uploaded Dossier Documents ({selectedApplication.documents.length})
                  </span>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Click any document below to inspect optical inspection quality, dimensions, and officer verification notes.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {selectedApplication.documents.map((doc) => (
                  <div
                    key={doc.id}
                    onClick={() => setInspectedDoc(doc)}
                    className="p-3 bg-white border border-slate-200 hover:border-emerald-400 rounded-xl shadow-2xs hover:shadow-sm transition-all cursor-pointer flex items-center justify-between gap-2 group"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-800 flex items-center justify-center shrink-0 border border-emerald-200">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="font-semibold text-slate-900 truncate text-xs group-hover:text-emerald-900">
                          {doc.name}
                        </div>
                        <div className="text-[11px] text-slate-500 truncate">{doc.type}</div>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                          doc.status === 'APPROVED'
                            ? 'bg-emerald-100 text-emerald-800'
                            : doc.status === 'REJECTED'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {doc.status}
                      </span>
                      {doc.aiScore && (
                        <div className="text-[10px] font-mono text-slate-400 mt-0.5">
                          {doc.aiScore}/100
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 1: APPLICANT GUIDANCE ASSISTANT (DEDICATED FULL TAB)
         ========================================================================= */}
      {activeTab === 'guidance' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded uppercase">
                  Module 1: Applicant Guidance Assistant
                </span>
                <span className="text-xs text-emerald-700 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Working Prototype Active
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900 mt-1">
                24/7 Virtual Assistant with Speech Synthesis &amp; Policy Grounding
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Answers approved MoHAIS immigration FAQs, resolves passport photo &amp; fee queries, and provides plain-language reversion help.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('faqs')}
                className="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-semibold cursor-pointer"
              >
                Browse FAQ Library
              </button>
            </div>
          </div>

          {/* Full-width AI Assistant Component sharing ChatContext */}
          <AIGuidanceChat isFullWidth={true} onNavigateToTab={(tab) => setActiveTab(tab as any)} />
        </div>
      )}

      {/* =========================================================================
          MODULE 2: DATA VALIDATION MODULE (DEDICATED TAB)
         ========================================================================= */}
      {activeTab === 'checker' && (
        <div className="space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold bg-blue-100 text-blue-900 px-2 py-0.5 rounded uppercase">
                  Module 2: Data Validation Module
                </span>
                <span className="text-xs text-blue-700 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> E.164 &amp; Typo Scanner Active
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900 mt-1">
                Contact &amp; Application Data Integrity Checker
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Mechanisms for identifying invalid contact formats, missing fields, and potential application errors before dispatch.
              </p>
            </div>
            <button
              onClick={handleApplyDetailsFix}
              className="px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Normalize &amp; Save Verified Details</span>
            </button>
          </div>

          {checkerNotice && (
            <div className="p-3.5 bg-emerald-50 border border-emerald-300 rounded-xl text-xs text-emerald-900 flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{checkerNotice}</span>
            </div>
          )}

          {/* Validation Analysis Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Phone Checker */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 uppercase flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-emerald-700" />
                  Mobile Phone Format
                </span>
                {phoneValidation.isValid && !phoneValidation.warning ? (
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded">
                    E.164 Valid
                  </span>
                ) : (
                  <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
                    Needs Attention
                  </span>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Mobile Number (With +260 code):
                </label>
                <input
                  type="text"
                  value={checkerPhone}
                  onChange={(e) => setCheckerPhone(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-lg font-mono bg-white focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              {phoneValidation.warning && (
                <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-800 flex items-start gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                  <span>{phoneValidation.warning}</span>
                </div>
              )}
              {phoneValidation.error && (
                <div className="p-2.5 bg-red-50 border border-red-200 rounded-lg text-[11px] text-red-700 flex items-start gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-red-600 shrink-0 mt-0.5" />
                  <span>{phoneValidation.error}</span>
                </div>
              )}
              {phoneValidation.isValid && !phoneValidation.warning && (
                <p className="text-[11px] text-emerald-700 font-medium">
                  Verified Zambian standard: {phoneValidation.formatted}
                </p>
              )}
            </div>

            {/* Email Checker */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 uppercase flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-emerald-700" />
                  Email Address Syntax
                </span>
                {emailValidation.isValid && !emailValidation.warning ? (
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded">
                    RFC Valid
                  </span>
                ) : (
                  <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
                    Typo Detected
                  </span>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Email for Status &amp; Appointment Slips:
                </label>
                <input
                  type="email"
                  value={checkerEmail}
                  onChange={(e) => setCheckerEmail(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-lg bg-white focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              {emailValidation.warning && (
                <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-800 flex items-start gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                  <span>{emailValidation.warning}</span>
                </div>
              )}
              {emailValidation.error && (
                <div className="p-2.5 bg-red-50 border border-red-200 rounded-lg text-[11px] text-red-700 flex items-start gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-red-600 shrink-0 mt-0.5" />
                  <span>{emailValidation.error}</span>
                </div>
              )}
              {emailValidation.isValid && !emailValidation.warning && (
                <p className="text-[11px] text-emerald-700 font-medium">
                  Valid syntax &amp; verified domain.
                </p>
              )}
            </div>

            {/* Green NRC Checker */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 uppercase flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-emerald-700" />
                  Green NRC Identity Syntax
                </span>
                {nrcValidation.isValid ? (
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded">
                    Verified Format
                  </span>
                ) : (
                  <span className="text-[10px] bg-red-100 text-red-800 font-bold px-1.5 py-0.5 rounded">
                    Invalid Format
                  </span>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  National Registration Number:
                </label>
                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-mono text-xs font-bold text-slate-900">
                  {selectedApplication.nrcNumber}
                </div>
              </div>

              <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-[11px] text-emerald-800">
                Format matches Zambian national standard: 6 digits / 2 digits / 1 digit.
              </div>
            </div>
          </div>

          {/* Official Case Details Intake Verification Card */}
          <CaseDetailsForm
            application={selectedApplication}
            mode="verification"
            onSaveVerification={handleSaveVerifiedCaseDetails}
          />
        </div>
      )}

      {/* =========================================================================
          MODULE 3: APPLICATION MONITORING MODULE (DEDICATED TAB)
         ========================================================================= */}
      {activeTab === 'monitoring' && (
        <div className="space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold bg-amber-100 text-amber-900 px-2 py-0.5 rounded uppercase">
                  Module 3: Application Monitoring Module
                </span>
                <span className="text-xs text-amber-700 font-semibold flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" /> Surveillance Logic Active
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900 mt-1">
                Incomplete, Paid-but-Unsubmitted &amp; Reverted Case Surveillance
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Surfaces applications requiring applicant remediation, tracks dormant queues, and safeguards priority.
              </p>
            </div>

            {/* Slicers */}
            <div className="flex flex-wrap items-center gap-1.5 text-xs font-bold">
              {[
                { id: 'ALL', label: `All (${monitoringCounts.total})` },
                { id: 'REVERTED', label: `Reverted (${monitoringCounts.reverted})` },
                { id: 'PAID_UNSUBMITTED', label: `Paid Unsubmitted (${monitoringCounts.paidUnsubmitted})` },
                { id: 'INCOMPLETE', label: `Incomplete (${monitoringCounts.incomplete})` },
                { id: 'REVIEW', label: `In Review (${monitoringCounts.review})` },
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => setMonitoringFilter(f.id as any)}
                  className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                    monitoringFilter === f.id
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* Monitoring Grid of Dossiers */}
          <div className="space-y-3">
            {filteredMonitoringApps.map((app) => {
              const isSelected = selectedApplication.id === app.id;
              const isReverted = app.status === 'Reverted';
              const isPaid = app.status === 'Paid - Unsubmitted';
              return (
                <div
                  key={app.id}
                  onClick={() => onSelectApplication(app)}
                  className={`p-4 sm:p-5 rounded-2xl border transition-all cursor-pointer shadow-xs ${
                    isSelected
                      ? 'bg-white border-emerald-600 ring-2 ring-emerald-500/20'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-sm sm:text-base">{app.fullName}</span>
                        <span className="font-mono text-xs text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                          {app.trackingNumber}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded text-xs font-bold ${
                            isReverted
                              ? 'bg-red-100 text-red-800'
                              : isPaid
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {app.status}
                        </span>
                        {app.isUrgent && (
                          <span className="bg-amber-500 text-slate-950 font-bold text-[10px] px-1.5 py-0.2 rounded">
                            EXPRESS
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-600">
                        NRC: <strong className="font-mono">{app.nrcNumber}</strong> &bull; Station: <strong>{app.collectionOffice}</strong> &bull; Aging: <strong>{app.daysInStatus} days in current stage</strong>
                      </p>
                      {app.reversionReason && (
                        <div className="text-xs text-red-700 bg-red-50 p-2 rounded-lg border border-red-200 mt-1.5 font-medium">
                          <strong>Reversion Cause:</strong> {app.reversionReason}
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectApplication(app);
                          setActiveTab('status');
                        }}
                        className="px-3.5 py-2 rounded-xl text-xs font-bold bg-emerald-800 hover:bg-emerald-900 text-white shadow-xs transition-colors cursor-pointer"
                      >
                        Open on Dashboard &rarr;
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* =========================================================================
          MODULE 4: AUTOMATED NOTIFICATION PROTOTYPE (DEDICATED TAB)
         ========================================================================= */}
      {activeTab === 'messages' && (
        <div className="space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold bg-purple-100 text-purple-900 px-2 py-0.5 rounded uppercase">
                  Module 4: Automated Notification Prototype
                </span>
                <span className="text-xs text-purple-700 font-semibold flex items-center gap-1">
                  <Bell className="w-3.5 h-3.5" /> SMS &amp; Portal Notification Log
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900 mt-1">
                Official MoHAIS Notification Tracking &amp; Message Board
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Functionality for generating and tracking approved reminders, quiet intervals, and delivery receipts.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsPhoneSimOpen(true)}
                className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
              >
                <Smartphone className="w-4 h-4" />
                <span>Launch SMS Mobile Handset Simulator</span>
              </button>
            </div>
          </div>

          {/* Quiet Interval Compliance Banner */}
          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
            <div>
              <strong>Approved Communication Schedule &bull; EOI Section 3.4:</strong> Automated reminders enforce a 72-hour quiet interval per applicant to eliminate duplicate or aggressive alerts while keeping citizens fully informed of mandatory actions.
            </div>
          </div>

          {/* Notifications Log List */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                Delivered Notices for #{selectedApplication.trackingNumber} ({selectedApplication.fullName})
              </h4>
              <span className="text-xs font-mono text-slate-500">
                {selectedApplication.notifications.length} Logs
              </span>
            </div>

            {selectedApplication.notifications.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">
                No notifications logged yet for this dossier.
              </div>
            ) : (
              <div className="space-y-3">
                {selectedApplication.notifications.map((n) => (
                  <div
                    key={n.id}
                    className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 text-xs space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900">{n.subject || 'OPAS Alert'}</span>
                        <span className="text-[10px] bg-slate-200 text-slate-800 px-2 py-0.5 rounded font-mono font-bold">
                          {n.channel}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] text-slate-500 font-mono">
                          {new Date(n.timestamp).toLocaleString()}
                        </span>
                        <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded">
                          {n.deliveryStatus}
                        </span>
                      </div>
                    </div>
                    <p className="text-slate-700 leading-relaxed font-sans">{n.content}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          NEW APPLICATION TAB
         ========================================================================= */}
      {activeTab === 'apply' && (
        <ApplicationForm
          onSubmitSuccess={(newApp) => {
            onAddNewApplication(newApp);
            onSelectApplication(newApp);
            setActiveTab('status');
          }}
          onCancel={() => setActiveTab('status')}
        />
      )}

      {/* =========================================================================
          APPROVED FAQS TAB
         ========================================================================= */}
      {activeTab === 'faqs' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-5">
          <div className="border-b border-slate-100 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900">
                Approved MoHAIS Passport FAQs &amp; Operational Knowledge Base
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Verified immigration rules grounding the 24/7 AI Guidance Assistant (Module 1)
              </p>
            </div>
            <button
              onClick={() => setActiveTab('guidance')}
              className="px-3 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Ask in AI Assistant</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {APPROVED_FAQS.map((faq) => (
              <div key={faq.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 space-y-2 text-xs">
                <span className="text-[10px] uppercase font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  {faq.category}
                </span>
                <h4 className="font-bold text-slate-900 text-sm mt-1">{faq.question}</h4>
                <div className="text-slate-700 whitespace-pre-wrap leading-relaxed">{faq.answer}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =========================================================================
          SETTINGS & GOVERNANCE TAB
         ========================================================================= */}
      {activeTab === 'settings' && (
        <div className="space-y-5">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
                <Settings className="w-4 h-4 text-slate-700" />
                Citizen Preferences &amp; Notification Settings
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Configure your approved notification channels, audio voice assistance, and data privacy options.
              </p>
            </div>
          </div>

          {settingsSavedNotice && (
            <div className="p-3.5 bg-emerald-50 border border-emerald-300 rounded-xl text-xs text-emerald-900 flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span className="font-semibold">Preferences successfully saved to your OPAS citizen account!</span>
            </div>
          )}

          <form onSubmit={handleSaveSettings} className="space-y-5">
            {/* Notification Delivery Channels */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3 text-xs">
              <h4 className="font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
                <Bell className="w-4 h-4 text-emerald-700" />
                Approved Notification Channels
              </h4>
              <p className="text-slate-500 text-[11px]">
                Per MoHAIS EOI Section 3.4: Automated reminders follow approved communication schedules and 72-hour quiet intervals.
              </p>

              <div className="space-y-3 pt-2">
                <label className="flex items-center justify-between p-3 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer">
                  <div>
                    <span className="font-bold text-slate-900 block">SMS Status Notifications</span>
                    <span className="text-[11px] text-slate-500">
                      Direct alerts to {selectedApplication.contact.phone} for biometrics scheduling &amp; collection.
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={smsAlertsEnabled}
                    onChange={(e) => setSmsAlertsEnabled(e.target.checked)}
                    className="w-4 h-4 text-emerald-700 rounded cursor-pointer"
                  />
                </label>

                <label className="flex items-center justify-between p-3 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer">
                  <div>
                    <span className="font-bold text-slate-900 block">Email Dossier Summaries</span>
                    <span className="text-[11px] text-slate-500">
                      Official email notices sent to {selectedApplication.contact.email} with PDF slips.
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={emailAlertsEnabled}
                    onChange={(e) => setEmailAlertsEnabled(e.target.checked)}
                    className="w-4 h-4 text-emerald-700 rounded cursor-pointer"
                  />
                </label>

                <label className="flex items-center justify-between p-3 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer">
                  <div>
                    <span className="font-bold text-slate-900 block">OPAS Portal Message Board</span>
                    <span className="text-[11px] text-slate-500">
                      In-app official communications displayed on your personal dashboard.
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={boardAlertsEnabled}
                    onChange={(e) => setBoardAlertsEnabled(e.target.checked)}
                    className="w-4 h-4 text-emerald-700 rounded cursor-pointer"
                  />
                </label>
              </div>
            </div>

            {/* Guidance Voice & Language Settings */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3 text-xs">
              <h4 className="font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
                <Globe className="w-4 h-4 text-emerald-700" />
                Assistant Language &amp; Speech Playback
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Preferred Language:</label>
                  <select
                    value={preferredLanguage}
                    onChange={(e) => setPreferredLanguage(e.target.value as any)}
                    className="w-full p-2.5 border border-slate-300 rounded-lg bg-white cursor-pointer"
                  >
                    <option value="English">English (Official Government Standard)</option>
                    <option value="Bemba">IciBemba</option>
                    <option value="Nyanja">ChiNyanja</option>
                    <option value="Tonga">Chitonga</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Voice Playback:</label>
                  <label className="flex items-center gap-2 p-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={autoVoice}
                      onChange={(e) => setAutoVoice(e.target.checked)}
                      className="w-4 h-4 text-emerald-700 rounded cursor-pointer"
                    />
                    <span className="text-slate-800 font-medium">Auto-read guidance answers with speech synthesis</span>
                  </label>
                </div>
              </div>
            </div>

            {/* Data Governance & Privacy Consent */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3 text-xs">
              <h4 className="font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
                <Lock className="w-4 h-4 text-emerald-700" />
                Data Protection &amp; Governance (EOI Section 6.1)
              </h4>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Your passport information is processed under the Ministry of Home Affairs data protection policy. Personal identification is strictly accessed by authorized vetting officers at designated passport centers.
              </p>
              <label className="flex items-center gap-2 p-2.5 rounded-lg bg-slate-50 border border-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={dataConsent}
                  onChange={(e) => setDataConsent(e.target.checked)}
                  className="w-4 h-4 text-emerald-700 rounded cursor-pointer"
                />
                <span className="font-semibold text-slate-900">
                  I consent to automated optical pre-flight checks and SMS notification delivery.
                </span>
              </label>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                className="px-6 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-lg font-bold text-xs shadow-md transition-colors cursor-pointer"
              >
                Save Preferences
              </button>
            </div>
          </form>
        </div>
      )}

      </div>

      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-white border-t border-slate-200 shadow-[0_-4px_12px_rgba(15,23,42,0.06)] grid grid-cols-5 pb-[env(safe-area-inset-bottom)]" aria-label="Primary">
        {bottomNavItems.map((item) => {
          const Icon = item.icon;
          const active = item.id === activeTab;
          return (
            <button key={item.id} onClick={() => goTo(item.id)} aria-current={active ? 'page' : undefined}
              className={`relative flex flex-col items-center gap-0.5 py-2.5 text-[10px] font-bold cursor-pointer ${active ? 'text-emerald-800' : 'text-slate-500'}`}>
              <Icon className="w-5 h-5" />
              {item.shortLabel}
              {item.badge ? <span className="absolute top-1.5 left-1/2 ml-2 min-w-4 h-4 px-1 rounded-full bg-red-600 text-white text-[9px] font-black flex items-center justify-center">{item.badge}</span> : null}
            </button>
          );
        })}
        <button onClick={() => setMobileMenuOpen(true)} className="flex flex-col items-center gap-0.5 py-2.5 text-[10px] font-bold text-slate-500 cursor-pointer">
          <Menu className="w-5 h-5" />
          More
        </button>
      </nav>

      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label="Navigation menu">
          <div className="absolute inset-0 bg-slate-900/50" onClick={() => setMobileMenuOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-[85%] max-w-xs bg-white shadow-2xl overflow-y-auto flex flex-col">
            <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200">
              <span className="text-sm font-extrabold text-slate-900">Menu</span>
              <button onClick={() => setMobileMenuOpen(false)} className="p-2 rounded-lg hover:bg-slate-100 cursor-pointer" aria-label="Close menu">
                <X className="w-5 h-5 text-slate-600" />
              </button>
            </div>
            {sidebarContent}
          </div>
        </div>
      )}

      {/* =========================================================================
          INTERACTIVE MODALS
         ========================================================================= */}
      {/* High-Fidelity Document & Optical AI Viewer */}
      {inspectedDoc && (
        <DocumentViewerModal
          document={inspectedDoc}
          application={selectedApplication}
          onClose={() => setInspectedDoc(null)}
          isOfficerRole={false}
        />
      )}

      {/* Citizen Mobile Phone & SMS Simulator */}
      {isPhoneSimOpen && (
        <CitizenPhoneSimulatorModal
          application={selectedApplication}
          onClose={() => setIsPhoneSimOpen(false)}
        />
      )}

      {/* Biometrics Appointment Booking Modal */}
      {isBiometricsModalOpen && (
        <BiometricsSchedulerModal
          application={selectedApplication}
          onClose={() => setIsBiometricsModalOpen(false)}
          onConfirmSchedule={(dateStr, office) => {
            onUpdateStatus(
              selectedApplication.id,
              'Biometrics Scheduled',
              `Biometrics enrollment scheduled for ${dateStr} at ${office}.`
            );
            selectedApplication.biometricsDate = dateStr;
            selectedApplication.collectionOffice = office;
          }}
        />
      )}
    </div>
  );
};
