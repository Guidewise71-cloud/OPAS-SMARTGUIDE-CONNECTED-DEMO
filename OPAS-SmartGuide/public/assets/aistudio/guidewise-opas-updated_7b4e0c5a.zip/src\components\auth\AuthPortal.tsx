import React, { useState } from 'react';
import {
  Shield,
  Lock,
  Mail,
  User,
  Phone,
  ArrowRight,
  ArrowLeft,
  X,
  CheckCircle2,
  AlertTriangle,
  KeyRound,
  Sparkles,
  Building2,
  UserCheck,
} from 'lucide-react';
import { UserAccount } from '../../types/auth';
import { validateNRC, validatePhoneNumber, validateEmail } from '../../utils/validation';

interface AuthPortalProps {
  users: UserAccount[];
  onLogin: (user: UserAccount) => void;
  onRegisterCitizen: (newUser: UserAccount) => void;
  initialMode?: 'login' | 'register';
  onClose?: () => void;
  isModal?: boolean;
}

export const AuthPortal: React.FC<AuthPortalProps> = ({
  users,
  onLogin,
  onRegisterCitizen,
  initialMode = 'login',
  onClose,
  isModal = false,
}) => {
  const [authMode, setAuthMode] = useState<'login' | 'register'>(initialMode);

  React.useEffect(() => {
    if (initialMode) {
      setAuthMode(initialMode);
    }
  }, [initialMode]);

  // Login Form State
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // Register Form State (Citizen Account Creation)
  const [regFullName, setRegFullName] = useState('');
  const [regNrc, setRegNrc] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPhoneCode, setRegPhoneCode] = useState('+260');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regError, setRegError] = useState('');
  const [regSuccess, setRegSuccess] = useState(false);

  // Validation
  const nrcValidation = validateNRC(regNrc);
  const phoneValidation = validatePhoneNumber(regPhone, regPhoneCode);
  const emailValidation = validateEmail(regEmail);

  // Handle Login
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    const cleanId = loginIdentifier.trim().toLowerCase();
    const user = users.find(
      (u) =>
        u.email.toLowerCase() === cleanId ||
        (u.nrcNumber && u.nrcNumber.toLowerCase() === cleanId) ||
        (u.badgeNumber && u.badgeNumber.toLowerCase() === cleanId)
    );

    if (!user) {
      setLoginError('No account found matching this email, NRC, or Officer ID.');
      return;
    }

    if (user.status === 'SUSPENDED') {
      setLoginError('This officer/citizen account has been suspended by the administrator.');
      return;
    }

    // Verify password (in test sandbox, default 'password123' or 'admin' or matching password)
    if (user.password && loginPassword !== user.password && loginPassword !== 'password123' && loginPassword !== 'admin') {
      setLoginError('Incorrect password. Please verify your credentials or contact administrator.');
      return;
    }

    // Login successful
    onLogin(user);
  };

  // Handle Quick Demo Login
  const handleQuickLogin = (email: string) => {
    const user = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (user) {
      onLogin(user);
    }
  };

  // Handle Citizen Registration
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');

    if (!regFullName.trim()) {
      setRegError('Please enter your full legal name as it appears on your Green NRC.');
      return;
    }

    if (!nrcValidation.isValid) {
      setRegError(nrcValidation.message || 'Please enter a valid Green NRC format (123456/78/1).');
      return;
    }

    if (!phoneValidation.isValid) {
      setRegError(phoneValidation.error || 'Please enter a valid phone number.');
      return;
    }

    if (!emailValidation.isValid) {
      setRegError(emailValidation.error || 'Please enter a valid email address.');
      return;
    }

    if (regPassword.length < 6) {
      setRegError('Password must be at least 6 characters long.');
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setRegError('Passwords do not match.');
      return;
    }

    // Check if email or NRC already registered
    const existing = users.find(
      (u) =>
        u.email.toLowerCase() === regEmail.trim().toLowerCase() ||
        (u.nrcNumber && u.nrcNumber === regNrc.trim())
    );

    if (existing) {
      setRegError('An account with this email or NRC number already exists. Please sign in instead.');
      return;
    }

    const newCitizen: UserAccount = {
      id: `usr-citizen-${Date.now()}`,
      email: regEmail.trim().toLowerCase(),
      password: regPassword,
      fullName: regFullName.trim(),
      role: 'citizen',
      nrcNumber: regNrc.trim(),
      phone: phoneValidation.formatted,
      status: 'ACTIVE',
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString(),
    };

    setRegSuccess(true);
    setTimeout(() => {
      onRegisterCitizen(newCitizen);
      onLogin(newCitizen);
    }, 1200);
  };

  const content = (
    <div className="w-full max-w-xl relative">
      {/* Top navigation row with arrow button to return to main page */}
      {onClose && (
        <div className="flex items-center justify-between mb-4">
          <button
            type="button"
            onClick={onClose}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-bold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 shadow-xs transition-all hover:-translate-x-0.5 cursor-pointer group"
            title="Return to Main Welcome Page"
            aria-label="Return to Main Welcome Page"
          >
            <ArrowLeft className="w-4 h-4 text-emerald-800 group-hover:-translate-x-0.5 transition-transform" />
            <span>Back to Main Page</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white flex items-center justify-center shadow-xs transition-transform hover:scale-105 cursor-pointer border border-slate-600"
            title="Close"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Government Emblem & Header */}
      <div className="text-center mb-6">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-emerald-800 text-white shadow-md mb-3">
          <Shield className="w-8 h-8 stroke-[2.2]" />
        </div>
        <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-widest block">
          Republic of Zambia · Ministry of Home Affairs &amp; Internal Security
        </span>
        <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">
          {authMode === 'register' ? 'Citizen Account Creation' : 'OPAS Unified Access Portal'}
        </h2>
        <p className="text-xs text-slate-500 mt-1">
          {authMode === 'register'
            ? 'Register with your Green NRC to begin your passport application'
            : 'Single gateway for Zambian Citizens, Passport Officers & System Administrators'}
        </p>
      </div>

      {/* Auth Card Container */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden">
        {/* Segmented Mode Selector */}
        <div className="grid grid-cols-2 p-1.5 bg-slate-100 border-b border-slate-200 text-xs font-bold">
          <button
            onClick={() => {
              setAuthMode('login');
              setLoginError('');
            }}
              className={`py-2.5 rounded-lg transition-all cursor-pointer ${
                authMode === 'login'
                  ? 'bg-white text-emerald-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Sign In to OPAS
            </button>
            <button
              onClick={() => {
                setAuthMode('register');
                setRegError('');
              }}
              className={`py-2.5 rounded-lg transition-all cursor-pointer ${
                authMode === 'register'
                  ? 'bg-white text-emerald-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Create Citizen Account
            </button>
          </div>

          <div className="p-6 sm:p-8">
            {/* MODE 1: Unified Sign In Form */}
            {authMode === 'login' && (
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                {loginError && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
                    <span>{loginError}</span>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                    Email, Green NRC or Officer ID
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={loginIdentifier}
                      onChange={(e) => setLoginIdentifier(e.target.value)}
                      placeholder="e.g. name@domain.com or 294812/11/1 or PO-LUS-001"
                      required
                      className="w-full text-xs pl-9 pr-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white"
                    />
                  </div>
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    Citizens use email or NRC; Passport Officers use official email or badge ID.
                  </span>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide">
                      Password
                    </label>
                    <span className="text-[11px] text-slate-400">
                      Sandbox default: password123 / admin
                    </span>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="password"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="••••••••"
                      required
                      className="w-full text-xs pl-9 pr-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white font-mono"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full mt-2 py-3 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-lg shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <KeyRound className="w-4 h-4" />
                  <span>Authenticate &amp; Enter Portal</span>
                </button>

                {/* Quick Demo Pre-fills */}
                <div className="pt-5 mt-5 border-t border-slate-100">
                  <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2 text-center">
                    Instant Sandbox Sign-In Profiles
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => handleQuickLogin('mutinta.mweetwa@gmail.com')}
                      className="p-2 text-left border border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/50 rounded-lg transition-all cursor-pointer group"
                    >
                      <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 group-hover:text-emerald-900">
                        <User className="w-3.5 h-3.5 text-emerald-700" />
                        <span>Citizen</span>
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">Mutinta Mweetwa</div>
                      <span className="text-[10px] text-red-600 font-semibold block mt-0.5">
                        Reverted Case #1592
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleQuickLogin('s.banda@mohais.gov.zm')}
                      className="p-2 text-left border border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/50 rounded-lg transition-all cursor-pointer group"
                    >
                      <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 group-hover:text-emerald-900">
                        <Shield className="w-3.5 h-3.5 text-emerald-700" />
                        <span>Passport Officer</span>
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">Spriano Banda</div>
                      <span className="text-[10px] text-emerald-700 font-semibold block mt-0.5">
                        Lusaka Central PO
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleQuickLogin('admin@mohais.gov.zm')}
                      className="p-2 text-left border border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/50 rounded-lg transition-all cursor-pointer group"
                    >
                      <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 group-hover:text-emerald-900">
                        <Building2 className="w-3.5 h-3.5 text-emerald-700" />
                        <span>MoHAIS Admin</span>
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">System Administrator</div>
                      <span className="text-[10px] text-indigo-700 font-semibold block mt-0.5">
                        Officer Provisioning
                      </span>
                    </button>
                  </div>
                </div>

                {/* Secondary back link if user does not want to log in */}
                {onClose && (
                  <div className="text-center pt-3 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={onClose}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-emerald-800 transition-colors cursor-pointer"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      <span>Don&apos;t want to log in? Return to main page</span>
                    </button>
                  </div>
                )}
              </form>
            )}

            {/* MODE 2: Citizen Account Registration */}
            {authMode === 'register' && (
              <form onSubmit={handleRegisterSubmit} className="space-y-4">
                {regError && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
                    <span>{regError}</span>
                  </div>
                )}

                {regSuccess && (
                  <div className="p-3.5 bg-emerald-50 border border-emerald-300 rounded-lg text-xs text-emerald-900 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span className="font-semibold">
                      Citizen Account Created Successfully! Logging into OPAS...
                    </span>
                  </div>
                )}

                {/* Full Legal Name */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Full Legal Name (As on Green NRC)
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={regFullName}
                      onChange={(e) => setRegFullName(e.target.value)}
                      placeholder="e.g. Chileshe Mulenga"
                      required
                      className="w-full text-xs pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white"
                    />
                  </div>
                </div>

                {/* Green NRC */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Green NRC Number (Format: 123456/78/1)
                  </label>
                  <input
                    type="text"
                    value={regNrc}
                    onChange={(e) => setRegNrc(e.target.value)}
                    placeholder="294812/11/1"
                    required
                    className={`w-full text-xs p-2 border rounded-lg font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white ${
                      regNrc && !nrcValidation.isValid ? 'border-red-400 bg-red-50/20' : 'border-slate-300'
                    }`}
                  />
                  {regNrc && !nrcValidation.isValid && (
                    <p className="text-[11px] text-red-600 mt-1 font-medium">{nrcValidation.message}</p>
                  )}
                  {regNrc && nrcValidation.isValid && (
                    <p className="text-[11px] text-emerald-700 mt-1 font-medium flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> NRC syntax valid.
                    </p>
                  )}
                </div>

                {/* Phone & Country Code */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Mobile Phone (For SMS Status Notifications)
                  </label>
                  <div className="flex gap-2">
                    <select
                      value={regPhoneCode}
                      onChange={(e) => setRegPhoneCode(e.target.value)}
                      className="p-2 border border-slate-300 rounded-lg bg-slate-50 font-mono text-xs w-28"
                    >
                      <option value="+260">+260 (ZM)</option>
                      <option value="+44">+44 (UK)</option>
                      <option value="+1">+1 (US)</option>
                      <option value="+27">+27 (ZA)</option>
                    </select>
                    <input
                      type="text"
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      placeholder="0977 123456"
                      required
                      className="flex-1 text-xs p-2 border border-slate-300 rounded-lg font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white"
                    />
                  </div>
                  {regPhone && phoneValidation.warning && (
                    <p className="text-[11px] text-amber-700 mt-1 font-medium">{phoneValidation.warning}</p>
                  )}
                  {regPhone && phoneValidation.error && (
                    <p className="text-[11px] text-red-600 mt-1 font-medium">{phoneValidation.error}</p>
                  )}
                </div>

                {/* Email Address */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="chileshe.mulenga@gmail.com"
                    required
                    className="w-full text-xs p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white"
                  />
                  {regEmail && emailValidation.warning && (
                    <p className="text-[11px] text-amber-700 mt-1 font-medium">{emailValidation.warning}</p>
                  )}
                </div>

                {/* Passwords */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                      Create Password
                    </label>
                    <input
                      type="password"
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      placeholder="••••••••"
                      required
                      className="w-full text-xs p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                      Confirm Password
                    </label>
                    <input
                      type="password"
                      value={regConfirmPassword}
                      onChange={(e) => setRegConfirmPassword(e.target.value)}
                      placeholder="••••••••"
                      required
                      className="w-full text-xs p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white font-mono"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={regSuccess}
                  className="w-full mt-2 py-3 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-lg shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <UserCheck className="w-4 h-4" />
                  <span>Register &amp; Create Citizen Account</span>
                </button>

                {/* Secondary back link if user does not want to register */}
                {onClose && (
                  <div className="text-center pt-2">
                    <button
                      type="button"
                      onClick={onClose}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-emerald-800 transition-colors cursor-pointer"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      <span>Back to main page</span>
                    </button>
                  </div>
                )}
              </form>
            )}
          </div>
        </div>

        {/* Footer help note */}
        <p className="text-center text-[11px] text-slate-500 mt-4">
          Government of the Republic of Zambia · Online Passport Application System (OPAS)
        </p>
      </div>
    );

  if (isModal) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto animate-in fade-in duration-200">
        {content}
      </div>
    );
  }

  return (
    <div className="min-h-[85vh] flex items-center justify-center py-8 px-4 sm:px-6">
      {content}
    </div>
  );
};
